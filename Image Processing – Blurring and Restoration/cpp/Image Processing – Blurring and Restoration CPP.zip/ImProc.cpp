/*
  First steps in Image Processing
  Creating two simple Synthetic Images:
  Gray Rectangle and Analog Ramp
  Using BMP Library
*/

#include <stdio.h> // for printf
#include <conio.h> // for _getch
#include <string>
#include <iostream> // for cin cout
#include <fstream>  // For file IO
using namespace std; // Explain some day 

// This needed to do Math calculations
#define _USE_MATH_DEFINES
#include <math.h>

#include "c2dByteGrayImage.h"
#include "c2dFloatGrayImage.h"
#include "FFT.h"

const int NUMBER_OF_ROWS = 480;
const int NUMBER_OF_COLUMNS = 640;
const int filterHalfSize = 3;


void minmax(int ThreshHold, string filename, c2dFloatGrayImage& src, c2dByteGrayImage& des)
{
	int numPixels = src.NumberOfPixels();
	tFloat* pSrc = src.PointerToPixel();  // Pointer to source image
	tByte* pDes = des.PointerToPixel();  // Pointer to destination image

	// Find min and max
	tFloat minVal = pSrc[0], maxVal = pSrc[0];
	for (int i = 1; i < numPixels; i++) {
		if (pSrc[i] < minVal) minVal = pSrc[i];
		if (pSrc[i] > maxVal) maxVal = pSrc[i];
	}

	if (minVal == maxVal) return;

	double scale = 255.0 / (maxVal - minVal);

	for (int i = 0; i < numPixels; i++) {
		tByte newVal = (tByte)((pSrc[i] - minVal) * scale);
		pDes[i] = (newVal > ThreshHold) ? 255 : 0;
	}

	// Save image
	string t_filename = filename + ".bmp";
	des.SaveToGrayBmpFile(&t_filename[0]);
}


void DoGaussianFiltration(c2dByteGrayImage& source, double* filter)
{
	// Get the number of rows and columns in the source image
	int numRows = source.NumberOfRows();
	int numColumns = source.NumberOfColumns();

	// Create a temporary destination image with the same dimensions as the source image
	c2dByteGrayImage temp_dest(numRows, numColumns);
	double summa;

	// Apply filtration in the x direction (horizontal convolution)
	for (int row = 0; row < numRows; row++)
	{
		for (int column = filterHalfSize; column < numColumns - filterHalfSize; column++)
		{
			summa = 0;
			// Convolution operation along the x direction
			for (int x = -filterHalfSize; x <= filterHalfSize; x++)
			{
				summa = summa + filter[filterHalfSize + x] * (double)source.GetPixelValue(row, column + x);
			} // end of x convolution

			// Clamp the result to the range [0, 255] to prevent overflow or underflow
			if (summa < 0)
				summa = 0;
			if (summa > 255)
				summa = 255;

			// Store the result in the temporary destination image (rounding to nearest byte value)
			temp_dest.SetPixelValue(row, column, (tByte)(summa + 0.5));
		} // end of column loop
	} // end of row loop

	// Clear the source image to prepare for vertical (y-direction) filtering
	source.Clear();

	// Apply filtration in the y direction (vertical convolution)
	for (int row = filterHalfSize; row < numRows - filterHalfSize; row++)
	{
		for (int column = 0; column < numColumns; column++)
		{
			summa = 0;
			// Convolution operation along the y direction
			for (int y = -filterHalfSize; y <= filterHalfSize; y++)
			{
				summa += filter[filterHalfSize + y] * (double)temp_dest.GetPixelValue(row + y, column);
			} // end of y convolution

			// Clamp the result to the range [0, 255] to prevent overflow or underflow
			if (summa < 0)
				summa = 0;
			if (summa > 255)
				summa = 255;

			// Store the result back in the source image (rounding to nearest byte value)
			source.SetPixelValue(row, column, (tByte)(summa + 0.5));
		} // end of column loop
	} // end of row loop
}


// Applies a convolution filter to the source image and stores the result in the destination image.
void DoFiltrationByConvolutionMINMAX(string filename, c2dByteGrayImage& source, c2dByteGrayImage& dest, double filter[][3], double factor, int threshold)
{
	int filterHalfSize = 1;
	int numRows = source.NumberOfRows();
	int numCols = source.NumberOfColumns();
	int numPixels = source.NumberOfPixels();

	// Clear destinations
	dest.Clear();

	// Allocate temporary float image
	c2dFloatGrayImage temp(numRows, numCols);

	// Access raw data with pointers
	tByte* pSrc = source.PointerToPixel();
	tFloat* pTemp = temp.PointerToPixel();

	// Convolution loop using pointer access only
	for (int row = filterHalfSize; row < numRows - filterHalfSize; row++) {
		for (int col = filterHalfSize; col < numCols - filterHalfSize; col++) {
			double summa = 0.0;

			for (int dy = -filterHalfSize; dy <= filterHalfSize; dy++) {
				for (int dx = -filterHalfSize; dx <= filterHalfSize; dx++) {
					int neighborRow = row + dy;
					int neighborCol = col + dx;

					double pixelVal = (double)pSrc[neighborRow * numCols + neighborCol];
					double filterVal = filter[dy + filterHalfSize][dx + filterHalfSize];

					summa += pixelVal * filterVal;
				}
			}

			summa *= factor;
			pTemp[row * numCols + col] = (tFloat)summa;
		}
	}
	// Apply the min-max normalization with thresholding and save the result
	minmax(threshold, filename, temp, dest);
}


// Applies a convolution filter to the source image and stores the result in the destination image. 
// Applies a 3x3 convolution filter on the source image and stores the result in the destination image.
void DoFiltrationByConvolution(c2dByteGrayImage& source, c2dByteGrayImage& dest, double filter[][3], double factor)
{
	int filterHalfSize = 1;  // for 3x3 filter
	dest.Clear();  // reset destination image
	int numRows = source.NumberOfRows();
	int numCols = source.NumberOfColumns();

	tByte* pSrc = source.PointerToPixel();
	tByte* pDst = dest.PointerToPixel();

	for (int row = filterHalfSize; row < numRows - filterHalfSize; row++) {
		for (int col = filterHalfSize; col < numCols - filterHalfSize; col++) {
			double summa = 0.0;

			for (int dy = -filterHalfSize; dy <= filterHalfSize; dy++) {
				for (int dx = -filterHalfSize; dx <= filterHalfSize; dx++) {
					int neighborRow = row + dy;
					int neighborCol = col + dx;
					double pixelValue = (double)pSrc[neighborRow * numCols + neighborCol];
					double filterValue = filter[dy + filterHalfSize][dx + filterHalfSize];
					summa += pixelValue * filterValue;
				}
			}

			summa *= factor;
			if (summa < 0) summa = 0;
			if (summa > 255) summa = 255;

			pDst[row * numCols + col] = (tByte)(summa + 0.5);
		}
	}
}


// Applies a 5x5 convolution filter and then normalizes the result using min-max normalization.
void DoFiltrationByConvolution5MINMAX(string filename, c2dByteGrayImage& source, c2dByteGrayImage& dest, double filter[][5], double factor, int threshold)
{
	int filterHalfSize = 2;  // 5x5 filter -> half = 2
	int numRows = source.NumberOfRows();
	int numCols = source.NumberOfColumns();
	int numPixels = source.NumberOfPixels();

	// Clear destination image
	dest.Clear();

	// Temporary float image to store filtered result
	c2dFloatGrayImage temp(numRows, numCols);

	// Get raw data pointers
	tByte* pSrc = source.PointerToPixel();
	tFloat* pTemp = temp.PointerToPixel();

	// Apply convolution using pointer access
	for (int row = filterHalfSize; row < numRows - filterHalfSize; row++) {
		for (int col = filterHalfSize; col < numCols - filterHalfSize; col++) {
			double summa = 0.0;

			for (int dy = -filterHalfSize; dy <= filterHalfSize; dy++) {
				for (int dx = -filterHalfSize; dx <= filterHalfSize; dx++) {
					int neighborRow = row + dy;
					int neighborCol = col + dx;

					double pixelVal = (double)pSrc[neighborRow * numCols + neighborCol];
					double filterVal = filter[dy + filterHalfSize][dx + filterHalfSize];

					summa += pixelVal * filterVal;
				}
			}

			summa *= factor;
			pTemp[row * numCols + col] = (tFloat)summa;
		}
	}

	// Apply min-max normalization + thresholding
	minmax(threshold, filename, temp, dest);
}

// Applies a 5x5 convolution filter and clamps the result between [0, 255].
void DoFiltrationByConvolution5(c2dByteGrayImage& source, c2dByteGrayImage& dest, double filter[][5], double factor)
{
	int filterHalfSize = 2;  // for 5x5 filter
	int numRows = source.NumberOfRows();
	int numCols = source.NumberOfColumns();

	// Clear destination image
	dest.Clear();

	// Get raw data pointers
	tByte* pSrc = source.PointerToPixel();
	tByte* pDst = dest.PointerToPixel();

	// Apply convolution using pointer access
	for (int row = filterHalfSize; row < numRows - filterHalfSize; row++) {
		for (int col = filterHalfSize; col < numCols - filterHalfSize; col++) {
			double summa = 0.0;

			for (int dy = -filterHalfSize; dy <= filterHalfSize; dy++) {
				for (int dx = -filterHalfSize; dx <= filterHalfSize; dx++) {
					int neighborRow = row + dy;
					int neighborCol = col + dx;

					double pixelVal = (double)pSrc[neighborRow * numCols + neighborCol];
					double filterVal = filter[dy + filterHalfSize][dx + filterHalfSize];

					summa += pixelVal * filterVal;
				}
			}

			summa *= factor;
			if (summa < 0) summa = 0;
			if (summa > 255) summa = 255;

			pDst[row * numCols + col] = (tByte)(summa + 0.5);
		}
	}
}


void CreateGaussianFilter(c2dFloatGrayImage& image, tFloat sigmaRadius)
{
	tFloat x, y, r, z;
	double summa = 0;
	int numRows = image.NumberOfRows();
	int numColumns = image.NumberOfColumns();

	// Compute Gaussian values
	for (int row = 0; row < numRows; row++)
	{
		for (int column = 0; column < numColumns; column++)
		{
			y = row - numRows / 2;
			x = column - numColumns / 2;
			r = sqrt(x * x + y * y);
			z = exp(-(r * r) / (2 * sigmaRadius * sigmaRadius));
			summa += z;
			image.SetPixelValue(row, column, z);
		}
	}

	// Normalize filter so sum = 1
	for (int row = 0; row < numRows; row++)
	{
		for (int column = 0; column < numColumns; column++)
		{
			tFloat val = image.GetPixelValue(row, column);
			image.SetPixelValue(row, column, val / summa);
		}
	}
}



void CreateInverseGaussianFilter(c2dFloatGrayImage& image, tFloat sigmaRadius)
{
	const tFloat epsilon = 0.1;  // Minimum allowed value to avoid division by near-zero (prevent noise amplification)

	tFloat x, y, r, g, z;
	int numRows = image.NumberOfRows();     // Image height
	int numColumns = image.NumberOfColumns(); // Image width

	// Loop over all pixels in the image
	for (int row = 0; row < numRows; row++)
	{
		for (int column = 0; column < numColumns; column++)
		{
			// Compute (x, y) distance from the center of the image
			y = row - numRows / 2;
			x = column - numColumns / 2;

			// Compute radial distance from center
			r = sqrt(x * x + y * y);

			// Compute Gaussian function at distance r
			g = exp(-(r * r) / (2 * sigmaRadius * sigmaRadius));

			// Clip the Gaussian to prevent division by very small values
			if (g < epsilon)
				g = epsilon;

			// Compute inverse of Gaussian value
			z = 1.0 / g;

			// Store the inverse filter value at current pixel
			image.SetPixelValue(row, column, z);
		}
	}
}




// Applies the Fast Fourier Transform (FFT) to the image with a Gaussian filter in the frequency domain.
void ApplyFFT(c2dFloatGrayImage& imageRe, bool reverseFilter, int radius)
{
	std::string filename;
	// Load the input image
	c2dFloatGrayImage imageIm(imageRe.NumberOfRows(), imageRe.NumberOfColumns());
	// Create a Gaussian filter image with the same dimensions as the input image
	c2dFloatGrayImage gaussFilter(imageRe.NumberOfRows(), imageRe.NumberOfColumns());
	CreateGaussianFilter(gaussFilter, radius);
	if (reverseFilter)
	{
		CreateInverseGaussianFilter(gaussFilter, radius);
		filename = "gaussFilter" + std::to_string(radius) + "Reversed" + ".bmp";
	}
	else
		filename = "gaussFilter" + std::to_string(radius) + ".bmp";
	gaussFilter.SaveAsOptimalGrayBmpFile(&filename[0]);
	// Shift both real and imaginary part images
	ShiftHalfSize(imageRe);
	ShiftHalfSize(imageIm);
	// Perform Forward FFT on the images
	DoFFT(imageRe, imageIm, FORWARD_FFT, NORMALIZE_BY_SQRT);
	// Filter the image in the frequency domain
	DoFiltrationInFD(imageRe, imageIm, gaussFilter);
	// Perform Inverse FFT on the filtered images
	DoFFT(imageRe, imageIm, REVERSE_FFT, NORMALIZE_BY_SQRT);
	// Shift both real and imaginary part images
	ShiftHalfSize(imageRe);
	ShiftHalfSize(imageIm);
}



int main()
{
	//-------------------------------------part 2------------------------------------------//
	c2dByteGrayImage sourceImage("Tim1.bmp");

	sourceImage.Init("Tim1.bmp");
	//Variation 1: s = 0.8 (Sharper)
	double Filter1[] = { 0.00044, 0.02191, 0.22831, 0.49868, 0.22831, 0.02191, 0.00044 };
	DoGaussianFiltration(sourceImage, Filter1);
	sourceImage.SaveToGrayBmpFile("lpf1Blur.bmp");
	sourceImage.Clear();

	sourceImage.Init("Tim1.bmp");
	//Variation 2: s = 1.0 
	double Filter2[] = { 0.00443, 0.05401, 0.24204, 0.39905, 0.24204, 0.05401, 0.00443 };
	DoGaussianFiltration(sourceImage, Filter2);
	sourceImage.SaveToGrayBmpFile("lpf2Blur.bmp");
	sourceImage.Clear();

	sourceImage.Init("Tim1.bmp");
	//Variation 3: s = 1.2 (Smoother)
	double Filter3[] = { 0.01465,0.08312,0.23556,0.33335,0.23556,0.08312,0.01465 };
	DoGaussianFiltration(sourceImage, Filter3);
	sourceImage.SaveToGrayBmpFile("lpf3Blur.bmp");
	sourceImage.Clear();

	sourceImage.Init("Tim1.bmp");
	//Variation 4: s = 1.5(Wider Smoothing)
	double Filter4[] = { 0.03663,0.11128,0.21675,0.27068,0.21675,0.11128,0.03663 };
	DoGaussianFiltration(sourceImage, Filter4);
	sourceImage.SaveToGrayBmpFile("lpf4Blur.bmp");
	sourceImage.Clear();

	sourceImage.Init("Tim1.bmp");
	//Variation 5: s = 3.5 
	double Filter5[] = { 0.11535, 0.14147, 0.15990, 0.16656, 0.15990, 0.14147, 0.11535 };
	DoGaussianFiltration(sourceImage, Filter5);
	sourceImage.SaveToGrayBmpFile("Tim1LPFc.bmp");
	cout << "Tim1LPFc.bmp file was created.\n" << endl;
	sourceImage.Clear();


	//-------------------------------------part 3------------------------------------------//
	c2dByteGrayImage srcAfterFilter("Tim1LPFc.bmp");
	c2dByteGrayImage dest(srcAfterFilter.NumberOfRows(), srcAfterFilter.NumberOfColumns());


	// Define High Pass Filter kernels
	double HPF1[3][3] = { {-2, -2, -2}, {-2, 17, -2}, {-2, -2, -2} };
	DoFiltrationByConvolution(srcAfterFilter, dest, HPF1, 1);
	dest.SaveToGrayBmpFile("HPF1.bmp");
	dest.Clear();

	// Define High Pass Filter kernels
	DoFiltrationByConvolutionMINMAX("HPF1_1_MINMAX", srcAfterFilter, dest, HPF1, 1, 50);
	DoFiltrationByConvolutionMINMAX("HPF1_2_MINMAX", srcAfterFilter, dest, HPF1, 1, 95);
	DoFiltrationByConvolutionMINMAX("HPF1_3_MINMAX", srcAfterFilter, dest, HPF1, 1, 101);
	DoFiltrationByConvolutionMINMAX("HPF1_4_MINMAX", srcAfterFilter, dest, HPF1, 1, 108);
	dest.Clear();


	double HPF2[3][3] = { {-1,-1,-1}, {-1,9,-1}, {-1,-1,-1} };
	// Define normalization factor for HPF2
	double HTP2factor = 1.0 / 1.0;
	DoFiltrationByConvolution(srcAfterFilter, dest, HPF2, HTP2factor);
	dest.SaveToGrayBmpFile("HPF2.bmp");
	dest.Clear();


	DoFiltrationByConvolutionMINMAX("HPF2_1_MINMAX", srcAfterFilter, dest, HPF2, HTP2factor, 50);
	DoFiltrationByConvolutionMINMAX("HPF2_2_MINMAX", srcAfterFilter, dest, HPF2, HTP2factor, 98);
	DoFiltrationByConvolutionMINMAX("HPF2_3_MINMAX", srcAfterFilter, dest, HPF2, HTP2factor, 115);
	DoFiltrationByConvolutionMINMAX("HFEF1cTim1LPFc", srcAfterFilter, dest, HPF2, HTP2factor, 106);
	cout << "HFEF1cTim1LPFc.bmp file was created.\n" << endl;
	dest.Clear();


	double HPF3[3][3] = { {-4,-8,-4}, {-8,64,-8}, {-4,-8,-4} };
	// Define normalization factor for HPF3
	double HTP3factor = 1.0 / 16.0;
	DoFiltrationByConvolution(srcAfterFilter, dest, HPF3, HTP3factor);
	dest.SaveToGrayBmpFile("HPF3.bmp");
	dest.Clear();

	DoFiltrationByConvolutionMINMAX("HPF3_1_MINMAX", srcAfterFilter, dest, HPF3, HTP3factor, 50);
	DoFiltrationByConvolutionMINMAX("HPF3_2_MINMAX", srcAfterFilter, dest, HPF3, HTP3factor, 95);
	DoFiltrationByConvolutionMINMAX("HPF3_3_MINMAX", srcAfterFilter, dest, HPF3, HTP3factor, 120);
	DoFiltrationByConvolutionMINMAX("HPF3_4_MINMAX", srcAfterFilter, dest, HPF3, HTP3factor, 135);
	dest.Clear();



	double HPF4[3][3] = { {0,-1,0}, {-1,5,-1}, {0,-1,0} };
	// Define normalization factor for HPF4
	double HTP4factor = 1.0 / 1.0;
	DoFiltrationByConvolution(srcAfterFilter, dest, HPF4, HTP4factor);
	dest.SaveToGrayBmpFile("HPF4.bmp");
	dest.Clear();

	DoFiltrationByConvolutionMINMAX("HPF4_1_MINMAX", srcAfterFilter, dest, HPF4, HTP4factor, 88);
	DoFiltrationByConvolutionMINMAX("HPF4_2_MINMAX", srcAfterFilter, dest, HPF4, HTP4factor, 95);
	DoFiltrationByConvolutionMINMAX("HPF4_3_MINMAX", srcAfterFilter, dest, HPF4, HTP4factor, 108);
	DoFiltrationByConvolutionMINMAX("HPF4_4_MINMAX", srcAfterFilter, dest, HPF4, HTP4factor, 116);


	//////		5*5 filters				//////
	double HPF5[5][5] = { {-1,-1,-1,-1,-1},{-1,-1,-1,-1,-1} ,{-1,-1,25,-1,-1} ,{-1,-1,-1,-1,-1} ,{-1,-1,-1,-1,-1} };
	DoFiltrationByConvolution5(srcAfterFilter, dest, HPF5, 1);
	dest.SaveToGrayBmpFile("HPF5.bmp");
	dest.Clear();
	DoFiltrationByConvolution5MINMAX("HPF5_1_MINMAX", srcAfterFilter, dest, HPF5, 1, 80);
	DoFiltrationByConvolution5MINMAX("HPF5_2_MINMAX", srcAfterFilter, dest, HPF5, 1, 100);
	DoFiltrationByConvolution5MINMAX("HPF5_3_MINMAX", srcAfterFilter, dest, HPF5, 1, 120);
	DoFiltrationByConvolution5MINMAX("HFEF2cTim1LPFc", srcAfterFilter, dest, HPF5, 1, 102);
	cout << "HFEF2cTim1LPFc.bmp file was created.\n" << endl;
	dest.Clear();
	//-------------------------------------part 4------------------------------------------//

		////////			FFT	blur		////////

	// Apply FFT and blur with different radii for the image "Tim1.bmp" and save the results
	int radiusForTextImage = 100;
	c2dFloatGrayImage imageRe;
	imageRe.LoadFromBmpFile("Tim1.bmp");
	ApplyFFT(imageRe, false, radiusForTextImage); // Apply FFT with blur
	imageRe.SaveAsOptimalGrayBmpFile("BlurredFFT1.bmp"); // Save blurred image
	imageRe.Clear(); // Clear the image for next use

	radiusForTextImage = 80;
	imageRe.LoadFromBmpFile("Tim1.bmp");
	ApplyFFT(imageRe, false, radiusForTextImage); // Apply FFT with an even smaller blur radius
	imageRe.SaveAsOptimalGrayBmpFile("BlurredFFT2.bmp"); // Save the image with blur
	imageRe.Clear();

	radiusForTextImage = 70;
	imageRe.LoadFromBmpFile("Tim1.bmp");
	ApplyFFT(imageRe, false, radiusForTextImage); // Apply FFT with an even smaller blur radius
	imageRe.SaveAsOptimalGrayBmpFile("BlurredFFT3.bmp"); // Save the image with blur
	imageRe.Clear();

	radiusForTextImage = 60;
	imageRe.LoadFromBmpFile("Tim1.bmp");
	ApplyFFT(imageRe, false, radiusForTextImage); // Apply FFT with an even smaller blur radius
	imageRe.SaveAsOptimalGrayBmpFile("BlurredFFT4.bmp"); // Save the image with blur
	imageRe.Clear();

	radiusForTextImage = 50;
	imageRe.LoadFromBmpFile("Tim1.bmp");
	ApplyFFT(imageRe, false, radiusForTextImage); // Apply FFT with an even smaller blur radius
	imageRe.SaveAsOptimalGrayBmpFile("BlurredFFT5.bmp"); // Save the image with blur
	imageRe.Clear();

	radiusForTextImage = 40;
	imageRe.LoadFromBmpFile("Tim1.bmp");
	ApplyFFT(imageRe, false, radiusForTextImage); // Apply FFT with a smaller blur radius
	imageRe.SaveAsOptimalGrayBmpFile("BlurredFFT6.bmp"); // Save filtered image best result 
	imageRe.Clear();

	radiusForTextImage = 32;
	imageRe.LoadFromBmpFile("Tim1.bmp");
	ApplyFFT(imageRe, false, radiusForTextImage); // Apply FFT with a smaller blur radius
	imageRe.SaveAsOptimalGrayBmpFile("BlurredFFT7.bmp"); // Save filtered image best result 
	imageRe.SaveAsOptimalGrayBmpFile("Tim1LPFfft.bmp"); // Save filtered image best result 
	cout << "Tim1LPFfft.bmp file was created.\n" << endl;
	imageRe.Clear();


	radiusForTextImage = 30;
	imageRe.LoadFromBmpFile("Tim1.bmp");
	ApplyFFT(imageRe, false, radiusForTextImage); // Apply FFT with a smaller blur radius
	imageRe.SaveAsOptimalGrayBmpFile("BlurredFFT8.bmp"); // Save filtered image best result 
	imageRe.Clear();



	radiusForTextImage = 20;
	imageRe.LoadFromBmpFile("Tim1.bmp");
	ApplyFFT(imageRe, false, radiusForTextImage); // Apply FFT with a smaller blur radius
	imageRe.SaveAsOptimalGrayBmpFile("BlurredFFT9.bmp"); // Save filtered image best result 
	imageRe.Clear();


	//------------------------part 5-----------------------------------------------------------//

			////////			FFT	unblur(restore)		////////

		// Apply FFT to reverse the blur effect on the "Tim1LPFfft.bmp" image with varying radii
	radiusForTextImage = 20;
	imageRe.LoadFromBmpFile("Tim1LPFfft.bmp");
	ApplyFFT(imageRe, true, radiusForTextImage); // Apply FFT to unblur the image
	imageRe.SaveAsOptimalGrayBmpFile("unBlur1.bmp"); // Save unblurred image

	radiusForTextImage = 25;
	imageRe.LoadFromBmpFile("Tim1LPFfft.bmp");
	ApplyFFT(imageRe, true, radiusForTextImage); // Unblur with a slightly higher radius
	imageRe.SaveAsOptimalGrayBmpFile("unBlur2.bmp"); // Save unblurred image
	imageRe.Clear();

	radiusForTextImage = 30;
	imageRe.LoadFromBmpFile("Tim1LPFfft.bmp");
	ApplyFFT(imageRe, true, radiusForTextImage); // Apply unblur with a higher radius
	imageRe.SaveAsOptimalGrayBmpFile("unBlur3.bmp"); // Save result
	imageRe.Clear();

	radiusForTextImage = 35;
	imageRe.LoadFromBmpFile("Tim1LPFfft.bmp");
	ApplyFFT(imageRe, true, radiusForTextImage); // Continue unblurring with larger radius
	imageRe.SaveAsOptimalGrayBmpFile("unBlur4.bmp"); // Save result
	imageRe.Clear();

	radiusForTextImage = 40;
	imageRe.LoadFromBmpFile("Tim1LPFfft.bmp");
	ApplyFFT(imageRe, true, radiusForTextImage); // Increase unblur radius
	imageRe.SaveAsOptimalGrayBmpFile("unBlur5.bmp"); // Save unblurred image
	c2dByteGrayImage Tim1RGfft(imageRe.NumberOfRows(), imageRe.NumberOfColumns());
	minmax(200, "Tim1RGfft", imageRe, Tim1RGfft); // Process the image further
	cout << "Tim1RGfft.bmp file was created.\n" << endl;
	imageRe.Clear();

	radiusForTextImage = 42;
	imageRe.LoadFromBmpFile("Tim1LPFfft.bmp");
	ApplyFFT(imageRe, true, radiusForTextImage); // Apply unblur with a larger radius
	imageRe.SaveAsOptimalGrayBmpFile("unBlur6.bmp"); // Save the image
	imageRe.Clear();

	radiusForTextImage = 43;
	imageRe.LoadFromBmpFile("Tim1LPFfft.bmp");
	ApplyFFT(imageRe, true, radiusForTextImage); // Apply unblur with even more radius
	imageRe.SaveAsOptimalGrayBmpFile("unBlur7.bmp"); // Save unblurred image
	imageRe.Clear();

	radiusForTextImage = 48;
	imageRe.LoadFromBmpFile("Tim1LPFfft.bmp");
	ApplyFFT(imageRe, true, radiusForTextImage); // Increase radius for unblur
	imageRe.SaveAsOptimalGrayBmpFile("unBlur8.bmp"); // Save result
	imageRe.Clear();

	radiusForTextImage = 50;
	imageRe.LoadFromBmpFile("Tim1LPFfft.bmp");
	ApplyFFT(imageRe, true, radiusForTextImage); // Apply high radius for unblur
	imageRe.SaveAsOptimalGrayBmpFile("unBlur9.bmp"); // Save result
	imageRe.Clear();

	radiusForTextImage = 60;
	imageRe.LoadFromBmpFile("Tim1LPFfft.bmp");
	ApplyFFT(imageRe, true, radiusForTextImage); // Unblur with an even larger radius
	imageRe.SaveAsOptimalGrayBmpFile("unBlur10.bmp"); // Save image after unblur
	imageRe.Clear();

	radiusForTextImage = 70;
	imageRe.LoadFromBmpFile("Tim1LPFfft.bmp");
	ApplyFFT(imageRe, true, radiusForTextImage); // Apply extreme unblur
	imageRe.SaveAsOptimalGrayBmpFile("unBlur11.bmp"); // Save the final unblurred image
	imageRe.Clear();


	//--------------------------------part 7 back to task 4------------------------------------------------------------------//

				//  Assignment 13 (TV Test Image)////

		// Apply FFT and blur with varying radii for the "Tim2.bmp" image and save results

	imageRe.LoadFromBmpFile("Tim2.bmp");
	radiusForTextImage = 100;
	ApplyFFT(imageRe, false, radiusForTextImage); // Apply blur with small radius
	imageRe.SaveAsOptimalGrayBmpFile("blurFFTtv1.bmp");
	imageRe.Clear();

	imageRe.LoadFromBmpFile("Tim2.bmp");
	radiusForTextImage = 80;
	ApplyFFT(imageRe, false, radiusForTextImage); // Apply blur with moderate radius
	imageRe.SaveAsOptimalGrayBmpFile("blurFFTtv2.bmp");
	imageRe.Clear();

	imageRe.LoadFromBmpFile("Tim2.bmp");
	radiusForTextImage = 70;
	ApplyFFT(imageRe, false, radiusForTextImage); // Apply blur with moderate radius
	imageRe.SaveAsOptimalGrayBmpFile("blurFFTtv3.bmp");
	imageRe.Clear();

	imageRe.LoadFromBmpFile("Tim2.bmp");
	radiusForTextImage = 60;
	ApplyFFT(imageRe, false, radiusForTextImage); // Apply blur with moderate radius
	imageRe.SaveAsOptimalGrayBmpFile("blurFFTtv4.bmp");
	imageRe.Clear();

	imageRe.LoadFromBmpFile("Tim2.bmp");
	radiusForTextImage = 50;
	ApplyFFT(imageRe, false, radiusForTextImage); // Apply blur with a larger radius
	imageRe.SaveAsOptimalGrayBmpFile("blurFFTtv5.bmp");
	imageRe.Clear();


	imageRe.LoadFromBmpFile("Tim2.bmp");
	radiusForTextImage = 40;
	ApplyFFT(imageRe, false, radiusForTextImage); // Apply blur with another radius
	imageRe.SaveAsOptimalGrayBmpFile("Tim2LPFfft.bmp");
	cout << "Tim2LPFfft.bmp file was created.\n" << endl;
	imageRe.Clear();

	//-----------------------------------part 7 back to task 5-------------------------------------------------------//

	radiusForTextImage = 20;
	imageRe.LoadFromBmpFile("Tim2LPFfft.bmp");
	ApplyFFT(imageRe, true, radiusForTextImage); // Reverse blur with small radius
	imageRe.SaveAsOptimalGrayBmpFile("unblurFFTtv1.bmp");
	imageRe.Clear();

	radiusForTextImage = 25;
	imageRe.LoadFromBmpFile("Tim2LPFfft.bmp");
	ApplyFFT(imageRe, true, radiusForTextImage); // Reverse blur with moderate radius
	imageRe.SaveAsOptimalGrayBmpFile("unblurFFTtv2.bmp");
	imageRe.Clear();

	radiusForTextImage = 30;
	imageRe.LoadFromBmpFile("Tim2LPFfft.bmp");
	ApplyFFT(imageRe, true, radiusForTextImage); // Reverse blur with moderate radius
	imageRe.SaveAsOptimalGrayBmpFile("unblurFFTtv3.bmp");
	imageRe.Clear();

	radiusForTextImage = 35;
	imageRe.LoadFromBmpFile("Tim2LPFfft.bmp");
	ApplyFFT(imageRe, true, radiusForTextImage); // Reverse blur with moderate radius
	imageRe.SaveAsOptimalGrayBmpFile("unblurFFTtv4.bmp");
	imageRe.Clear();

	radiusForTextImage = 40;
	imageRe.LoadFromBmpFile("Tim2LPFfft.bmp");
	ApplyFFT(imageRe, true, radiusForTextImage); // Reverse blur with larger radius
	imageRe.SaveAsOptimalGrayBmpFile("unblurFFTtv5.bmp");
	imageRe.SaveAsOptimalGrayBmpFile("Tim2RGfft.bmp");
	cout << "Tim2RGfft.bmp file was created.\n" << endl;
	imageRe.Clear();

	radiusForTextImage = 42;
	imageRe.LoadFromBmpFile("Tim2LPFfft.bmp");
	ApplyFFT(imageRe, true, radiusForTextImage); // Reverse blur with larger radius
	imageRe.SaveAsOptimalGrayBmpFile("unblurFFTtv6.bmp");
	imageRe.Clear();

	radiusForTextImage = 45;
	imageRe.LoadFromBmpFile("Tim2LPFfft.bmp");
	ApplyFFT(imageRe, true, radiusForTextImage); // Reverse blur with larger radius
	imageRe.SaveAsOptimalGrayBmpFile("unblurFFTtv7.bmp");
	imageRe.Clear();

	radiusForTextImage = 48;
	imageRe.LoadFromBmpFile("Tim2LPFfft.bmp");
	ApplyFFT(imageRe, true, radiusForTextImage); // Reverse blur with a very large radius
	imageRe.SaveAsOptimalGrayBmpFile("unblurFFTtv8.bmp");
	imageRe.Clear();


	radiusForTextImage = 50;
	imageRe.LoadFromBmpFile("Tim2LPFfft.bmp");
	ApplyFFT(imageRe, true, radiusForTextImage); // Reverse blur with a very large radius 
	imageRe.SaveAsOptimalGrayBmpFile("unblurFFTtv9.bmp");
	imageRe.Clear();


	radiusForTextImage = 60;
	imageRe.LoadFromBmpFile("Tim2LPFfft.bmp");
	ApplyFFT(imageRe, true, radiusForTextImage); // Reverse blur with a very large radius 
	imageRe.SaveAsOptimalGrayBmpFile("unblurFFTtv10.bmp");
	imageRe.Clear();


	radiusForTextImage = 70;
	imageRe.LoadFromBmpFile("Tim2LPFfft.bmp");
	ApplyFFT(imageRe, true, radiusForTextImage); // Reverse blur with a very large radius 
	imageRe.SaveAsOptimalGrayBmpFile("unblurFFTtv11.bmp");
	imageRe.Clear();


	// End of program
	cout << "Press any key to exit\n" << endl;
	return 0;
}
vcom ../src/push_button.VHDL
vsim push_button
add wave /*
restart -f
force CLK 1 0, 0 {20ns} -r 40ns
force RST 0 0,1 1ns
force SW_IN 0, 1 100ms , 0  150ms ,1 200ms , 0  250ms, 1 300ms
run 4500 ms



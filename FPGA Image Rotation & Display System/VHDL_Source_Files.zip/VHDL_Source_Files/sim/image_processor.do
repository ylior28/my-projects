


# Clock files:
vcom ../src/clock_generator_sim.vhd

# components files:

vcom ../src/data_image_package.vhd
vcom ../src/push_button.vhdl 
vcom ../src/sim_sram.vhd 
vcom ../src/controller.vhdl
vcom ../src/timing_generator.vhdl
vcom ../src/data_generator.vhd
vcom ../src/two_flop_synchronizer.vhd
vcom ../src/image_processor.vhdl
vcom ../src/image_processor_tb.vhdl
vsim image_processor_tb


add wave -group image_processor image_processor_tb/dut/*
add wave -group two_flop_synchronizer image_processor_tb/dut/u1/*
add wave -group two_flop_synchronizer image_processor_tb/dut/u2/*
add wave -group two_flop_synchronizer image_processor_tb/dut/u3/*
add wave -group two_flop_synchronizer image_processor_tb/dut/u4/*
add wave -group timing_generator image_processor_tb/dut/u5/*
add wave -group push_button image_processor_tb/dut/u6/*
add wave -group controller image_processor_tb/dut/u7/*
add wave -group clock_generator image_processor_tb/dut/u8/*
add wave -group data_generator image_processor_tb/dut/u9/*

add wave -group sim_sram image_processor_tb/dut2/*


restart -f 
run 20 sec
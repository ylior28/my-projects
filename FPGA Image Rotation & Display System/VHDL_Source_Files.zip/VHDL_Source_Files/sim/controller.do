vcom ../src/controller.VHDL
vsim controller
add wave /*
restart -f
force CLK 1 0, 0 {20ns} -r 40ns
force RST 0 0ns ,1 20ns
force VS 1 0
force MODE 0 0ns ,1 400ns , 0  650ns 
force ROTATE  0 0ns ,1  100ns, 0 3000ns
force ROTATION_DIR 0 0ns, 1 600ns
run 4500 ns
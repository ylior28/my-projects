library ieee; 
use ieee.std_logic_1164.all;
use work.data_image_package.all;
entity controller is 
port(  
CLK          : in std_logic; -- clock
RST          : in std_logic; -- reset 
VS           : in std_logic; -- indication V_SYNC falling edge.
MODE         : in std_logic;--automaticlly or manual image ROTATE 
ROTATE       : in std_logic;--- using for key_rotate that used for long/short press
ROTATION_DIR : in std_logic;-- the diraction of image rotation
ANGLE        : out integer range 0 to 3;--- show us which angle the image is 
HEX0         : out std_logic_vector(6 downto 0);---show the digit in altera device
HEX1         : out std_logic_vector(6 downto 0);---show the digit in altera device
HEX2         : out std_logic_vector(6 downto 0)---show the digit in altera device
);
end entity;
architecture behave of controller is 
	component bcd_to_7seg 
		port(  
				bcd_in 	: in integer range 0 to 10; --  output 
				d_out 	:OUT std_logic_vector(6 DOWNTO 0) --  output 
		);
	end component; 	
	signal sig_deg_ones: integer range 0 to 9;---there is no point to range to 9 because it is always 0 but this is not change the code.
	signal sig_deg_tens: integer range 0 to 10;-- 10 used to turn off the tens digit in altera device display
	signal sig_deg_hundreds: integer range 0 to 10;--10 used to turn off the hundreds digit in altera device display
	signal angle_sig: integer range DEG_0 to DEG_270;--- count from 0 degree to 270 degree (0,1,2,3) is (0,90,180,270)
	signal sig_cnt_1sec : integer range 0 to G_VAL_1SEC; ---T=(1/25M(our frequency) )*25M=1sec  
	signal clk_1sec_sig  :  std_logic;--- this is the sigal clock for when mode equal to 1 logic.
	signal sig_ROTATE : std_logic; --- because the push_button not syncronize with controller clock we define sig_rotate to 
------------------------------------------ work like flag.


 --****************************************************************************************************	
begin-----------instead define it in top level we decide to use it in this block. 
-----------------this is to represent the degree in altera device.  
			u1: bcd_to_7seg
		port map( bcd_in=>sig_deg_ones, 	
				 d_out=>HEX0
	    );
		
	u2: bcd_to_7seg
		port map( bcd_in=>sig_deg_tens, 	
				 d_out=>HEX1
	    );
		
	u3: bcd_to_7seg
		port map( bcd_in=>sig_deg_hundreds, 	
				 d_out=>HEX2
	    );
		
--*******************************************************************************************************************


	process(CLK,RST)
begin

	if (RST=G_RESET_ACTIVE_VALUE) then
		ANGLE<=DEG_0;
		sig_deg_ones<=0;
		sig_deg_tens<=turn_off;--- is 10 used to turn off the  digit
		sig_deg_hundreds<=turn_off;---is 10 used to turn off the digit
		angle_sig<=DEG_0;
		sig_cnt_1sec<=0;
		clk_1sec_sig<=ACTIVE_LOW;
		sig_ROTATE<=ACTIVE_LOW;
	elsif rising_edge (CLK) then
	
	
	if (ROTATE = ACTIVE_HIGH) then ---- this is the used to make it syncronize with push_button block. 
		sig_ROTATE <= ROTATE;
	end if;
	
	
	
	if(sig_cnt_1sec=G_VAL_1SEC) then --- here we create the  1sec period clock 
		sig_cnt_1sec<=0;
		clk_1sec_sig<=not clk_1sec_sig;
	else
		sig_cnt_1sec<=sig_cnt_1sec+1;
	end if; 
	
	
	
		if(VS=ACTIVE_HIGH) then-----after we finish to fill frame it should be active. 
				if(MODE=ACTIVE_HIGH) then---- the image will rotate automaticlly 
					if clk_1sec_sig=ACTIVE_HIGH then---- meaning the clock reached to one second
						if(ROTATION_DIR=ACTIVE_HIGH) then--ccw-meaning the image movig against the clock. 
							case angle_sig is---- here we create the digit for the altera device.
											---------- angle_sig is change to next degree
											----------ANGLE is show us the current degree
								when DEG_0 => -- 0 deg								
											sig_deg_ones<=0;
											sig_deg_tens<=turn_off;
											sig_deg_hundreds<=turn_off;
											angle_sig<=DEG_90;
											ANGLE<=DEG_0;
								when DEG_90 => --90 deg
											sig_deg_ones<=0;
											sig_deg_tens<=9;
											sig_deg_hundreds<=turn_off;
											angle_sig<=DEG_180;---
											ANGLE<=DEG_90;
								when DEG_180 => -- 180 deg
											sig_deg_ones<=0;
											sig_deg_tens<=8;
											sig_deg_hundreds<=1;
											angle_sig<=DEG_270;
											ANGLE<=DEG_180;
								when DEG_270 => -- 270 deg
										 sig_deg_ones<=0;
										 sig_deg_tens<=7;
										 sig_deg_hundreds<=2;
										 angle_sig<=DEG_0;
										 ANGLE<=DEG_270;
							end case;	
						else-- cw-meaning the image movig with the clock. 
							case angle_sig is
								when DEG_0 => -- remeber to change hex, 0 deg
											 sig_deg_ones<=0;
											 sig_deg_tens<=turn_off;
											 sig_deg_hundreds<=turn_off;
											 angle_sig<=DEG_270;
											 ANGLE<=DEG_0;
								when DEG_90 => -- 90 deg
											 sig_deg_ones<=0;
											 sig_deg_tens<=9;
											 sig_deg_hundreds<=turn_off;
											 angle_sig<=DEG_0;
											 ANGLE<=DEG_90;
								when DEG_180 => -- 180 deg
											 sig_deg_ones<=0;
											 sig_deg_tens<=8;
											 sig_deg_hundreds<=1;
											 angle_sig<=DEG_90;
											 ANGLE<=DEG_180;
								when DEG_270 => -- 270 deg
											 sig_deg_ones<=0;
											 sig_deg_tens<=7;
											 sig_deg_hundreds<=2;
											 angle_sig<=DEG_180;
											 ANGLE<=DEG_270;
							end case;
						end if;
						clk_1sec_sig<=ACTIVE_LOW;--to make is work only for 1 sec. 
					end if;
				else------here we starting use to rotate_key (short/long press)
					if(sig_ROTATE=ACTIVE_HIGH) then
						sig_ROTATE<=ACTIVE_LOW;
						   
							if(ROTATION_DIR=ACTIVE_HIGH) then--ccw, against clock
								case angle_sig is
									when DEG_0 => --0 deg
										sig_deg_ones<=0;
										sig_deg_tens<=turn_off;
										sig_deg_hundreds<=turn_off;
										angle_sig<=DEG_90;
										ANGLE<=DEG_0;
									when DEG_90 => -- 90 deg
										sig_deg_ones<=0;
										sig_deg_tens<=9;
										sig_deg_hundreds<=turn_off;
										angle_sig<=DEG_180;
										ANGLE<=DEG_90;
									when DEG_180 => -- 180 deg
										sig_deg_ones<=0;
										sig_deg_tens<=8;
										sig_deg_hundreds<=1;
										angle_sig<=DEG_270;
										ANGLE<=DEG_180;
									when DEG_270 => -- 270 deg
										sig_deg_ones<=0;
										sig_deg_tens<=7;
										sig_deg_hundreds<=2;
										angle_sig<=DEG_0;
										ANGLE<=DEG_270;
								end case;	
							else-- cw, with clock
								case angle_sig is
									when DEG_0 =>
										 sig_deg_ones<=0;
										 sig_deg_tens<=turn_off;
										 sig_deg_hundreds<=turn_off;
										 angle_sig<=DEG_270;
										 ANGLE<=DEG_0;
									when DEG_90 => -- 90 deg
										 sig_deg_ones<=0;
										 sig_deg_tens<=9;
										 sig_deg_hundreds<=turn_off;
										 angle_sig<=DEG_0;
										 ANGLE<=DEG_90;
									when DEG_180 => -- 180 deg
										 sig_deg_ones<=0;
										 sig_deg_tens<=8;
										 sig_deg_hundreds<=1;
										 angle_sig<=DEG_90;
										 ANGLE<=DEG_180;
									when DEG_270 => -- 270 deg
										 sig_deg_ones<=0;
										 sig_deg_tens<=7;
										 sig_deg_hundreds<=2;
										 angle_sig<=DEG_180;
										 ANGLE<=DEG_270;
								end case;
							end if;
					end if;
				end if;
		end if;
	end if;
 end process;
end architecture;
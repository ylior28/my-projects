library ieee; 
use ieee.std_logic_1164.all;
use work.data_image_package.all;
entity push_button is 
port(  
CLK      : in std_logic; -- clock
RST      : in std_logic; -- reset 
SW_IN    : in std_logic; -- for key rotate 
PRESS_OUT: out std_logic --gives us the pulse when i press the key rotate 
);
end entity;

architecture behave of push_button is 
type state_PB is (idle, press, clk_pulse,sec_pulse);--State machine (BP)Push_Button
signal next_st : state_PB;  
signal count_two_sec: integer range 0 to G_PRESS_TIMOUT_VAL ;--count for  2 sec--(200)
signal count_one_sec: integer range 0 to G_TIME_BETWEEN_PULSES ;--count for 1 sec (100)
signal count_sig: integer range 0 to TIME_10_msec ;-- to create sig_clock for the long press. 
---the calculation: T=1/f  --->  (1/25M)*250000=10[msec]
signal clk_10msec_sig: std_logic;
begin





	process(CLK,RST)
begin
	if (RST=G_RESET_ACTIVE_VALUE) then
		next_st <= idle;
		count_two_sec<=0;
		count_one_sec<=0;
		count_sig<=0;
		clk_10msec_sig<=ACTIVE_LOW;
		PRESS_OUT<=ACTIVE_LOW;
	elsif rising_edge (CLK) then
	
		PRESS_OUT<=ACTIVE_LOW;
		clk_10msec_sig<=ACTIVE_LOW;

----------------------declare new signal clk with period of 10m sec per pulse
		if(count_sig=TIME_10_msec) then
			count_sig<=0;
			clk_10msec_sig<=ACTIVE_HIGH;
		else
			count_sig<=count_sig+1;
		end if;
-------------------------------------------------------
-----starting to use state machine 		
			case next_st is 
-----idle state: waiting for press 
				when  idle =>
					count_two_sec<=0;
					PRESS_OUT<=ACTIVE_LOW;
					if SW_IN=G_BUTTON_STATE then --idle state
						next_st<=press;
					else  
						next_st<=idle;
				end if;
--------------------------------------------------------
				
			---press state:	
------------when we press the button we starting to count 2 sec 
------------to check if we arrive to long press state if we are not holding the button
------------for 2 sec to we go to short press state  				
				when  press => 
					if SW_IN=G_BUTTON_STATE then --- first condition to count for 2 sec  
								if count_two_sec=G_PRESS_TIMOUT_VAL then --- checking if the counter arrive to 200 (meanig if we counted 2sec)
									next_st<=sec_pulse;--- moving to long press 
						
						
								elsif clk_10msec_sig=ACTIVE_HIGH then -- sig_clock we declare is 10ms period for every 10ms we increace the counter
									next_st<=press;
									count_two_sec<=count_two_sec+1;
								else 
									next_st<=press;
								end if;
					else 
						next_st<=clk_pulse;---if we didnt hold the button for 2 sec 
					end if;
----------------------------------------------------------------	
--------------long press: pulse will equal to 1 logic for every 1 sec (	count_one_sec=100)			
				when  sec_pulse =>
					
					if SW_IN=G_BUTTON_STATE then
							if  count_one_sec=G_TIME_BETWEEN_PULSES then 
								next_st<=sec_pulse;
								PRESS_OUT<=ACTIVE_HIGH;
								count_one_sec<=0;
								
							elsif clk_10msec_sig=ACTIVE_HIGH then --- as we explained in line 70
								next_st<=sec_pulse;
								count_one_sec<=count_one_sec+1;
							
							else 
								next_st<=sec_pulse;
							
							end if;
					else ----- when we stop to hold the button we back to the idle state 
						next_st<=idle;
						count_one_sec<=0;
				
					end if;
	--------------------------------------------------------				
-----short press state: working with clock(25MHZ) rising for 1 logic in 1 period of clock and back to idle state.   				
				when  	clk_pulse =>   
						PRESS_OUT<=ACTIVE_HIGH;
						next_st<=idle;
			end case;
	end if;
	end process;	
end architecture;



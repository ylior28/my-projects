library ieee;
use ieee.std_logic_1164.all;
use work.data_image_package.all;

entity timing_generator_tb is        -- The Testbench entity is empty. No ports.
end entity;

architecture behave of timing_generator_tb is    -- This is the architecture of the testbench

-- constants declaration    
    constant C_CLK_PRD              : time := 20 ns;
    

    component timing_generator is                -- This is the component declaration.
    port (
        RST    : in    std_logic;
        CLK    : in    std_logic;
		H_SYNC : out 	std_logic;
		V_SYNC : out 	std_logic;
		H_CNT : out 	integer range 0 to c_pixels_per_line-1;--800
		V_CNT : out 	integer range 0 to c_lines_per_frame-1;--525
		VS    : out 	std_logic
    );
    end component;


-- signals declaration  
    signal  clk_sig  : std_logic := '0';
    signal  rst_sig  : std_logic := '0';
	signal  sig_H_SYNC  : std_logic:='0';
	signal	sig_V_SYNC  : std_logic:='0';
	signal	sig_H_CNT   : integer range 0 to c_pixels_per_line-1;--800
	signal	sig_V_CNT   : integer range 0 to c_lines_per_frame-1;--525
	signal	sig_VS      : std_logic:='0';
    
begin
   
    dut: timing_generator                    -- This is the component instantiation. dut is the instance name of the component timing_generator
   
    port map (
        RST    => rst_sig, -- The RST input of the dut instance of the pulse generator component is connected to rst_sig signal
        CLK    => clk_sig, -- The CLK input of the dut instance of the pulse generator component is connected to clk_sig signal
        H_SYNC => sig_H_SYNC,
		V_SYNC => sig_V_SYNC,
		H_CNT =>  sig_H_CNT,
		V_CNT =>  sig_V_CNT,
		VS =>     sig_VS
    );
    
    
    clk_sig <= not clk_sig after C_CLK_PRD / 2;     -- clk_sig toggles every C_CLK_PRD/2 ns
    rst_sig <= '0', '1' after 20 ns;               -- the 100 ns is arbitrary

end architecture;

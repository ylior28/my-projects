library ieee; 
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

package data_image_package is
------New constants-----------------------------
------Timing generator--------------------------
constant G_RESET_ACTIVE_VALUE: std_logic:= '0';
constant ACTIVE_HIGH: std_logic:= '1';
constant ACTIVE_LOW: std_logic:= '0';
constant c_pixels_per_line: integer := 800; --1
constant c_active_pixels: integer := 640; --2
constant c_h_sync_start: integer := 656; --3
constant c_h_sync_end: integer := 752; --4

constant c_lines_per_frame: integer := 525; --5
constant c_active_lines: integer := 480; --6
constant c_v_sync_start: integer := 490; --7
constant c_v_sync_end: integer := 492; --8
------Push button-------------------------------
constant G_BUTTON_STATE: std_logic:='0';
constant G_PRESS_TIMOUT_VAL: integer:= 200;
constant G_TIME_BETWEEN_PULSES: integer:= 100;
constant TIME_10_msec: integer:= 250000;
------Controller----------------------------
constant turn_off: integer:= 10;
constant G_VAL_1SEC: integer:= 25000000;
constant DEG_0 : integer:= 0;
constant DEG_90: integer:= 1;
constant DEG_180: integer:= 2;
constant DEG_270: integer:= 3;
-------Data generator----------------------

constant c_image_size_h: integer :=512 ;
constant c_image_size_v: integer :=512 ; 
constant c_image_start_h: integer:=64; 
constant c_image_start_v: integer:=-16 ; 
constant c_image_end_h: integer :=576 ; 
constant c_image_end_v: integer :=496;
constant RED_START: integer :=0 ;
constant RED_END: integer :=79 ; 
constant GREEN_START: integer:=80; 
constant GREEN_END: integer:=159; 
constant BLACK_START: integer :=160; 
constant BLACK_END: integer :=239;
constant YELLOW_START: integer:=240;
constant YELLOW_END: integer:=319;
constant BLUE_START: integer:=320;
constant BLUE_END: integer:=399;
constant PURPLE_STRAT: integer:=400;
constant PURPLE_END: integer:=479;
constant LIGHT_BLUE_START: integer:=480;
constant LIGHT_BLUE_END: integer:=559;
constant WHITE_START: integer:=560;
constant WHITE_END: integer:=639;

-------------------------------------------------------

    function converter_to_8bit(p_in: std_logic_vector) return std_logic_vector;
	
	type sv_array is 
	array(0 to 3) of std_logic_vector(8 downto 0);
	constant first_pixel: sv_array:=("000000000","000010000","111111111","111111111");---meaning ( 0,16,511,511)
	constant first_line: sv_array:=("000010000","111111111","111101111","000000000");---meaning (16,511,495,0)
end package data_image_package ;

package body data_image_package is
	use ieee.numeric_std.all;

    function converter_to_8bit(p_in: std_logic_vector) return std_logic_vector is
			variable  p_out: std_logic_vector (7 downto 0);
			variable  p_length: integer ;
			variable  c: integer;
    begin									
	--implement function
		p_length:=p_in'length;
		c:=(2**p_length)-1;
		p_out := std_logic_vector(to_unsigned((to_integer(unsigned(p_in)) * 255) /c,p_out'length));
        return p_out;
    end function converter_to_8bit;
end package body data_image_package;

	
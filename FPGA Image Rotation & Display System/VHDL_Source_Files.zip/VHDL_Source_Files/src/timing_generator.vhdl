library ieee;
use ieee.std_logic_1164.all;
use work.data_image_package.all;

entity timing_generator is

port (
	CLK    : in 	std_logic;	----clock (25Mhz)
	RST	   : in 	std_logic;---- reset 
	H_SYNC : out 	std_logic; ----Horizontal Sync
	V_SYNC : out 	std_logic;----Vertical sync 
	H_CNT : out 	integer range 0 to c_pixels_per_line-1;---- Horizontal counter in size of 800
	V_CNT : out 	integer range 0 to c_lines_per_frame-1;----Vertical counter in size of 525
	VS    : out 	std_logic -------- indication V_SYNC falling edge.
);
end entity;
architecture behave of timing_generator is
	signal S_cnt_hsync: integer range 0 to c_pixels_per_line-1 ;--800
	signal S_cnt_vsync: integer range 0 to c_lines_per_frame-1 ;--525

	begin
	process(CLK,RST)
	begin
	if (RST=G_RESET_ACTIVE_VALUE) then	--- restet active in 0 
		H_SYNC<=ACTIVE_HIGH;
		V_SYNC<=ACTIVE_HIGH;
		H_CNT<=0 ; 
		V_CNT<=0 ;
		VS<=  ACTIVE_LOW   ;
		S_cnt_hsync<= 0 ;
		S_cnt_vsync<= 0  ;
		
	elsif rising_edge (CLK) then

		 VS<= ACTIVE_LOW;-----while we generate the V_SYNC and H_SYNC we will hold it to zero.		 
		
		
------------------------------------------when we got H_CNT=799:		
				---explanation: if we arrive to 799 pixels and we make sure that we not exceeds the max value of V_CNT(524)
		--- then we increace the V_CNT and counting H_CNT again
		if(S_cnt_hsync=c_pixels_per_line-1 and S_cnt_vsync<c_lines_per_frame-1) then ---800,525   
			S_cnt_hsync<=0;
			H_CNT<=0;
			S_cnt_vsync<=S_cnt_vsync+1;
			V_CNT<=S_cnt_vsync+1;
------------------------------------------------------------------------------------------------------			
------------------------------------- here we startinng to handle with V_SYNC : 
----- explanation:when we arrive to 490  the V_SYNC should be off (the -1 is because then lines(41-56) are working in parallel
------ so S_cnt_vsync will be 491 in then next pulse)   			
			if(S_cnt_vsync=c_v_sync_start-1) then ----490
						V_SYNC<= ACTIVE_LOW;
						VS<=ACTIVE_HIGH;--in this part we make VS=1 for one clock period ( drivative up)
-------------explanation: here we proceed to generate the frame when we got S_cnt_vsync=492 
-----------(then -1  is the same reason i explained in line (49-50))
			elsif(S_cnt_vsync=c_v_sync_end-1) then----492
						V_SYNC<=ACTIVE_HIGH;
			end if;


---------------------here we  returning to begining(0(pixels),0(lines))			
		elsif(S_cnt_vsync=c_lines_per_frame-1 and S_cnt_hsync=c_pixels_per_line-1 ) then --5---525
				S_cnt_vsync<=0;
				V_CNT<=0;
				S_cnt_hsync<=0;
				H_CNT<=0;
				
------------------as long we are not exceeds the max value of H_CNT we increace H_CNT for every pulse of the clk 			
		elsif (S_cnt_hsync<c_pixels_per_line-1) then---800 
			S_cnt_hsync<=S_cnt_hsync+1;
			H_CNT<=S_cnt_hsync+1;
			
-----here we startinng to handle with H_SYNC :  
-----------when we arrive to H_CNT=656  the H_SYNC should be off			
			if (S_cnt_hsync=c_h_sync_start-1) then ----656 
				H_SYNC<= ACTIVE_LOW;
------here we proceed to generate the frame when we got H_CNT=752 
			elsif (S_cnt_hsync=c_h_sync_end-1)then ----752
				H_SYNC<=ACTIVE_HIGH;
			end if;
		end if;
------------------------------------------------		
	end if;
end process;
end architecture;
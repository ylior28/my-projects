library ieee; 
use ieee.std_logic_1164.all;

entity two_flop_synchronizer is 
port(
D_in : in std_logic; -- D_in input   
CLK : in std_logic; -- clock 
RST : in std_logic; -- reset
Q_out : out std_logic   -- Q output 
);
end entity;

architecture behave of two_flop_synchronizer is 
signal S: std_logic ;
begin
process(CLK,RST)
begin 
if (RST='0') then 
Q_out<='0';
S<='0';
elsif rising_edge (CLK) then 
S<=D_in;
Q_out<=S;
end if ;
end process;
end architecture;
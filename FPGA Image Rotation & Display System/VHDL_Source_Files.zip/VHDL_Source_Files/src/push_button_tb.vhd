library ieee;
use ieee.std_logic_1164.all;
use work.data_image_package.all;
entity push_button_tb is
end entity;

architecture behave of push_button_tb is
    -- constants declaration
    constant C_CLK_PRD             : time := 40 ns;
    component push_button is
        port (
            RST       : in  std_logic;
            CLK       : in  std_logic;
            SW_IN     : in  std_logic;
            PRESS_OUT : out std_logic
        );
    end component;
    
    signal clk_sig       : std_logic := '0';
    signal rst_sig       : std_logic := '0';
    signal sig_SW_IN     : std_logic;
    signal sig_PRESS_OUT : std_logic;
    
begin
    dut: push_button		
        port map (
            RST       => rst_sig,
            CLK       => clk_sig,
            SW_IN     => sig_SW_IN,
            PRESS_OUT => sig_PRESS_OUT
        );
    
    clk_sig <= not clk_sig after C_CLK_PRD / 2;
    rst_sig <= '0', '1' after 20 ns;
    
    process
    begin
        -------------Short press--------------------
      for i in 0 to 5 loop
         sig_SW_IN<='1' after 0 ms, '0' after 20 ms,  '1' after  60 ms,'0' after  110 ms,
		 '1' after  200 ms,'0' after  300 ms; 
         wait for 400 ms; 
      end loop;
        
        -------------Long press--------------------
	 for i in 0 to 2 loop
        sig_SW_IN<='1' after 0 ns, '0' after 1 sec,  '1' after  7 sec; 
         wait for 7 sec; 
      end loop;
      wait;
        
    end process;   
end architecture;
library ieee; 
use ieee.std_logic_1164.all;
use work.data_image_package.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;



entity data_generator is 		
port(  
CLK : in std_logic; -- clock
RST : in std_logic; -- reset 
ANGLE :in integer   range DEG_0 to DEG_270;  --angle is between 0 to 3 (0,1,2,3) is (0,90,180,270)    
IMAGE_ENA : in std_logic; --is work like a switch if IMAGE_ENA is '0' logic the we will see color bars else we will see the image. 
H_CNT : in integer  range 0 to c_pixels_per_line-1 ;--800-1 H_CNT range  
V_CNT :in  integer  range 0 to c_lines_per_frame-1;---525-1 V_CNT range 
SRAM_A : out  std_logic_vector  (17 downto 0);--- to send the address 
SRAM_D : in   std_logic_vector  (15 downto 0); -- the rgb collors we got from the SRAM  5-6-5
R_DATA : out  std_logic_vector  (7 downto 0); --from SRAM we got 5 bit we dafine it 8 bit because we need to send it to the HDMI controller 
G_DATA : out  std_logic_vector	(7 downto 0);---from SRAM we got 6 bit " "      "     "        "  
B_DATA : out  std_logic_vector  (7 downto 0);--from SRAM we got 5 bit  " "      "     "        "
DATA_DE : out std_logic-- tells us if we are in visible area visible is '1' logic  invisible is '0' logic 
);
end entity;

architecture behave of data_generator is 
signal image_pixel_num:std_logic_vector (8 downto 0) ;---index pixel used to send address to memory   
signal image_line_num: std_logic_vector (8 downto 0) ;---index line used to send address to memory  
signal image_h_active: std_logic;-- it tells us if we are in the horizontal area of the image 
signal image_v_active: std_logic; --it tells us if we are in the vertical area of the image 
signal image_active: std_logic;--- thats equal to image_h_active 'AND' image_v_active meaning the image will daisplay only if is equeal to '1' logic
signal image_ena_int:  std_logic; --equal to the  IMAGE_ENA we declare in entity.
signal data_tx:std_logic_vector (23 downto 0);-- recieve the color data and send it to 3 output collors (R_DATA,G_DATA,B_DATA)   
signal r_sig: std_logic_vector (4 downto 0); -- recieve the colors data from SRAM_D (red is 5 bits)
signal g_sig: std_logic_vector (5 downto 0); --recieve  the colors data from SRAM_D (green is 6 bits)
signal b_sig: std_logic_vector (4 downto 0); --recieve  the colors data from SRAM_D (blue is 5 bits)
begin
process(CLK,RST)
begin
if (RST=G_RESET_ACTIVE_VALUE) then
	image_h_active<=ACTIVE_LOW;
	image_v_active<=ACTIVE_LOW;
	image_ena_int<=ACTIVE_LOW;
	data_tx <= (others => '0');  -----------24bit
	DATA_DE<=ACTIVE_LOW;
	SRAM_A <= (others => '0'); -------------18bit
	R_DATA  <= (others => '0'); ------------9bit
	G_DATA  <= (others => '0');------------9bit
	B_DATA <=(others => '0');--------------9bit
	r_sig <=(others => '0');--------------5bit
	g_sig<=(others => '0');--------------6bit
	b_sig<=(others => '0');--------------5bit
	image_pixel_num<=first_pixel(ANGLE);
	image_line_num<=first_line(ANGLE);
	
elsif rising_edge (CLK) then
			image_ena_int<=IMAGE_ENA;-----to use the signal instead the input 	
			image_active<=image_h_active and image_v_active;--- if it equal to '1' then we are in the area of the image. 

-------------------------------------------------------------------------------

			if H_CNT>c_active_pixels or V_CNT>c_active_lines then----checking if we are in the dark zone H_CNT>640 or V_CNT>480
				data_tx<=(others => '0'); -----------24bit
				DATA_DE<=ACTIVE_LOW;

			else 
				DATA_DE<=ACTIVE_HIGH;
				r_sig<=SRAM_D(4 downto  0);---recieve the data color from SRAM
				g_sig<=SRAM_D(10 downto  5);---recieve the data color from SRAM
				b_sig<=SRAM_D(15 downto  11);---recieve the data color from SRAM
			
--------------------------------------------------------------------------------
			
				if(image_ena_int=ACTIVE_LOW) then
					case  H_CNT is ---here we create color bars for every 80 pixel (X"FF0000") written in hex
						when   RED_START to RED_END   => data_tx<=X"FF0000";  --RED: 0 to 79 
						when  GREEN_START to GREEN_END  => data_tx<=X"00FF00";  --GREEN: 80 to 159 
						when BLACK_START to BLACK_END => data_tx<=X"000000"; -- BLACK: 160 to 239
						when YELLOW_START to YELLOW_END => data_tx<=X"FFFF00";  -- YELLOW: 240 to 319
						when BLUE_START to BLUE_END => data_tx<=X"0000FF";  -- BLUE: 320 to 399
						when PURPLE_STRAT to PURPLE_END => data_tx<=X"FF00FF";  -- PURPLE: 400 to 479 
						when LIGHT_BLUE_START to LIGHT_BLUE_END => data_tx<=X"00FFFF";  -- LIGHT BLUE: 480 to 559
						when WHITE_START to WHITE_END => data_tx<=X"FFFFFF";  -- WHITE: 560 to 639
						when others => null;
					end case;
						
					---- send it to the 3 output of data_rgb
					R_DATA<=data_tx(23 downto 16);
					G_DATA<=data_tx(15 downto 8); 
					B_DATA<=data_tx(7 downto 0);
				
-------------------------------------------------------------------------------------------------------
				
				else----- display the image  
				
					if image_active=ACTIVE_HIGH then ----checknig  if we located in the image zone.  
					
					----Generate the DATA_TX by receiving the data from the SRAM_D and sending it to the three signals
					----as we did in line 79-81 after that we convert them from (5,6,5)bit each color_signal to (8,8,8) bit.  
						---- this is the function that convert to 8 bit; 
						data_tx(23 downto 16)<=converter_to_8bit(r_sig);
						data_tx(15 downto 8)<=converter_to_8bit(g_sig);
						data_tx(7 downto 0)<=converter_to_8bit(b_sig);
						
						---- send it to the 3 output of data_rgb to crate the image.
						R_DATA<=data_tx(23 downto 16);
						G_DATA<=data_tx(15 downto 8); 
						B_DATA<=data_tx(7 downto 0);
					end if;	


					---------------checking if we in the hozrizental zone of the image. 
					if(H_CNT>c_image_start_h and H_CNT<c_image_end_h) then	
						image_h_active<=ACTIVE_HIGH;
					else
						image_h_active<=ACTIVE_LOW;
						data_tx<=(others => '0');----this is to darken the sides
					end if;
							
					---------------checking if we in the vertical zone of the image. 	
					if(V_CNT>0 and V_CNT<c_active_lines) then
						image_v_active<=ACTIVE_HIGH;
					else 
						data_tx<=(others => '0');----this is to darken the sides
						image_v_active<=ACTIVE_LOW;
					end if;

	
	
					--***************************************************************************	
					--in this part we create addresses for each pixels and lines the image for each angle the image is at 
					if(ANGLE=DEG_0) then----for 0 degree
						
						if V_CNT=0 then 
							image_line_num<=first_line(ANGLE);--- take the frist index from array we creat in package 
						end if;
					
						if H_CNT=c_image_start_h then 
								image_pixel_num<=first_pixel(ANGLE);
						end if;
						
						if(H_CNT>c_image_start_h and H_CNT<c_image_end_h) then
							image_pixel_num<=image_pixel_num+1;---because the index start from 0
						end if; 
						
						if H_CNT=c_image_end_h then 
							if(V_CNT>0 and V_CNT<c_active_lines) then
								image_line_num<=image_line_num+1;----because the index start from 16
							end if;
						end if; 
					
					---------------------------------------------	
					elsif(ANGLE=DEG_90) then---for 90 degree
						
						if V_CNT=0 then 
							image_line_num<=first_line(ANGLE);
						end if;
					
						if H_CNT=c_image_start_h then 
								image_pixel_num<=first_pixel(ANGLE);
						end if;

						
						if(H_CNT>c_image_start_h-c_image_start_v and H_CNT<c_image_end_h) then----because the index start from 16 in pixels
							image_pixel_num<=image_pixel_num+1;----the index start from 16
						end if; 
						
						if H_CNT=c_image_end_h then 
							if(V_CNT>0 and V_CNT<c_active_lines) then
								image_line_num<=image_line_num-1;----the index start from 511
							end if;
						end if; 
						
					--------------------------------------------------------------------------		
					elsif(ANGLE=DEG_180) then --for 180 degree
						
						
							if V_CNT=0 then 
								image_line_num<=first_line(ANGLE);
							end if;
					
							if H_CNT=c_image_start_h then 
								image_pixel_num<=first_pixel(ANGLE);
							end if;
						
						
						
							if(H_CNT>c_image_start_h and H_CNT<c_image_end_h) then
							image_pixel_num<=image_pixel_num-1;-------the index start from 511
							end if; 
						
							if H_CNT=c_image_end_h then 
								if(V_CNT>0 and V_CNT<c_active_lines) then
									image_line_num<=image_line_num-1;----the index start from 495
								end if;
							end if; 
						
						
					----------------------------------------------------------------------------------		
						
					elsif(ANGLE=DEG_270) then --for 270 degree
						
							if V_CNT=0 then 
								image_line_num<=first_line(ANGLE);
							end if;
					
							if H_CNT=c_image_start_h then 
								image_pixel_num<=first_pixel(ANGLE);
							end if;
						
							if(H_CNT>c_image_start_h and H_CNT<c_image_end_h) then
								image_pixel_num<=image_pixel_num-1;----the index start from 511
							end if; 
						
							if H_CNT=c_image_end_h then 
								if(V_CNT>0 and V_CNT<c_active_lines) then
									image_line_num<=image_line_num+1;----the index start from 0
								end if;
							end if; 
						end if;

--**********************************************************************************************	
					--------- here we send the address to SRAM_A 
					if(ANGLE=0 or ANGLE=2) then 
						SRAM_A<=image_line_num&image_pixel_num; --when angle is 0 or 180 deg
					else 
						SRAM_A<=image_pixel_num&image_line_num;--when angle is 90 or 270 deg
					end if;	
	
	
				end if;-- image_ena_int
			end if;-- main condition 
end if;----rising_edge 
end process;
end architecture;
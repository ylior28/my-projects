library ieee; 
use ieee.std_logic_1164.all;
use work.data_image_package.all;

entity image_processor_tb is        -- The Testbench entity is empty. No ports.
end entity;

architecture behave of image_processor_tb is    -- This is the architecture of the testbench

--------------------------------------------------- constants declaration    
		constant C_CLK_PRD     : time := 20 ns;
		constant    C_image_file		: string := "sec_cols_fixed_lines_mem.bin";

    component image_processor is                -- This is the component declaration.
    port(  
		clk : in std_logic; -- clock
		RSTn : in std_logic; -- reset 
		KEY_ROTATE : in std_logic; 
		SW_ROTATION_DIR: in std_logic; 
		SW_IMAGE_ENA: in std_logic; 
		SW_MODE: in std_logic ;
		SRAM_D : in std_logic_vector (15 downto 0);
		SRAM_A : out std_logic_vector(17 downto 0);
		SRAM_CEn:out std_logic ;
		SRAM_OEn:out std_logic ;
		SRAM_WEn:out std_logic ;
		SRAM_UBn:out std_logic ;
		SRAM_LBn:out std_logic ;
		HDMI_TX :out std_logic_vector (23 downto 0);
		HDMI_TX_DE:out std_logic ;
		HDMI_TX_HS:out std_logic ;
		HDMI_TX_VS:out std_logic ;
		HDMI_TX_CLK:out std_logic ;
		HEX0: out std_logic_vector (6 downto 0);
		HEX1: out std_logic_vector (6 downto 0);
		HEX2: out std_logic_vector (6 downto 0)
		);
    end component;
	
	component sim_sram is
	generic ( ini_file_name: string := "UNUSED");
	port (
		SRAM_ADDR       : in    std_logic_vector(17 downto 0) := (others=>'0');  -- sram address
		SRAM_DQ         : inout std_logic_vector(15 downto 0);  -- sram data
		SRAM_WE_N       : in    std_logic;                      -- sram write enable 
		SRAM_OE_N       : in    std_logic;                      -- sram output enable
		SRAM_UB_N       : in    std_logic;                      -- sram upper byte enable 
		SRAM_LB_N       : in    std_logic;                      -- sram lower byte enable
		SRAM_CE_N       : in    std_logic                       -- sram chip enable
	);
	
	end component;



-- signals declaration  
	signal clk_sig:  std_logic:= '0'; -- clock
	signal RSTn_sig: std_logic:= '0'; -- reset 

	signal KEY_ROTATE_sig:  std_logic:='0'; 
	signal SW_ROTATION_DIR_sig: std_logic:='0'; 
	signal SW_IMAGE_ENA_sig:  std_logic:='0'; 
	signal SW_MODE_sig:  std_logic:='0' ;
	signal SRAM_D_sig :  std_logic_vector (15 downto 0);
	signal SRAM_A_sig :  std_logic_vector(17 downto 0);
	signal SRAM_CEn_sig: std_logic:='0' ;
	signal SRAM_OEn_sig: std_logic:='0' ;
	signal SRAM_WEn_sig: std_logic:='1' ;
	signal SRAM_UBn_sig: std_logic:='0' ;
	signal SRAM_LBn_Sig: std_logic:='0' ;
	signal HDMI_TX_sig : std_logic_vector (23 downto 0);
	signal HDMI_TX_DE_sig: std_logic:='0' ;
	signal HDMI_TX_HS_sig: std_logic:='0' ;
	signal HDMI_TX_VS_sig: std_logic:='0' ;
	signal HDMI_TX_CLK_sig: std_logic:='0' ;
	signal HEX0_sig:  std_logic_vector (6 downto 0);
	signal HEX1_sig:  std_logic_vector (6 downto 0);
	signal HEX2_sig:  std_logic_vector (6 downto 0);
	
    
begin 
   
    dut: image_processor                   
    port map (
        RSTn  => RSTn_sig, 
        clk  => clk_sig, 	
		KEY_ROTATE =>KEY_ROTATE_sig,
		SW_ROTATION_DIR => SW_ROTATION_DIR_sig,
		SW_IMAGE_ENA =>SW_IMAGE_ENA_sig, 
		SW_MODE =>SW_MODE_sig,
		SRAM_D =>SRAM_D_sig,
		SRAM_A => SRAM_A_sig,
		SRAM_CEn =>SRAM_CEn_sig,
		SRAM_OEn =>SRAM_OEn_sig,
		SRAM_WEn => SRAM_WEn_sig,
		SRAM_UBn => SRAM_UBN_SIG,
		SRAM_LBn=> SRAM_LBn_Sig,
		HDMI_TX => HDMI_TX_sig,
		HDMI_TX_DE => HDMI_TX_DE_sig,
		HDMI_TX_HS => HDMI_TX_HS_sig,
		HDMI_TX_VS => HDMI_TX_VS_sig,
		HDMI_TX_CLK => HDMI_TX_CLK_sig,
		HEX0 =>HEX0_sig,
		HEX1 =>HEX1_sig,
		HEX2 =>HEX2_sig
	);
	dut2: sim_sram
	
			
				generic map (ini_file_name=> C_image_file)			
				port map (
					SRAM_ADDR           => SRAM_A_sig,
					SRAM_DQ             => SRAM_D_sig,
					SRAM_WE_N           => SRAM_WEn_sig,
					SRAM_OE_N           => SRAM_OEn_sig,
					SRAM_UB_N           => SRAM_UBN_sig, 
					SRAM_LB_N           => SRAM_LBn_sig,
					SRAM_CE_N           => SRAM_CEn_sig
				);
	---------------------------------------------------------------------------			
    
	
 
   
	clk_sig <= not clk_sig after C_CLK_PRD /2;     -- clk_sig toggles every C_CLK_PRD/2 ns
	RSTn_sig <= '0', '1' after 15 ns; 

 process
	
   begin

    for i in 0 to 10 loop
			KEY_ROTATE_sig<='1' after 0 ns,'0' after 20 ms, '1' after 50 ms, '0' after 100 ms,
			'1' after 200 ms, '0' after 1000 ms, '1' after 5000 ms;
			
			SW_ROTATION_DIR_sig<= '1', '0' after 500 ns, '1' after 100 ms, '0' after 4000 ms;
			
			SW_MODE_sig<= '1', '0' after 20 ns, '1' after 5000 ms;
			
			SW_IMAGE_ENA_sig<='1', '0' after 100 ns, '1' after 1 ms;
        wait for 10000 ms;
    end loop;
	end process;
	end architecture;

library ieee;
use ieee.std_logic_1164.all;
use work.data_image_package.all;
entity controller_tb is        -- The Testbench entity is empty. No ports.
end entity;

architecture behave of controller_tb is    -- This is the architecture of the testbench

-- constants declaration    
    constant C_CLK_PRD     : time := 40 ns;
	
    component controller is                -- This is the component declaration.
    port (
			CLK          : in std_logic; -- clock
			RST          : in std_logic; -- reset 
			VS           : in std_logic; 
			MODE         : in std_logic;
			ROTATE       : in std_logic;
			ROTATION_DIR : in std_logic;
			ANGLE        : out integer range 0 to 3;
			HEX0         : out std_logic_vector(6 downto 0);
			HEX1         : out std_logic_vector(6 downto 0);
			HEX2         : out std_logic_vector(6 downto 0)
    );
    end component;


-- signals declaration  
    signal 		clk_sig 		 : std_logic := '0';
    signal		rst_sig 	 	 : std_logic := '0';
	signal 		VS_sig 			 : std_logic:=  '0';
	signal 		MODE_sig 		 : std_logic;
	signal		ROTATE_sig   	 : std_logic;
	signal		ROTATION_DIR_sig : std_logic;
	signal		ANGLE_sig        : integer range 0 to 3;
	signal		HEX0_Sig         : std_logic_vector(6 downto 0);
	signal		HEX1_sig         : std_logic_vector(6 downto 0);
	signal		HEX2_sig 		 : std_logic_vector(6 downto 0);
    
begin
   
    dut: controller                   
    port map (
        rst  => rst_sig, 
        clk  => clk_sig, 
        VS => VS_sig,
		MODE => MODE_sig,  -- output
		ROTATE=>ROTATE_sig,
		ROTATION_DIR=>ROTATION_DIR_sig,
		ANGLE=>ANGLE_sig,
		HEX0=>HEX0_Sig,
		HEX1=>HEX1_sig,
		HEX2=>HEX2_sig
    );
    
    
    clk_sig <= not clk_sig after C_CLK_PRD /2;     -- clk_sig toggles every C_CLK_PRD/2 ns
    rst_sig <= '0', '1' after 100 ns;  
	VS_sig <='0' after 0 ns ,'1' after  50 ns,  '0' after  5 sec,'1' after  5510 ms; 	
	process
		begin
		  for i in 0 to 10 loop
			 MODE_sig<='1' after 0 ns ,'0' after  4 sec; 
			 ROTATE_sig<='0' after 0 ns ,'1' after  2000 ms;
			 ROTATION_DIR_sig<='0' after 0 ns,  '1' after  3000 ms;
			 wait for 500 ms; 
		  end loop;
		 
		 for i in 0 to 10 loop
			MODE_sig<='0' after 0 ns, '1' after  2 sec; 
			ROTATE_sig<='0' after 0 ns ,'1' after  100 ms,  '0' after  300 ms,'1' after  600 ms,
			'0' after 700 ms ,'1' after  800 ms,  '0' after  1000 ms,'1' after  1100 ms;
			ROTATION_DIR_sig<='0' after 0 ns ,'1' after  500 ms,  '0' after  700 ms,'1' after  1000 ms; 
			 wait for 200 ms; 
		  end loop;
		  wait;
	   end process;
	end architecture;
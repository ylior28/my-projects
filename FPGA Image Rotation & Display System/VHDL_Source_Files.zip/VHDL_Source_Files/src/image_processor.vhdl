library ieee; 
use ieee.std_logic_1164.all;
use work.data_image_package.all;
use ieee.std_logic_unsigned.all;

entity image_processor is 
port(  
clk : in std_logic; -- clock
RSTn : in std_logic; -- reset 
KEY_ROTATE : in std_logic; 
SW_ROTATION_DIR: in std_logic; 
SW_IMAGE_ENA: in std_logic; 
SW_MODE: in std_logic ;
SRAM_A:out  std_logic_vector (17 downto 0);
SRAM_D : in std_logic_vector (15 downto 0);
HDMI_TX :out std_logic_vector (23 downto 0);
HDMI_TX_DE:out std_logic ;
HDMI_TX_HS:out std_logic ;
HDMI_TX_VS:out std_logic ;
HDMI_TX_CLK:out std_logic ;
HEX0: out std_logic_vector (6 downto 0);
HEX1: out std_logic_vector (6 downto 0);
HEX2: out std_logic_vector (6 downto 0);
SRAM_CEn: out std_logic;
SRAM_OEn: out std_logic;
SRAM_WEn: out std_logic;
SRAM_UBn: out std_logic;
SRAM_LBn: out std_logic
);
end entity;

architecture behave of image_processor is 
------------------------------------------------------------------------------
	component timing_generator 
		port(
				CLK    : in 	std_logic;	
				RST	   : in 	std_logic;
				H_SYNC : out 	std_logic;
				V_SYNC : out 	std_logic;
				H_CNT : out 	integer range 0 to c_pixels_per_line-1;
				V_CNT : out 	integer range 0 to c_lines_per_frame-1;
				VS    : out 	std_logic
			);
	end component;
----------------------------------------------------------------------------	
	
	
	component two_flop_synchronizer 
			port(
					D_in : in std_logic; -- D_in input   
					CLK : in std_logic; -- clock 
					RST : in std_logic; -- reset
					Q_out : out std_logic   -- Q output 
				);
	end component;
	
---------------------------------------------------------------------------------
	component push_button 
 
			port(  
					CLK      : in std_logic; -- clock
					RST      : in std_logic; -- reset 
					SW_IN    : in std_logic; 
					PRESS_OUT: out std_logic
				);
	end component; 
	
-------------------------------------------------------------------------------------------
	component controller 
 
				port(  
							CLK          : in std_logic; -- clock
							RST          : in std_logic; -- reset 
							VS           : in std_logic; 
							MODE         : in std_logic;
							ROTATE       : in std_logic;
							ROTATION_DIR : in std_logic;
							ANGLE        : out integer range DEG_0 to DEG_270;
							HEX0         : out std_logic_vector(6 downto 0);
							HEX1         : out std_logic_vector(6 downto 0);
							HEX2         : out std_logic_vector(6 downto 0)
					);
	end component; 
	
-----------------------------------------------------------------------------------------
	component clock_generator
			port (
					refclk   : in  std_logic:= '0';  --  refclk.clk
					rst      : in  std_logic:= '0';  --   reset.reset
					outclk_0 : out std_logic;        -- outclk0.clk
					locked   : out std_logic         --  locked.export
				 );
	end component;

-----------------------------------------------------------------------------------------
	component data_generator
			port(  
					CLK : in std_logic; -- clock
					RST : in std_logic; -- reset 
					ANGLE :in integer   range DEG_0 to DEG_270;  
					IMAGE_ENA : in std_logic; 
					H_CNT : in integer  range 0 to c_pixels_per_line-1;
					V_CNT :in  integer  range 0 to c_lines_per_frame-1;
					SRAM_A : out  std_logic_vector  (17 downto 0); 
					SRAM_D : in   std_logic_vector  (15 downto 0);
					R_DATA : out  std_logic_vector  (7 downto 0); 
					G_DATA : out  std_logic_vector	(7 downto 0);
					B_DATA : out  std_logic_vector  (7 downto 0);
					DATA_DE : out std_logic
				);
	end component;
-----------------------------------------------------------------------------------------	
-------------------------------------------------------------------------------------		
------------------------------------------------------------------------------------------



	
signal rstn_sig,KEY_ROTATE_sig,SW_ROTATION_DIR_sig: std_logic:='0';
signal clk_sig: std_logic:= '0'; 
signal SW_IN_sig:std_logic:='0';
signal H_SYNC_sig:std_logic:='0';
signal V_SYNC_sig:std_logic:='0';
signal H_CNT_sig : integer range 0 to c_pixels_per_line-1;
signal V_CNT_sig : integer range 0 to c_lines_per_frame-1;
signal VS_sig:std_logic:='0';
signal ROTATION_DIR_sig:std_logic:='0';
signal MODE_sig :std_logic:='0';
signal PRESS_OUT_sig:std_logic:='0';
signal ANGLE_sig :integer  range DEG_0 to DEG_270;
signal IMAGE_ENA_sig :std_logic:='0';
signal rstn_pllin :std_logic:='0';



begin
u1: two_flop_synchronizer------syncronizer rotate
	port map(CLK=>clk_sig,
			 RST=> rstn_sig,    
			 D_in=>KEY_ROTATE, 
			 Q_out=>SW_IN_sig  
	);
	
--------------------------------------------------------------

u2: two_flop_synchronizer-------sycronaizer_mode
	port map(CLK=>clk_sig,
			 RST=> rstn_sig,    
			 D_in=>SW_MODE, 
			 Q_out=>MODE_sig  
	);
----------------------------------------------------------
	
u3: two_flop_synchronizer------sycronizer_ROTATION_DIR 
	port map(CLK=>clk_sig,
			 RST=> rstn_sig,    
			 D_in=>SW_ROTATION_DIR, 
			 Q_out=>ROTATION_DIR_sig  
	);	
--------------------------------------------------------

u4: two_flop_synchronizer--------------syncronizer_image_enable 
	port map(CLK=>clk_sig,
			 RST=> rstn_sig,    
			 D_in=>SW_IMAGE_ENA, 
			 Q_out=>IMAGE_ENA_sig  
	);	
---------------------------------------------------------	
	
u5: timing_generator
	port map(CLK=> clk_sig,
			 RST=>rstn_sig, 
			 H_SYNC=>HDMI_TX_HS, 
			 V_SYNC=>HDMI_TX_VS,  
			 H_CNT=>H_CNT_sig,
			 V_CNT=>V_CNT_sig,
			 VS=>VS_sig	 		 
			);

-----------------------------------------------------------------------------

u6: push_button
		port map(
					CLK=>clk_sig, 	
					RST=>rstn_sig, 
					SW_IN=>SW_IN_sig, 
					PRESS_OUT=>PRESS_OUT_sig
				);
	
----------------------------------------------------------------------	
	
	u7: controller
		port map(
				 CLK=>clk_sig, 	
				 RST=>rstn_sig, 
				 VS=>VS_sig, 
				 MODE=>MODE_sig,
				 ROTATE=>PRESS_OUT_sig,      
				 ROTATION_DIR=>ROTATION_DIR_sig,
				 ANGLE=>ANGLE_sig ,      
				 HEX0=>HEX0,        
				 HEX1=>HEX1,       
				 HEX2=>HEX2      
				);
--------------------------------------------------------------	


	u8: clock_generator
		port map(	
					refclk=>CLK,
					rst=>rstn_pllin,
					outclk_0=>clk_sig,
					locked=>rstn_sig
				);
	
------------------------------------------------------------

	u9: data_generator
		port map(	CLK=>clk_sig,
					RST=>rstn_sig,
					ANGLE=>ANGLE_sig,
					IMAGE_ENA=>IMAGE_ENA_sig, 
					H_CNT=>H_CNT_sig,
					V_CNT=>V_CNT_sig,
					SRAM_A=>SRAM_A,
					SRAM_D=>SRAM_D,
					R_DATA=>HDMI_TX(23 downto 16 ),
					G_DATA=>HDMI_TX(15 downto 8),
					B_DATA=>HDMI_TX(7 downto 0),
					DATA_DE=>HDMI_TX_DE
				);
-------------------------------------------------------
HDMI_TX_CLK<=clk_sig;
rstn_pllin<= not RSTn;
SRAM_CEn<='0';
SRAM_OEn<='0';
SRAM_WEn<='1';
SRAM_UBn<='0';
SRAM_LBn<='0';

end behave; 
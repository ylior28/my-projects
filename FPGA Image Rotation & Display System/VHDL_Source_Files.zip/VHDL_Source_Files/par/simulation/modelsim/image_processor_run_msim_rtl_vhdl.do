transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vcom -93 -work work {C:/VHDL/final project/src/data_image_package.vhd}
vcom -93 -work work {C:/VHDL/final project/src/timing_generator.vhdl}

vcom -93 -work work {C:/VHDL/final project/par/../src/timing_generator_tb.vhd}

vsim -t 1ps -L altera -L lpm -L sgate -L altera_mf -L altera_lnsim -L cyclonev -L rtl_work -L work -voptargs="+acc"  timing_generator_tb

add wave *
view structure
view signals
run 10000 us

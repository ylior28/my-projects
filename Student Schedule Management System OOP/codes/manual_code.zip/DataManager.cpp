#include "DataManager.h"

// Checks if a given string is composed entirely of digits (e.g., "123")
bool DataManager::is_number(const string& str)
{
    int len = str.size();
    for (int i = 0;i < len;i++)
    {
        // ASCII check for digits '0' to '9'
        if (str[i] <= '9' && str[i] >= '0')
        {
            continue;
        }
        else// Found non-digit character
        {
            return false;
        }
    }
    return true;
}
// Checks if a string is a valid float representation (e.g., "3.14", "0.5")
// Allows one '.' only and ensures it's not at the beginning or end
bool DataManager::is_float_num(const string& str)
{
    int flag = 0;//To count the number of '.' characters
    int len = str.size();
    for (int i = 0;i < len;i++)
    {
        if (str[i] <= '9' && str[i] >= '0')
        {
            continue;
        }
        else      // Allow one '.' if not first/last character
        {
            if ((str[i] == '.') && (i<(len-1)) && (i>0) && (flag==0))
            {
                flag++;
            }
            else
            {
                return false;// Invalid float
            }
        }
    }
    return true;
}

// Validates and normalizes day names to capitalized format (e.g., "monday" ->"Monday")
string DataManager::is_day(const string& day)
{
    if (day=="sunday"|| day=="Sunday")
    {
        if (day == "sunday")
        {
            return "Sunday";
        }
        return day;
    }
    else if (day== "monday"|| day=="Monday")
    {
        if (day == "monday")
        {
            return "Monday";
        }
        return day;
    }
    else if (day=="tuesday"|| day=="Tuesday")
    {
        if (day == "tuesday")
        {
            return "Tuesday";
        }
        return day;

    }
    else if (day=="wednesday"|| day=="Wednesday")
    {
        if (day == "wednesday")
        {
            return "Wednesday";
        }
        return day;

    }
    else if (day=="thursday"|| day=="Thursday")
    {
        if (day == "thursday")
        {
            return "Thursday";
        }
        return day;

    }
    else if (day== "friday"|| day=="Friday")
    {
        if (day == "friday")
        {
            return "Friday";
        }
        return day;

    }
    else if (day=="saturday"|| day=="Saturday")
    {
        if (day == "saturday")
        {
            return "Saturday";
        }
        return day;

    }
    else
    {
        return "error";// Invalid day
    }
}





//dtor Frees dynamically allocated Lesson objects to prevent memory leaks
DataManager::~DataManager()
{
    vector<Lesson*>::iterator it;
    for (it = lessons_full_data.begin(); it != lessons_full_data.end(); ++it)
    {
        delete* it;// Free each allocated lesson
    }
}


// Loads course data from a CSV file into the vector `courses_full_data`
// Expected CSV Format: id,name,credits,moedA,moedB,lecturer
bool DataManager::loadCoursesFromCSV(const string& filename) 
{
    ifstream file(filename, ios::in);
    if (!file)
    {
        cout<<"Error: cannot open courses file."<<endl;
        return false;
    }
    string line;
    getline(file, line);//skip first line 

    while (getline(file, line)) 
    {
        if (line.empty())
        {
            continue;//no need exeption error for this 
        }
        vector<string> fields;
        string field;

        // separate by "," ("," in csv indicate new tab)
        for (int i = 0; i < line.size(); ++i) 
        {
            if (line[i] == ',') 
            {
                fields.push_back(field);
                field.clear();
            }
            else 
            {
                field += line[i];
            }
        }
        fields.push_back(field); //add last field 

        if (fields.size() != 6) // should be 6 fileds 
        {
            cout <<"Invalid line: " << line << endl;
            throw length_error("Error: incorect line length in course.csv file");
        }


        // first field the course id:
        string id = fields[0];
        if (!is_number(id))
        {
            cout << "Error in line: " <<line<< endl;
            cout<<"file name: "<< filename << endl; 
            throw invalid_argument("course id should be number");
        }
        
        // second field the course name:
        string name = fields[1];

        // third field the course credits:
        string credits = fields[2];
        if (!is_float_num(credits)) 
        {
            cout << "Error in line: " << line << endl; 
            cout << "file name: " << filename << endl; 
            throw invalid_argument("course credits should be number");
        }

        // fourth field the course moed A date:
        string moedA = fields[3];

        // fifth field the course moed B date:
        string moedB = fields[4];

        // sixth field the course lecturer:
        string lecturer = fields[5];
        // Create Course object.
        Course course_fileds(id, name, credits, moedA, moedB, lecturer);
        
        //courses_full_data get data of Course object and store it
        courses_full_data.push_back(course_fileds);
    }

    file.close();
    return true;
}

//get all coruses data 
const vector<Course>& DataManager::getCourses() const
{
    return courses_full_data;
}

// Finds and prints a course by ID
bool DataManager::find_course_by_id(const string& id) 
{
    vector<Course>::const_iterator c_it= courses_full_data.begin();
    for (c_it;c_it!=courses_full_data.end();c_it++) 
    {
        if (c_it->get_Id() == id) 
        {
            cout << *c_it << endl;
            return true;
        }
    }
    cout << "the course with ID:" << id << " not found" << endl;
    return false; 
}


// Finds and prints all lessons associated with a given course ID
bool DataManager::find_lesson_by_cid(const string& id)
{
    int flag = 0;
    vector<Lesson*>::const_iterator c_it = lessons_full_data.begin();
    for (c_it;c_it != lessons_full_data.end();c_it++)
    {
        if ((*c_it)->get_course_id() == id)
        {
            cout << *(*c_it) << endl;
            flag = 1;
        }
    }
    if (flag == 1)
    {
        return true;
    }
    cout << "Erorr Lesson with ID:" << id << " not found (check the file)" << endl;
    return false;
}


// Find a specific lesson by course ID and group ID
Lesson* DataManager::find_lesson(const string& course_id, const string& group_id)
{
    vector<Lesson*>::const_iterator it;
    for (it = lessons_full_data.begin(); it != lessons_full_data.end(); ++it)
    {
        if ((*it)->get_course_id() == course_id && (*it)->get_group_id() == group_id)
        {
            return *it;
        }
    }
    cout << "lesson not found" << endl;
    return nullptr; 
}



// Load lessons from multiple lesson-type CSVs per course
// Each course has three lesson files: courseID_lectures.csv, courseID_tutorials.csv, courseID_labs.csv

bool DataManager::loadLessonsFromCSV(const string& filename_a, const string& filename_b, const string& filename_c)
{
    if (courses_full_data.empty())
    {
        cout << "you sholud first load courses file to load the lessons!" << endl;
        return false;
    }
    //file name not include the course id!(for exmaple 122_lecture.csv write just lecture.csv)
    string lesson_types[] = { filename_a, filename_b, filename_c };

    int len = courses_full_data.size();
    for (int i = 0; i < len; ++i)
    {
        const Course& course_data = courses_full_data[i];
        string course_id = course_data.get_Id();
        // Load all three types for each course
        for (int i = 0; i < 3; i++)
        {
            string filename = course_id + "_" + lesson_types[i];
            ifstream file(filename, ios::in);
            if (!file)
            {
                cout << "warning cannot open " << filename << " file." << endl;
                continue;
            }

            string line;
            getline(file, line); // skip header

            while (getline(file, line))
            {
                if (line.empty())
                {
                    continue;
                }
                vector<string> fields;
                string field;
                // Parse CSV line
                for (int i = 0; i < line.size(); i++)
                {
                    if (line[i] == ',')
                    {
                        fields.push_back(field);
                        field.clear();
                    }
                    else
                    {
                        field += line[i];
                    }
                }
                fields.push_back(field);

                if (fields.size() != 7)
                {
                    cout << "Invalid line: " << line << endl;
                    throw length_error("Incorrect line length in lessons csv");
                }

                string id = fields[0];//course id
                is_number(id);
                if (!is_number(id))
                {
                    cout << "Error in line: " << line << endl;
                    cout << "file name: " << filename << endl;
                    throw invalid_argument("course credits should be number");
                }
                
                string day = fields[1];
                day=is_day(day);///check if this correct day 
                if (day=="error")
                {
                    cout << "Error in line: " << line << endl;
                    cout << "file name: " << filename << endl;
                    throw invalid_argument("wrong day! (check the file)");
                }


                string start_hour = fields[2];
                
                //check if duration is number
                if (!is_number(fields[3]))
                {
                    cout << "Error in line: " << line << endl;
                    cout << "file name: " << filename << endl;
                    throw invalid_argument("duration should be number! (check the file)");
                }
                int duration = stoi(fields[3]);

                //room 
                string room = fields[4];
                //teahcer 
                string teacher = fields[5];
                //group id 
                string group_id = fields[6];
                if (!is_number(group_id))
                {
                    cout << "Error in line: " << line << endl;
                    cout << "file name: " << filename << endl;
                    throw invalid_argument("group should be number!! (check the file)");
                }
                // Create appropriate lesson type
                Lesson* lesson_ptr = nullptr;

                if (lesson_types[i] == "lectures.csv")
                {
                    lesson_ptr = new Lecture(id, day, start_hour, duration, room, teacher, group_id);
                }
                else if (lesson_types[i] == "tutorials.csv")
                {
                    lesson_ptr = new Tutorial(id, day, start_hour, duration, room, teacher, group_id);
                }
                else if (lesson_types[i] == "labs.csv")
                {
                    lesson_ptr = new Lab(id, day, start_hour, duration, room, teacher, group_id);
                }

                if (lesson_ptr != nullptr)
                {
                    lessons_full_data.push_back(lesson_ptr);
                }
            }
            file.close();
        }
    }
    return true;
}

//get all Lessons data 
const vector<Lesson*>& DataManager::getLessons() const
{
    return lessons_full_data;
}


string check_uppercase(const string& day)
{
    if (day == "sunday")
    {
        return "Sunday";
    }
    else if (day == "monday")
    {
        return "Monday";
    }
    else if (day == "tuesday")
    {
        return "Tuesday";
    }
    else if (day == "wednesday")
    {
        return "Wednesday";
    }
    else if (day == "thursday")
    {
        return "Thursday";
    }
    else if (day == "friday")
    {
        return "Friday";
    }
    else if (day == "saturday")
    {
        return "Saturday";
    }
    else
    {
        return day;
    }
}

//third own demanded method: Print all lessons that occur on a specified day (case insensitive)
void DataManager::print_lessons_by_day(const string& day)
{
    string correted_day = check_uppercase(day);
    int flag = 0;
    if (lessons_full_data.empty())
    {
        cout << "the lessons data is empty" << endl;
       return;
    }
    vector<Lesson*>::const_iterator cit;
    for (cit = lessons_full_data.begin(); cit != lessons_full_data.end(); ++cit)
    {
        if ((*cit)->get_day() == correted_day)
        {
            flag = 1;
            cout << *(*cit) << endl;
        }
    }
    if (flag == 0)
    {
        cout << "there are no lessons at: " << day <<"s" << endl;
    }
}
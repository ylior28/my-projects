#ifndef _Lab_H_
#define _Lab_H_
#include "Lesson.h"


using namespace std;


class Lab : public Lesson
{
public:
    //default ctor
    Lab();

    //ctor
    Lab(const string& course_id, const string& day,
        const string& start_hour, int duration,
        const string& room,
        const string& teacher, const string& group_id);
    //dtor
    ~Lab();

    //get 
    string get_lesson_type() const;
};
#endif
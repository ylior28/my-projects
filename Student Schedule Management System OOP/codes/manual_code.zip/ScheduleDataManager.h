#ifndef _ScheduleDataManager_H_
#define _ScheduleDataManager_H_

#include "DataManager.h"

using namespace std;

class ScheduleDataManager {
private:
    vector<Schedule> schedules_array; 
public:

    //dtor
    ~ScheduleDataManager();
    //load schedule file
    bool loadSchedulesFromCSV(const string& filename, DataManager& data_manager);
    //save schedule file
    void SaveSchedulesInCSV(const string& filename);
    //get getSchedules data
    const vector<Schedule>& getSchedules() const;
    // add empty schedule
    void addschedule(Schedule& s);
    //remove schedule
    void removeschedule(int schedule_id);
    //find schedule by id 
    Schedule* find_schedule(int schedule_id);
};
#endif

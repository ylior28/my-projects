#include "Lab.h"

using namespace std;

//default ctor 
Lab::Lab() : Lesson() {}


//ctor
Lab::Lab(const string& course_id, const string& day,
    const string& start_hour, int duration,
    const string& room,
    const string& teacher, const string& group_id)
    :Lesson(course_id, day, start_hour, duration, room, teacher, group_id) {}

//dtor
Lab::~Lab() {}

//get type of lesson
string Lab::get_lesson_type() const
{
    return "Lab";
}
#ifndef _Schedule_H_
#define _Schedule_H_ 

#include "Course.h"
#include "Lecture.h"
#include "Tutorial.h"
#include "Lab.h"
#include <vector>
#include <algorithm>
#include <map>
#include <set>

using namespace std;

class Schedule {
private:
    int s_schedule_id;// number of the schedule
    vector<Lesson*> s_added_lessons;//all lesson that in schedule
    int find_min_stime() const;
    int find_max_stime() const;
public:
    //ctor
    Schedule();
    Schedule(int id);
    
    //dtor 
    ~Schedule();

    //get // //const vector<Lesson*>& getLessons() const;
    int get_schedule_id() const; 
    
    const vector<Lesson*>& get_lessons() const;
    //vector<Lesson*>& get_lessons();
    
    // set
    void set_schedule_id(int id); 

    //add lesson (lecture/tutorial/lab)
    void addLesson(Lesson* lesson);
    
    // remove lesson by group and course id 
    void removeLesson(const string& course_id, const string& group_id);
    
    //print schedule as table 
    friend ostream& operator<<(ostream& os, const Schedule& s);

    //first demand method: print overlaps lessons in the schedule;
    void print_overlap_lessons();
    //second own demanded method: print the sum of credits in the schedule;
    void print_total_credits(const vector<Course>& courses);
};

#endif

#include "Lecture.h"


using namespace std;
//default ctor 
Lecture::Lecture() : Lesson() {}

//ctor
Lecture::Lecture(const string& course_id, const string& day,
    const string& start_hour, int duration,
    const string& room,
    const string& teacher, const string& group_id)
    :Lesson(course_id, day, start_hour, duration, room, teacher, group_id) {}

//dtor
Lecture::~Lecture() {}

//get type of lesson
string Lecture::get_lesson_type() const
{
    return "Lecture";
}
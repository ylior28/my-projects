#include "Schedule.h"
//ctor
Schedule::Schedule() : s_schedule_id(0) {}

Schedule::Schedule(int id) : s_schedule_id(id) {}

//dtor: no explicit cleanup needed here, lessons are managed elsewhere 
Schedule::~Schedule() {}
//get number of schedule 
int Schedule::get_schedule_id() const
{
    return s_schedule_id;
}

// Const getter: returns const reference to the vector of added lessons
const vector<Lesson*>& Schedule::get_lessons() const
{
    return s_added_lessons; 
}


// Setter: sets the schedule ID
void Schedule::set_schedule_id(int id)
{
    s_schedule_id = id;
}

// Adds a new lesson to the schedule if it doesn�t already exist (based on course + group ID)
void Schedule::addLesson(Lesson* lesson)
{
    vector<Lesson*>::iterator it;
    string lc = lesson->get_course_id(), lg = lesson->get_group_id();
    for ( it = s_added_lessons.begin(); it != s_added_lessons.end(); ++it)  
    {
        if ((*it)->get_course_id()==lc && (*it)->get_group_id()==lg)
        {
            cout << "lesson already exists in schedule" << endl;
            return;
        }
    }
    s_added_lessons.push_back(lesson); //add the lesson to the end of the vector
}

// Removes a lesson from the schedule based on course and group ID
void Schedule::removeLesson(const string& course_id, const string& group_id)
{
    vector<Lesson*>::iterator it;
    it = s_added_lessons.begin(); 
    while(it != s_added_lessons.end())
    {
        if ((*it)->get_course_id() == course_id && (*it)->get_group_id() == group_id) 
        {
            it = s_added_lessons.erase(it);
            cout << "The lesson was successfully deleted." << endl;
            break;
        }
        else 
        {
            ++it;
        }
    }
}

// Validates that a character is a digit between '0' and '9'

void check_legal_digit(const char& digit)
{
    if (digit < '0' || digit>'9')
    {
        throw invalid_argument("illegal digit in start time");
    }
}
// Converts string time format (e.g. "08:30") into integer (e.g. 830)

int stime_to_int(const string& stime)
{
    int len = (int)stime.size();
    // Basic validation on format (must include ':' and be 4 or 5 characters long)
    if ((len != 5 && stime[2] != ':')&& (stime[1] != ':' && len != 4))
    {
        throw invalid_argument("wrong start time string, should contain ':' and be length 4 or 5!");
    }
    int digit = 0;
    int num = 0;
    int thousend = 1000;
    int hundred = 100;
    if (len == 5)
    {
        for (int i = 0;i < len;i++)
        {
            if (i != 2)
            {
                check_legal_digit(stime[i]);
                digit = stime[i] - '0';
                num += thousend * digit;
                thousend = thousend / 10;
            }
        }

    }
    else
    {
        for (int i = 0;i < len;i++)
        {
            if (i != 1)
            {
                check_legal_digit(stime[i]);
                digit = stime[i] - '0';
                num += hundred * digit;
                hundred = hundred / 10;
            }
        }
    }
    return num;
}

// Finds the minimum (earliest) start time of all lessons in the schedule
int Schedule::find_min_stime() const
{
    if (s_added_lessons.empty()) 
    {
        return 0;  
    }

    vector<Lesson*>::const_iterator c_it = s_added_lessons.begin();

    int min_time = stime_to_int((*c_it)->get_start_hour());
    ++c_it;

    for (c_it; c_it != s_added_lessons.end(); ++c_it)
    {
        int current_time = stime_to_int((*c_it)->get_start_hour());
        if (current_time < min_time)
        {
            min_time = current_time;
        }
    }
    return (min_time);
}

// Finds the maximum (latest end) time among all lessons in the schedule
int Schedule::find_max_stime() const
{
    if (s_added_lessons.empty())
    {
        return 0; 
    }

    vector<Lesson*>::const_iterator c_it = s_added_lessons.begin();

    int max_time = stime_to_int((*c_it)->get_start_hour());
    int duration = ((*c_it)->get_duration()) * 100;
    max_time = max_time + duration;
    ++c_it;

    for (c_it; c_it != s_added_lessons.end(); ++c_it)
    {
        int current_time = stime_to_int((*c_it)->get_start_hour());
        duration = ((*c_it)->get_duration())*100;
        if ((current_time+duration) > max_time)
        {
            max_time = current_time+ (duration);
        }
    }
    return (max_time);
}





//print table 
ostream& operator<<(ostream& os, const Schedule& s)
{
    os << "schedule id: " << s.get_schedule_id() << "\n" << endl;
    const vector<string> days = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday","Saturday" };
    vector<string>::const_iterator c1_it;

    //find min start lesson hour and max start lesson hour 
    int min_stime = s.find_min_stime(); 
    int max_stime = s.find_max_stime();

    //Build a map: Construct table of lessons: map[day][hour] -> lessons
    map<string, map<int, vector<const Lesson*>>> schedule_table;
    vector<Lesson*>::const_iterator c2_it;
    for (c2_it = s.s_added_lessons.begin(); c2_it != s.s_added_lessons.end(); ++c2_it)
    {
        const Lesson* lesson = *c2_it;
        string day = lesson->get_day();
        int start_hour = stime_to_int(lesson->get_start_hour()) / 100;

        for (int i = 0; i < lesson->get_duration(); ++i)
        {
            schedule_table[day][start_hour + i].push_back(lesson);
        }
    }
    
    // Print table header (days)
    os << "Hour ";
    for (c1_it = days.begin(); c1_it != days.end(); ++c1_it) 
    {
        int ds_size = (int)(*c1_it).size();
        //print days in the first row 
        if (ds_size == 6)
        {
            os << "         " << *c1_it << "         ";
        }
        else if (ds_size == 7)
        {
            os << "         " << *c1_it << "        ";
        }
        else if (ds_size == 8)
        {
            os << "        " << *c1_it <<"        ";
        }
        else
        {
            os << "        " << *c1_it << "       ";
        }
    }
    os << "\n"<<endl;
    int minute_stime = min_stime%100;
    min_stime = min_stime / 100;
    max_stime = max_stime / 100;
    for (int hour =min_stime; hour <= max_stime; ++hour)
    {
        if (hour < 10)
        {
            os<<" "<< hour << ":" << minute_stime << " "; //print houre for firts column
        }
        else
        {
            os << hour << ":" << minute_stime << " "; //print houre for firts column
        }
        if (hour == 11)
        {
            minute_stime = 50;
        }
        // Determine max number of overlapping lessons at this hour
        int max_overlap = 1;
        int count = 0; 
        vector<string>::const_iterator day_cit; 
        for (day_cit = days.begin(); day_cit != days.end(); ++day_cit)
        {
            if (schedule_table[*day_cit].count(hour) > 0)
            {
                count = (int)schedule_table[*day_cit][hour].size();
            }
            if (count > max_overlap)
            {
                max_overlap = count;
            }
        }

        for (int line = 0; line < max_overlap; ++line)
        {
            if (line >= 1)
            {
                os << "      ";
            }
            for (day_cit = days.begin(); day_cit != days.end(); ++day_cit)
            {
                if (schedule_table[*day_cit].count(hour)>0)
                {
                    // Assign to a shorter name(lessons) for convenience instead of repeating the full expression 
                    const vector<const Lesson*>& lessons = schedule_table[*day_cit][hour];
                    if (line < lessons.size())
                    {
                        //const Lesson* sl_data = lessons[line];//specific lesson data
                        string info = "[" + lessons[line]->get_course_id();
                        info = info + "," + lessons[line]->get_lesson_type();
                        info= info+"," +lessons[line]->get_room() + "]  ";
                        int infosize = (int)info.size();
                        while (infosize < 24)
                        {
                            info = info + " ";
                            infosize++;
                        }
                        os << info;
                    }
                    else
                    {
                        if (line > 0)
                        {
                            os << "                        ";
                        }
                    }
                }
                else
                {
                    os << "                        ";
                }
            }
            os << endl;
        }
    }
    return os;
}

//first own demanded method: print overlaps lessons in the schedule;
void Schedule::print_overlap_lessons()
{
    if (s_added_lessons.empty())
    {
        cout << "there no lesson in this schedule>";
        return;
    }
    cout << "schedule id: " << get_schedule_id() << "\n" << endl;
    const vector<string> days = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday","Saturday" };
    vector<string>::const_iterator c1_it;

    //find min start lesson hour and max start lesson hour 
    int min_stime = find_min_stime();
    int max_stime = find_max_stime();

    //Build a map: day > hour > list of lessons, sorted by time (put in same key but differet lesson )
    map<string, map<int, vector<const Lesson*>>> schedule_table;
    vector<Lesson*>::const_iterator c2_it;
    for (c2_it = s_added_lessons.begin(); c2_it != s_added_lessons.end(); ++c2_it)
    {
        const Lesson* lesson = *c2_it;
        string day = lesson->get_day();
        int start_hour = stime_to_int(lesson->get_start_hour()) / 100;

        for (int i = 0; i < lesson->get_duration(); ++i)
        {
            schedule_table[day][start_hour + i].push_back(lesson);
        }
    }
    min_stime = min_stime / 100;
    max_stime = max_stime / 100;
    int flag = 0;//to indicate if there no lesson overlap in the schedule
    for (int hour = min_stime; hour <= max_stime; ++hour)
    {
        int max_overlap = 1;
        int count = 0;
        vector<string>::const_iterator day_cit;
        for (day_cit = days.begin(); day_cit != days.end(); ++day_cit)
        {
            count = 0;
            if (schedule_table[*day_cit].count(hour) > 0)
            {
                count = (int)schedule_table[*day_cit][hour].size();
            }
            if (count > max_overlap)//there overlap lesson if true  
            {
                flag = 1;
                const vector<const Lesson*>& lessons = schedule_table[*day_cit][hour];
                for (int i = 0;i < count;i++) 
                {
                    cout << *lessons[i] << endl; //print all lesson with overlap
                }
            }
        }
    }
    if (flag == 0)
    {
        cout << "there no overlap lessons in this schedule" <<endl;
    }
}

//second own demanded method: Calculates and prints the total number of credits;
void Schedule::print_total_credits(const vector<Course>& s_courses)
{
    if (s_added_lessons.empty())
    {
        cout << "There are no lessons in this schedule." << endl;
        return;
    }

    //using set to insert course id once and not insert same course id 
    set<string> cid_schedule;//coruse id in schedule
    vector<Lesson*>::const_iterator c_it;
    for (c_it = s_added_lessons.begin(); c_it != s_added_lessons.end(); ++c_it)
    {
        cid_schedule.insert((*c_it)->get_course_id());
    }
    
    float total_credits = 0;
    vector<Course>::const_iterator cit;
    for (cit = s_courses.begin(); cit != s_courses.end(); ++cit)
    {
        if (cid_schedule.count(cit->get_Id()) > 0)
        {
            total_credits += stof(cit->get_Credits());
        }
    }
    cout << "Total credits in this schedule: " << total_credits << endl;
}
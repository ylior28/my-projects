#ifndef _Lesson_H_
#define _Lesson_H_
#include <string>
#include <iostream>

using namespace std;

class Lesson {
private:
    string l_course_id;
    string l_day;
    string l_start_hour;// from 00 to 23
    int l_duration;// hours unit
    string l_room;// include number of room and building 
    string l_teacher;
    string l_group_id;

public:

    //default Constructor
    Lesson();

    //ctor
    Lesson(const string& course_id, const string& day,
        const string& start_hour, int duration,
        const string& room, 
        const string& teacher, const string& group_id);
    
    //dtor
    virtual ~Lesson();

    //pure virtual to get type of the lesson
    virtual string get_lesson_type() const = 0;

    //getters
    string get_course_id()const;
    string get_day() const;
    string get_start_hour()const;
    int get_duration()const;
    string get_room() const;
    string get_teacher() const;
    string get_group_id()const;

    // setters
    void set_course_id(const string& course_id);
    void set_day(const string& day);
    void set_start_hour(const string &hour);
    void set_duration(int duration);
    void set_room(const string& room);
    void set_teacher(const string& teacher);
    void set_group_id(const string& group_id);

    //Operator << (print)
    friend ostream& operator<<(ostream& os, const Lesson& lesson);
};
#endif 
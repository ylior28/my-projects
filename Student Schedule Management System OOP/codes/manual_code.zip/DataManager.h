#ifndef _DataManager_H_
#define _DataManager_H_


#include <fstream>
#include <stdexcept>
#include "Schedule.h"

using namespace std;

class DataManager {
private:
    vector<Course> courses_full_data;
    vector<Lesson*> lessons_full_data;
public:
    //open course.csv file then load all data and save it. 
    bool loadCoursesFromCSV(const string& filename);

    ~DataManager();


    //open (lectures.csv,tutorials.csv,labs.csv) files then load all data and save it. 
    bool loadLessonsFromCSV(const string& filename_a, const string& filename_b, const string& filename_c);
    //find course by id and print the details if found
    bool find_course_by_id(const string& id);
    //find lesson by course id and print the details if found
    bool find_lesson_by_cid(const string& id);
    Lesson* find_lesson(const string& course_id, const string& group_id);

    //get all data 
    const vector<Course>& getCourses() const;
    const vector<Lesson*>& getLessons() const;

    //third own demanded method: print the list of the lessons by choosen day;
    void print_lessons_by_day(const string& day);


    //check fileds
    bool is_number(const string& str);
    bool is_float_num(const string& str);
    string is_day(const string& day);


};

#endif




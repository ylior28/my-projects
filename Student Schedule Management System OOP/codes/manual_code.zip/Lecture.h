#ifndef _Lecture_H_
#define _Lecture_H_
#include "Lesson.h"

using namespace std;


class Lecture : public Lesson 
{
public:
    //default ctor
    Lecture();
    //ctor
    Lecture(const string& course_id, const string& day,
        const string& start_hour, int duration,
        const string& room,
        const string& teacher, const string& group_id);
    //dtor
    ~Lecture(); 
    
    //get 
    string get_lesson_type() const;
};
#endif

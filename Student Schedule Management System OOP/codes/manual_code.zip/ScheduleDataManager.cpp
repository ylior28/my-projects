#include "ScheduleDataManager.h"



//dtor
ScheduleDataManager::~ScheduleDataManager(){}

// Load schedules from CSV file and associate lessons with schedules
bool ScheduleDataManager::loadSchedulesFromCSV(const string& filename, DataManager& data_manager)
{


    ifstream file(filename, ios::in);
    if (!file)
    {
        cout << "cannot open schedules file.(the file may not exist)" << endl;
        return false;
    }

    string line;
    getline(file, line); // skip header

    vector<Schedule> schedules;
    int current_schedule_id = 0;
    Schedule* current_schedule = nullptr;

    // Read each line (representing a lesson)
    while (getline(file, line)) 
    {
        
        if (line.empty())
        {
            continue;
        }

        vector<string> fields;
        string field;
        // separate by "," ("," in csv indicate new tab)
        for (int i = 0; i < line.size(); ++i)
        {
            if (line[i] == ',')
            {
                fields.push_back(field);
                field.clear();
            }
            else
            {
                field += line[i];
            }
        }
        fields.push_back(field); // last field

        if (fields.size() != 9) // should be 9 fileds 
        {
            cout << "Invalid line: " << line << endl;
            throw length_error("Error: incorect line length in course.csv file");
        }
    
        DataManager check_fields;
        //check if schedule_id is number
        if (!(check_fields.is_number(fields[0])))
        {
            cout << "Error in line: " << line << endl;
            cout << "file name: " << filename << endl;
            throw invalid_argument("schedule id should be number!");
        }
        int schedule_id = stoi(fields[0]);

        //lesson type
        string lesson_type = fields[1];

        //course id
        string course_id = fields[2];
        if (!(check_fields.is_number(course_id))) 
        {
            cout << "Error in line: " << line << endl;
            cout << "file name: " << filename << endl;
            throw invalid_argument("course id should be number!");
        }
        //lesson day 
        string day = fields[3];
        day = check_fields.is_day(day);
        if (day=="error")
        {
            cout << "Error in line: " << line << endl;
            cout << "file name: " << filename << endl;
            throw invalid_argument("wrong day! (check the file)");
        }
        //start hour
        string start_hour = fields[4];

        //check duration field if its number
        if (!(check_fields.is_number(fields[5]))) 
        {
            cout << "Error in line: " << line << endl;
            cout << "file name: " << filename << endl;
            throw invalid_argument("duration should be number!");
        }
        int duration = stoi(fields[5]);

        //room 
        string room = fields[6];
        //thaecher
        string teacher = fields[7];
        //check if group id is number
        string group_id = fields[8];
        if (!(check_fields.is_number(group_id))) 
        {
            cout << "Error in line: " << line << endl;
            cout << "file name: " << filename << endl;
            throw invalid_argument("group id should be number!");
        }
       
        // Locate the lesson pointer from DataManager
        Lesson* lesson = data_manager.find_lesson(course_id, group_id);
        if (!lesson)
        {
            cout << "Lesson not found for course " << course_id << " group " << group_id << endl;
            throw invalid_argument("Error the lesson should type of (lecture,tutorial,lab) only");
        }
        // If it's a new schedule ID, create a new schedule object

        if (schedule_id != current_schedule_id) 
        {
            schedules.push_back(Schedule(schedule_id));
            current_schedule = &schedules.back();
            current_schedule_id = schedule_id;
        }

        current_schedule->addLesson(lesson);
    }

    file.close();
    schedules_array = schedules; //save all schedules 
    return true;
}


// Getter for loaded schedules

const vector<Schedule>& ScheduleDataManager::getSchedules() const
{
    return schedules_array;
}

// Save current in-memory schedules to a CSV file

void ScheduleDataManager::SaveSchedulesInCSV(const string& filename) 
{
    ofstream out(filename, ios::trunc);
    if (!out)
    {
        cout << "Cannot open/create file " << filename << " for writing." << endl;
        throw runtime_error("Error: failed open/create file");
    }

    //write Header line
    out << "schedule_id,lesson_type,course_id,day,start_hour,duration,room,teacher,group_id\n";

    vector<Schedule>::const_iterator s_cit;
    // Write each lesson in each schedule

    for (s_cit = schedules_array.begin(); s_cit != schedules_array.end(); ++s_cit)
    {
        int schedule_id = s_cit->get_schedule_id();
        
        const vector<Lesson*>& lessons = s_cit->get_lessons();
        vector<Lesson*>::const_iterator l_cit;
        for (l_cit = lessons.begin(); l_cit != lessons.end(); ++l_cit)
        {
            const Lesson* lesson = *l_cit;
            out << schedule_id << ","
                << lesson->get_lesson_type() << ","
                << lesson->get_course_id() << ","
                << lesson->get_day() << ","
                << lesson->get_start_hour() << ","
                << lesson->get_duration() << ","
                << lesson->get_room() << ","
                << lesson->get_teacher() << ","
                << lesson->get_group_id()
                << "\n";
        }
    }
    out.close();
}
// Add a new schedule, ensuring unique and incremental IDs
void ScheduleDataManager::addschedule(Schedule& new_schedule)
{
    int new_id = new_schedule.get_schedule_id();

    if (schedules_array.empty())
    {
        // If first schedule, force ID to 1

        if (new_id != 1)
        {
            new_schedule.set_schedule_id(1);
        }
        schedules_array.push_back(new_schedule);
    }
    else
    {
        // Force ID to be next available index

        int max_id=(schedules_array.size() + 1);

        if (max_id == new_id)
        {
            schedules_array.push_back(new_schedule);
        }
        else
        {
            new_schedule.set_schedule_id(max_id);
            schedules_array.push_back(new_schedule);
        }
    }
}

// Remove schedule by ID and adjust subsequent IDs

void ScheduleDataManager::removeschedule(int schedule_id)
{
    if (schedules_array.empty()) 
    { 
        cout << "no schedules to remove." << endl;
        return;
    }
    bool found_schedule = false;
    int new_id = 1;
    vector<Schedule>::iterator it = schedules_array.begin();
    while(it != schedules_array.end())
    {
        if (it->get_schedule_id() == schedule_id)
        {
            it = schedules_array.erase(it);
            found_schedule = true;
            continue;
        }
        if (found_schedule)
        { 
            // Renumber following schedules
            it->set_schedule_id(new_id);
        }
        new_id++;
        it++;
    }

    if (!found_schedule)
    {
        cout << "schedule id not found for deletion" << endl;
    }
}
// Find and return a pointer to a schedule by ID

Schedule* ScheduleDataManager::find_schedule(int schedule_id)
{
    if (schedules_array.empty())
    {
        cout << "schedules not exist." << endl;
        return nullptr;
    }
    if (schedule_id <= 0 || schedule_id > schedules_array.size())
    {
        cout << "schedule for id: " << schedule_id << " not found" << endl;
        return nullptr;
    }
    return &schedules_array[schedule_id - 1]; 
}
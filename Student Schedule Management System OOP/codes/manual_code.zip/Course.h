#ifndef _Course_H_
#define _COURSE_H_
#include <string>
#include <iostream>

using namespace std;


class Course {
private:
    string c_id;
    string c_name;
    string c_credits;
    string c_moedA_date;
    string c_moedB_date;
    string c_lecturer;

public:
    //default
    Course();
    // Constructor
    Course(const string& id, const string& name, const string& credits,
        const string& moed_A, const string& moed_B,
        const string& lecturer);//ctor 
    ~Course();//dtor

    // Getters
    string get_Id() const;
    string get_Name() const;
    string get_Credits() const;
    string get_MoedA_date() const;
    string get_MoedB_date() const;
    string get_Lecturer() const;

    // Setters
    void set_Id(const string& id);
    void set_Name(const string& name);
    void set_Credits(const string& credits); 
    void set_MoedA_date(const string& dateA);
    void set_MoedB_date(const string& dateB);
    void set_Lecturer(const string& lecturer);

    // Operator << (print)
    friend ostream& operator<<(ostream& os, const Course& course);
};

#endif 


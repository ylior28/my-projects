#include "Lesson.h"
using namespace std;


//default Constructor
Lesson::Lesson() :l_course_id("0"), l_day("default_day"), l_start_hour("00"),
l_duration(0), l_room("default_room"),
l_teacher("default_teacher"), l_group_id("0") {}



// constructor
Lesson::Lesson(const string& course_id, const string& day, const string& start_hour, int duration,
    const string& room,const string& teacher, const string& group_id):
    l_course_id(course_id), l_day(day), l_start_hour(start_hour), l_duration(duration),
    l_room(room), l_teacher(teacher), l_group_id(group_id){}

//dtor
Lesson::~Lesson() {}

//getters
string Lesson::get_course_id() const
{
    return l_course_id;
}
string Lesson::get_day() const
{
    return l_day;
}
string Lesson::get_start_hour()const
{
    return l_start_hour;
}
int Lesson::get_duration()const
{
    return l_duration;
}
string Lesson::get_room() const
{
    return l_room;
}
string Lesson::get_teacher() const
{
    return l_teacher;
}
string Lesson::get_group_id()const
{
    return l_group_id;
}

//setters
void Lesson::set_course_id(const string& course_id)
{
    l_course_id = course_id; 
}
void Lesson::set_day(const string& day)
{
    l_day = day;
}
void Lesson::set_start_hour(const string& hour)
{
    l_start_hour= hour;
}
void Lesson::set_duration(int duration)
{
    l_duration = duration;
}
void Lesson::set_room(const string& room)
{
    l_room = room;
}
void Lesson::set_teacher(const string& teacher)
{
    l_teacher = teacher;
}
void Lesson::set_group_id(const string& group_id)
{
    l_group_id = group_id;
}


// operator << (print)
ostream& operator<<(ostream& os, const Lesson& lesson) 
{
    os << "Type of lesson: " << lesson.get_lesson_type();
    os << ", course id: " << lesson.get_course_id();
    os << ", day: " << lesson.get_day();
    os << ", strat hour: " << lesson.get_start_hour();
    os << ", duration: " << lesson.get_duration();
    os << ", room and building: " << lesson.get_room();
    os << ", teacher name: " << lesson.get_teacher();
    os << ", groupe id: " << lesson.get_group_id();
    return os;
}

#ifndef _Tutorial_H_
#define _Tutorial_H_
#include "Lesson.h"

using namespace std;


class Tutorial : public Lesson 
{
public:
    //default ctor
    Tutorial();

    //ctor
    Tutorial(const string& course_id, const string& day,
        const string& start_hour, int duration,
        const string& room,
        const string& teacher, const string& group_id);
    //dtor
    ~Tutorial();

    //get 
    string get_lesson_type() const;
};
#endif

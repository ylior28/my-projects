#include"Course.h"


using namespace std;
//default Constructor
Course::Course() :c_id("0"), c_name("N_default"),
    c_credits("0"), c_moedA_date("0/0/0"),
    c_moedB_date("0/0/0"), c_lecturer("L_default") {}


// Constructor
Course::Course(const string& id, const string& name, const string& credits,
        const string& moed_A, const string& moed_B,
        const string& lecturer) :c_id(id), c_name(name),
        c_credits(credits), c_moedA_date(moed_A),
        c_moedB_date(moed_B), c_lecturer(lecturer) {}

//dtor
Course::~Course() {}

// Getters

string Course::get_Id() const
{
    return c_id;
}
string Course::get_Name() const
{
    return c_name;
}
string Course::get_Credits() const
{
    return c_credits;
}
string Course::get_MoedA_date() const
{
    return c_moedA_date;
}
string Course::get_MoedB_date() const
{
    return c_moedB_date;
}
string Course::get_Lecturer() const
{
    return c_lecturer;
}
// Setters

void Course::set_Id(const string& id)
{
    c_id = id;
}

void Course::set_Name(const string& name)
{
    c_name = name;
}
void Course::set_Credits(const string& credits)
{
    c_credits = credits;
}
void Course::set_MoedA_date(const string& dateA)
{
    c_moedA_date = dateA;
}
void Course::set_MoedB_date(const string& dateB)
{
    c_moedB_date = dateB;
}
void Course::set_Lecturer(const string& lecturer)
{
    c_lecturer = lecturer;
}

// Operator << (print)
ostream& operator<<(ostream& os, const Course& course)
{
    os << "course id: " << course.get_Id();
    os <<", course name: " << course.get_Name();
    os << ", course credits: " << course.get_Credits();
    os << ", course Moed A date: " << course.get_MoedA_date();
    os << ", course Moed B date: " << course.get_MoedB_date();
    os << ", course lecturer: " << course.get_Lecturer() << endl;
    return os;
}
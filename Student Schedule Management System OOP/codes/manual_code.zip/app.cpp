#include <sstream>
#include "ScheduleDataManager.h"
#include <crtdbg.h>
#include <cassert>
#define _CRT_SECURE_NO_WARNINGS

using namespace std;


bool is_number(const string& str) 
{
	int len = str.size();
	if (str.empty())
	{
		return false;
	}
	for (int i=0;i<len;i++) 
	{
		if (str[i] <= '9' && str[i] >= '0')
		{
			continue;
		}
		else
		{
			return false;
		}
	}

	return true; 
}



void app()
{
	DataManager data_manager; 
	ScheduleDataManager schedule_data_Manager; 

	//____________load all files____________\\

	//load all courses:
	if (!data_manager.loadCoursesFromCSV("courses.csv"))
	{
		return;
	}
	//load all lessons files:
	if (!data_manager.loadLessonsFromCSV("lectures.csv", "tutorials.csv", "labs.csv"))
	{
		return;
	}
	//load schedules if the file exist
	if (!schedule_data_Manager.loadSchedulesFromCSV("schedule.csv", data_manager))
	{
		cout << "if you didnt create the file yet ignore its just a warning" << endl;
	}

	cout << "Welcome to the schedule management System!" << endl;
	cout << "Type commands. Type 'exit' to quit." << endl;//please edit info for user 

	int more_flag = 0;// just avoid "unrecognize command" on command when i use printcourses command 
	while (true)
	{
		string line;
		string command;
		string first_value; //next word after the command 
		string second_value;//next word after the first_value
		string third_value;//next word after the second_value
		getline(cin, line);
		stringstream ss(line);
		ss >> command;
		ss >> first_value;
		ss >> second_value;
		ss >> third_value;

		if (command == "exit")
		{
			break;
		}

		else if (command == "printcourse" || command == "PrintCourse")
		{
			//PrintCourse <course_id>
			data_manager.find_course_by_id(first_value);
			data_manager.find_lesson_by_cid(first_value);
		}
		else if (command == "PrintCourses" || command == "printcourses")
		{
			//PrintCourses
			const vector<Course>& courses = data_manager.getCourses();
			string command_more;
			vector<Course>::const_iterator cit = courses.begin();
			int count = 0;//count current num of courses we have printed 
			for (cit = courses.begin(); cit != courses.end(); ++cit)
			{
				count++;
				if (count <= 10)
				{
					cout << *cit << endl;
					//data_manager.find_lesson_by_cid(cit->get_Id());
					cout << "" << endl;
				}
				else
				{
					if ((count - 1) % 10 == 0)
					{
						cout << "if you want print more courses write More else write stop" << endl;
						cin >> command_more; 
					}
					if (command_more == "more" || command_more == "More")
					{
						more_flag = 1;
						cout << *cit << endl;
						//data_manager.find_lesson_by_cid(cit->get_Id());
						cout<<""<<endl;
					}
					else
					{
						if (command_more == "stop")
						{
							more_flag = 1;
						}
						break;
					}
				}
			}
			if (cit == courses.end())
			{
				cout << "there no more courses in the file" << endl;
			}
		}

		else if (command == "PrintSchedule" || command == "printschedule")
		{
			//PrintSchedule <schedule_id>
			int id = 0;
			int flag = 0;
			if (!is_number(first_value))
			{
				cout << "Error: id should be positive number please try again" << endl;
				continue;
			}
			else
			{
				id = stoi(first_value);
			}
			if (id <= 0)
			{
				cout << "Error: id cant be small than 1!" << endl;
				continue;
			}
			int schedules_id = stoi(first_value);
			Schedule* schedule_ptr = schedule_data_Manager.find_schedule(schedules_id);
			if (schedule_ptr == nullptr)
			{
				continue;
			}
			cout << *schedule_ptr << endl;
		}

		else if (command == "PrintSchedules" || command == "printschedules")
		{
			//PrintSchedules
			const vector<Schedule>& schedules_data = schedule_data_Manager.getSchedules();
			if (schedules_data.size() == 0)
			{
				cout << "the schedules are not exists" << endl;
				continue;
			}
			vector<Schedule>::const_iterator cit;
			for (cit = schedules_data.begin(); cit != schedules_data.end(); ++cit)
			{
				cout << *cit << endl;
			}
		}
		else if (command == "AddSchedule" || command == "addschedule")
		{
			//AddSchedule
			Schedule new_schedule;
			schedule_data_Manager.addschedule(new_schedule);
		}

		else if (command == "RmSchedule" || command == "rmschedule")
		{
			//RmScedule <schedule_id>
			int id = 0;
			if (!is_number(first_value))
			{
				cout << "Error: id should be positive number please try again" << endl;
				continue;
			}
			else
			{
				id = stoi(first_value);
			}
			if (id <= 0)
			{
				cout << "Error: id cant be small than 1!" << endl;
				continue;
			}
			int schedules_id = stoi(first_value);
			schedule_data_Manager.removeschedule(schedules_id);
		}
		else if (command == "Add" || command == "add")
		{
			//Add <schedule_id> <course_id> <group_id>
			int id = 0;
			if (!is_number(first_value))
			{
				cout << "Error: id should be positive number please try again" << endl;
				continue;
			}
			else
			{
				id = stoi(first_value);
			}
			if (id <= 0)
			{
				cout << "Error: id cant be small than 1!" << endl;
				continue;
			}
			int schedules_id = stoi(first_value);
			Lesson* lessonptr = data_manager.find_lesson(second_value, third_value);
			Schedule* scheduleptr = schedule_data_Manager.find_schedule(schedules_id);
			if (lessonptr == nullptr || scheduleptr == nullptr)
			{
				continue;
			}
			scheduleptr->addLesson(lessonptr);
		}
		else if (command == "Rm" || command == "rm")
		{
			//Rm <schedule_id> <course_id> <group_id>
			int id = 0;
			if (!is_number(first_value))
			{
				cout << "Error: id should be positive number please try again" << endl;
				continue;
			}
			else
			{
				id = stoi(first_value);
			}
			if (id <= 0)
			{
				cout << "Error: id cant be small than 1!" << endl;
				continue;
			}
			int schedules_id = stoi(first_value);
			Schedule* scheduleptr = schedule_data_Manager.find_schedule(schedules_id);
			if (scheduleptr == nullptr)
			{
				continue;
			}
			scheduleptr->removeLesson(second_value, third_value);
		}
		else if (command == "totalcredits" || command == "TotalCredits")
		{
			//totalcredits <schedule_id>
			int idt = 0;
			if (!is_number(first_value))
			{
				cout << "Error: id should be positive number please try again" << endl;
				continue;
			}
			else
			{
				idt = stoi(first_value);
			}
			if (idt <= 0)
			{
				cout << "Error: id cant be small than 1!" << endl;
				continue;
			}
			int schedules_id = stoi(first_value);
			const vector<Course>& courses = data_manager.getCourses();
			Schedule* scheduleptr = schedule_data_Manager.find_schedule(schedules_id);
			if (scheduleptr == nullptr)
			{
				continue;
			}
			scheduleptr->print_total_credits(courses);
		}
		
		
		else if (command == "OverlapLessons" || command == "overlaplessons")
		{
			// overlaplessons <schedule_id>
			int idt = 0;
			if (!is_number(first_value))
			{
				cout << "Error: id should be positive number please try again" << endl;
				continue;
			}
			else
			{
				idt = stoi(first_value);
			}
			if (idt <= 0)
			{
				cout << "Error: id cant be small than 1!" << endl;
				continue;
			}
			int schedules_id = stoi(first_value);
			Schedule* scheduleptr = schedule_data_Manager.find_schedule(schedules_id);
			if (scheduleptr == nullptr)
			{
				continue;
			}
			scheduleptr->print_overlap_lessons();

		}
		else if (command == "lessonsday" || command == "LessonsDay")
		{
			// lessonsday <day>
			data_manager.print_lessons_by_day(first_value);
		}
		else
		{
			if (more_flag == 1)
			{
				more_flag =0;
				continue;
			}
			cout << "unrecognize command please try again" << endl;
		}
	}


	cout << "do you want save the schedules before exist? type yes or no" << endl;
	while (true)
	{
		string desision;
		cin >> desision;

		if (desision == "yes")
		{
			schedule_data_Manager.SaveSchedulesInCSV("schedule.csv");
			cout << "exit from program please wait .." << endl;
			break;
		}
		else if (desision == "no")
		{
			cout << "exit from program please wait .." << endl;
			break;
		}
		else
		{
			cout << "wrong type please try again" << endl;

		}

	}
}

int main()
{
	try 
	{
		app();
	}
	catch (const exception& e)
	{
		cerr << "failed with exception: " << e.what() <<endl;
		return 1;
	}
	cout << "Leaks: " << _CrtDumpMemoryLeaks() << endl;
	return 0;

}
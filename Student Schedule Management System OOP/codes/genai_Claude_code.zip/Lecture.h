#ifndef LECTURE_H
#define LECTURE_H

#include "Lesson.h"

/**
 * @class Lecture
 * @brief Represents a lecture lesson in the schedule system
 *
 * This class inherits from Lesson and represents lecture-type lessons.
 * Lectures are typically larger classes with theoretical content.
 */
class Lecture : public Lesson {
public:
    /**
     * @brief Default constructor
     */
    Lecture();

    /**
     * @brief Parameterized constructor (updated for DataManager compatibility)
     * @param courseNum Course number
     * @param dayNum Day of the week (1-7, 1=Sunday)
     * @param startHourNum Start hour (24-hour format)
     * @param dur Duration in hours
     * @param room Classroom (room + building)
     * @param teacher Teacher name
     * @param groupNum Group number
     * @throws std::invalid_argument if any parameter is invalid
     */
    Lecture(int courseNum, int dayNum, int startHourNum, int dur,
        const std::string& room, const std::string& teacher, int groupNum);

    /**
     * @brief Copy constructor
     * @param other Lecture object to copy from
     */
    Lecture(const Lecture& other);

    /**
     * @brief Assignment operator
     * @param other Lecture object to assign from
     * @return Reference to this object
     */
    Lecture& operator=(const Lecture& other);

    /**
     * @brief Virtual destructor
     */
    virtual ~Lecture() = default;

    /**
     * @brief Gets the lesson type
     * @return String "Lecture"
     */
    virtual std::string getLessonType() const override;

    /**
     * @brief Displays lecture-specific information
     */
    virtual void displaySpecificInfo() const override;

    /**
     * @brief Clone method for polymorphic copying
     * @return Pointer to a new Lecture object that is a copy of this one
     */
    virtual Lecture* clone() const override;
};

#endif // LECTURE_H
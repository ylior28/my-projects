﻿#include "Schedule.h"
#include <iomanip>
#include <algorithm>
#include <map>
#include <set>

// Constructors
Schedule::Schedule() : scheduleId(0) {
}

Schedule::Schedule(int id) : scheduleId(id) {
}

Schedule::Schedule(const Schedule& other)
    : scheduleId(other.scheduleId), lessons(other.lessons) {
}

Schedule& Schedule::operator=(const Schedule& other) {
    if (this != &other) {
        scheduleId = other.scheduleId;
        lessons = other.lessons;
    }
    return *this;
}

// Core methods
int Schedule::getScheduleId() const {
    return scheduleId;
}

void Schedule::setScheduleId(int id) {
    scheduleId = id;
}

const std::vector<std::shared_ptr<Lesson>>& Schedule::getLessons() const {
    return lessons;
}

void Schedule::addLesson(std::shared_ptr<Lesson> lesson) {
    if (!lesson) {
        throw std::invalid_argument("Cannot add null lesson");
    }

    // Check if lesson already exists (same course ID and group ID)
    for (const std::shared_ptr<Lesson>& existingLesson : lessons) {
        if (existingLesson &&
            existingLesson->getCourseId() == lesson->getCourseId() &&
            existingLesson->getGroupId() == lesson->getGroupId()) {
            throw std::runtime_error("Lesson already exists in schedule (Course " +
                std::to_string(lesson->getCourseId()) +
                ", Group " + std::to_string(lesson->getGroupId()) + ")");
        }
    }

    lessons.push_back(lesson);
}

bool Schedule::removeLesson(std::shared_ptr<Lesson> lesson) {
    if (!lesson) {
        return false;
    }

    for (std::vector<std::shared_ptr<Lesson>>::iterator it = lessons.begin();
        it != lessons.end(); ++it) {
        if (*it && (*it)->getCourseId() == lesson->getCourseId() &&
            (*it)->getGroupId() == lesson->getGroupId()) {
            lessons.erase(it);
            return true;
        }
    }
    return false;
}

bool Schedule::hasConflict(std::shared_ptr<Lesson> lesson) const {
    if (!lesson) {
        return false;
    }

    for (const std::shared_ptr<Lesson>& existingLesson : lessons) {
        if (existingLesson && lesson->hasConflictWith(*existingLesson)) {
            return true;
        }
    }
    return false;
}

//first demand method: print overlaps lessons in the schedule
void Schedule::printOverlappingLessons() const {
    std::cout << "\n=== Overlapping Lessons in Schedule " << scheduleId << " ===" << std::endl;

    if (lessons.empty()) {
        std::cout << "No lessons in schedule." << std::endl;
        return;
    }

    // Day names mapping
    const std::vector<std::string> dayNames = {
        "", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
    };

    // Group overlapping lessons by time slots
    std::map<std::string, std::vector<std::shared_ptr<Lesson>>> overlapGroups;

    // Create a time-slot key for each lesson and group overlapping ones
    for (const std::shared_ptr<Lesson>& lesson : lessons) {
        if (!lesson) continue;

        // Create time slot groups
        int day = lesson->getDay();
        int startHour = lesson->getStartHour();
        int duration = lesson->getDuration();

        // Check if this lesson overlaps with any existing group
        bool addedToGroup = false;
        for (std::map<std::string, std::vector<std::shared_ptr<Lesson>>>::iterator groupIt = overlapGroups.begin();
            groupIt != overlapGroups.end(); ++groupIt) {

            // Check if lesson overlaps with any lesson in this group
            for (const std::shared_ptr<Lesson>& groupLesson : groupIt->second) {
                if (lesson->hasConflictWith(*groupLesson)) {
                    groupIt->second.push_back(lesson);
                    addedToGroup = true;
                    break;
                }
            }
            if (addedToGroup) break;
        }

        // If not added to any group, create a new group
        if (!addedToGroup) {
            std::string timeKey = "Day" + std::to_string(day) + "_" + std::to_string(startHour);
            overlapGroups[timeKey].push_back(lesson);
        }
    }

    // Print only groups with more than one lesson (actual overlaps)
    int overlapGroupCount = 0;
    for (std::map<std::string, std::vector<std::shared_ptr<Lesson>>>::const_iterator groupIt = overlapGroups.begin();
        groupIt != overlapGroups.end(); ++groupIt) {

        if (groupIt->second.size() > 1) {
            overlapGroupCount++;
            std::cout << "\nOverlap Group " << overlapGroupCount << " (" << groupIt->second.size() << " lessons):" << std::endl;

            for (size_t i = 0; i < groupIt->second.size(); ++i) {
                const std::shared_ptr<Lesson>& lesson = groupIt->second[i];
                int dayNum = lesson->getDay();
                std::string dayName = (dayNum >= 1 && dayNum <= 7) ? dayNames[dayNum] : "Unknown";

                // FIXED: Display proper academic time format
                std::string startTimeStr = convertHourToAcademicTime(lesson->getStartHour());

                std::cout << "  Lesson " << (i + 1) << ": Course: " << lesson->getCourseId()
                    << ", Type: " << lesson->getLessonType()
                    << ", Day: " << dayName
                    << ", Start: " << startTimeStr
                    << ", Duration: " << lesson->getDuration() << "h"
                    << ", Room: " << lesson->getClassroom()
                    << ", Teacher: " << lesson->getTeacherName()
                    << ", Group: " << lesson->getGroupId() << std::endl;
            }
        }
    }

    if (overlapGroupCount == 0) {
        std::cout << "No overlapping lessons found." << std::endl;
    }
    else {
        std::cout << "\nTotal overlap groups found: " << overlapGroupCount << std::endl;
    }
    std::cout << std::endl;
}

//second own demanded method: print the sum of credits in the schedule
void Schedule::printTotalCredits(const std::map<int, Course>& courses) const {
    std::cout << "\n=== Total Credits in Schedule " << scheduleId << " ===" << std::endl;

    if (lessons.empty()) {
        std::cout << "No lessons in schedule." << std::endl;
        std::cout << "Total credits: 0" << std::endl;
        return;
    }

    std::set<int> uniqueCourses; // To avoid counting the same course multiple times
    double totalCredits = 0.0;

    // Collect unique course IDs
    for (const std::shared_ptr<Lesson>& lesson : lessons) {
        if (lesson) {
            uniqueCourses.insert(lesson->getCourseId());
        }
    }

    // Sum credits for unique courses
    std::cout << "Courses in schedule:" << std::endl;
    for (std::set<int>::const_iterator it = uniqueCourses.begin(); it != uniqueCourses.end(); ++it) {
        int courseId = *it;
        std::map<int, Course>::const_iterator courseIt = courses.find(courseId);
        if (courseIt != courses.end()) {
            double credits = courseIt->second.getCreditPoints();
            totalCredits += credits;
            std::cout << "  Course " << courseId << ": " << credits << " credits" << std::endl;
        }
        else {
            std::cout << "  Course " << courseId << ": Course not found in database" << std::endl;
        }
    }

    std::cout << "\nTotal credits: " << totalCredits << std::endl;
    std::cout << std::endl;
}

// Utility methods
size_t Schedule::getLessonsCount() const {
    return lessons.size();
}

bool Schedule::isEmpty() const {
    return lessons.empty();
}

void Schedule::clear() {
    lessons.clear();
}

// Helper method to convert internal hour to academic time format
std::string Schedule::convertHourToAcademicTime(int hour) const {
    switch (hour) {
    case 8: return "8:30";
    case 9: return "9:30";
    case 10: return "10:30";
    case 11: return "11:30";
    case 12: return "12:50";
    case 13: return "13:50";
    case 14: return "14:50";
    case 15: return "15:50";
    case 16: return "16:50";
    case 17: return "17:50";
    case 18: return "18:50";
    case 19: return "19:50";
    case 20: return "20:50";
    default: return std::to_string(hour) + ":00";
    }
}

// Display method - improved format with proper spacing and conflict handling
void Schedule::printScheduleTable() const {
    std::cout << "\nSchedule ID: " << scheduleId << std::endl;
    std::cout << "Total lessons: " << lessons.size() << std::endl;

    if (lessons.empty()) {
        std::cout << "No lessons scheduled.\n" << std::endl;
        return;
    }

    // FIXED: Use the correct academic time slots
    const std::vector<std::string> timeSlots = {
        "8:30", "9:30", "10:30", "11:30", "12:50", "13:50", "14:50", "15:50", "16:50", "17:50", "18:50", "19:50", "20:50"
    };

    const std::vector<std::string> days = {
        "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
    };

    // Print table header with proper spacing and separators
    std::cout << std::left << std::setw(9) << "Hour";
    for (size_t i = 0; i < days.size(); ++i) {
        std::cout << "| " << std::left << std::setw(32) << days[i];
    }
    std::cout << "|" << std::endl;

    // Print separator line
    std::cout << std::string(9, '-');
    for (size_t i = 0; i < days.size(); ++i) {
        std::cout << "+" << std::string(33, '-');
    }
    std::cout << "+" << std::endl;

    // Print schedule data with proper conflict handling
    for (size_t timeIdx = 0; timeIdx < timeSlots.size(); ++timeIdx) {
        const std::string& timeSlot = timeSlots[timeIdx];

        // Collect all lessons for each day at this time slot
        std::vector<std::vector<std::string>> dayLessonsVector(7); // 7 days

        for (const std::shared_ptr<Lesson>& lesson : lessons) {
            if (!lesson) continue;

            int dayNum = lesson->getDay();
            if (dayNum >= 1 && dayNum <= 7) {
                if (isLessonActiveAtTime(lesson->getStartHour(), lesson->getDuration(), timeSlot)) {
                    std::string lessonStr = "[" + std::to_string(lesson->getCourseId()) + "," +
                        lesson->getLessonType() + "," + lesson->getClassroom() + "]";
                    dayLessonsVector[dayNum - 1].push_back(lessonStr);
                }
            }
        }

        // Find maximum number of lessons in any day for this time slot
        size_t maxLessons = 1;
        for (size_t day = 0; day < 7; ++day) {
            if (dayLessonsVector[day].size() > maxLessons) {
                maxLessons = dayLessonsVector[day].size();
            }
        }

        // Print rows for this time slot (one row per conflict level)
        for (size_t row = 0; row < maxLessons; ++row) {
            // Print time only for first row of each time slot
            if (row == 0) {
                std::cout << std::left << std::setw(9) << timeSlot;
            }
            else {
                std::cout << std::left << std::setw(9) << "";
            }

            // Print content for each day with separators
            for (size_t day = 0; day < 7; ++day) {
                std::string cellContent = "";
                const std::vector<std::string>& currentDayLessons = dayLessonsVector[day];

                if (row < currentDayLessons.size()) {
                    cellContent = currentDayLessons[row];
                    // Truncate if too long to prevent overflow
                    if (cellContent.length() > 30) {
                        cellContent = cellContent.substr(0, 27) + "...";
                    }
                }

                std::cout << "| " << std::left << std::setw(32) << cellContent;
            }
            std::cout << "|" << std::endl;
        }

        // Add horizontal separator line between different time slots (except after last one)
        if (timeIdx < timeSlots.size() - 1) {
            std::cout << std::string(9, '.');  // Dotted line for time separation
            for (size_t i = 0; i < days.size(); ++i) {
                std::cout << "+" << std::string(33, '.');
            }
            std::cout << "+" << std::endl;
        }
    }

    std::cout << std::endl;
}

// FIXED: Helper function to check if lesson is active at specific academic time
bool Schedule::isLessonActiveAtTime(int lessonStartHour, int durationHours, const std::string& timeSlot) const {
    // Convert academic time slots to internal hour representation for comparison
    int slotHour = -1;

    if (timeSlot == "8:30") slotHour = 8;
    else if (timeSlot == "9:30") slotHour = 9;
    else if (timeSlot == "10:30") slotHour = 10;
    else if (timeSlot == "11:30") slotHour = 11;
    else if (timeSlot == "12:50") slotHour = 12;
    else if (timeSlot == "13:50") slotHour = 13;
    else if (timeSlot == "14:50") slotHour = 14;
    else if (timeSlot == "15:50") slotHour = 15;
    else if (timeSlot == "16:50") slotHour = 16;
    else if (timeSlot == "17:50") slotHour = 17;
    else if (timeSlot == "18:50") slotHour = 18;
    else if (timeSlot == "19:50") slotHour = 19;
    else if (timeSlot == "20:50") slotHour = 20;
    else {
        // Fallback: try to parse as HH:MM
        size_t colonPos = timeSlot.find(':');
        if (colonPos != std::string::npos) {
            slotHour = std::stoi(timeSlot.substr(0, colonPos));
        }
    }

    if (slotHour == -1) return false;

    // Check if time slot falls within lesson duration
    int lessonEndHour = lessonStartHour + durationHours;
    return (slotHour >= lessonStartHour && slotHour < lessonEndHour);
}

// Operators
bool Schedule::operator==(const Schedule& other) const {
    if (scheduleId != other.scheduleId || lessons.size() != other.lessons.size()) {
        return false;
    }

    for (size_t i = 0; i < lessons.size(); ++i) {
        if (!lessons[i] || !other.lessons[i] || !(*lessons[i] == *other.lessons[i])) {
            return false;
        }
    }

    return true;
}

bool Schedule::operator!=(const Schedule& other) const {
    return !(*this == other);
}

std::ostream& operator<<(std::ostream& os, const Schedule& schedule) {
    os << "Schedule ID: " << schedule.scheduleId << ", Lessons: " << schedule.lessons.size();
    return os;
}
#include "Lecture.h"
#include <iostream>

// Constructors
Lecture::Lecture() : Lesson() {
}

Lecture::Lecture(int courseNum, int dayNum, int startHourNum, int dur,
    const std::string& room, const std::string& teacher, int groupNum)
    : Lesson(courseNum, dayNum, startHourNum, dur, room, teacher, groupNum) {
}

Lecture::Lecture(const Lecture& other) : Lesson(other) {
}

// Assignment operator
Lecture& Lecture::operator=(const Lecture& other) {
    if (this != &other) {
        Lesson::operator=(other);
    }
    return *this;
}

// Virtual methods implementation
std::string Lecture::getLessonType() const {
    return "Lecture";
}

void Lecture::displaySpecificInfo() const {
    std::cout << std::endl << "  Type: Theoretical lecture session";
}

Lecture* Lecture::clone() const {
    return new Lecture(*this);
}
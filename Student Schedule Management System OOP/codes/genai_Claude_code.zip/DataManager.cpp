#include "DataManager.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <stdexcept>
#include <cctype>

DataManager::DataManager() : nextScheduleId(1) {
    try {
        loadCourses();
        loadLessons();
        loadSchedules();
    }
    catch (const std::exception& e) {
        std::cerr << "Error initializing DataManager: " << e.what() << std::endl;
        throw;
    }
}

DataManager::~DataManager() {
    try {
        saveSchedules();

        // Clear all data structures to ensure proper cleanup
        schedules.clear();
        lessons.clear();
        courses.clear();
    }
    catch (const std::exception& e) {
        std::cerr << "Error saving schedules in destructor: " << e.what() << std::endl;
    }
}

void DataManager::loadCourses() {
    std::ifstream file("courses.csv");
    if (!file.is_open()) {
        throw std::runtime_error("Cannot open courses.csv file");
    }

    std::string line;
    bool isFirstLine = true;

    while (std::getline(file, line)) {
        if (isFirstLine) {
            isFirstLine = false;
            continue; // Skip header line
        }

        if (line.empty()) continue;

        try {
            std::vector<std::string> fields = parseCSVLine(line);
            if (fields.size() >= 6) {
                int courseId = std::stoi(trimWhitespace(fields[0]));
                std::string name = trimWhitespace(fields[1]);
                double credits = std::stod(trimWhitespace(fields[2])); // Fixed: double instead of float
                std::string examDateA = trimWhitespace(fields[3]);
                std::string examDateB = trimWhitespace(fields[4]);
                std::string lecturer = trimWhitespace(fields[5]);

                Course course(courseId, name, credits, examDateA, examDateB, lecturer);
                courses[courseId] = course;
            }
        }
        catch (const std::exception& e) {
            std::cerr << "Error parsing course line: " << line << " - " << e.what() << std::endl;
        }
    }

    file.close();
}

void DataManager::loadLessons() {
    for (std::map<int, Course>::const_iterator it = courses.begin(); it != courses.end(); ++it) {
        loadLessonsForCourse(it->first);
    }
}

void DataManager::loadLessonsForCourse(int courseId) {
    std::vector<std::shared_ptr<Lesson>> courseLessons;

    // Load lectures
    std::string lecturesFile = std::to_string(courseId) + "_lectures.csv";
    std::ifstream file(lecturesFile);
    if (file.is_open()) {
        std::string line;
        bool isFirstLine = true;

        while (std::getline(file, line)) {
            if (isFirstLine) {
                isFirstLine = false;
                continue;
            }

            if (line.empty()) continue;

            try {
                std::vector<std::string> fields = parseCSVLine(line);
                std::shared_ptr<Lesson> lecture = parseLessonFromFields(courseId, fields, "Lecture");
                courseLessons.push_back(lecture);
            }
            catch (const std::exception& e) {
                std::cerr << "Error parsing lecture line: " << line << " - " << e.what() << std::endl;
            }
        }
        file.close();
    }

    // Load tutorials
    std::string tutorialsFile = std::to_string(courseId) + "_tutorials.csv";
    file.open(tutorialsFile);
    if (file.is_open()) {
        std::string line;
        bool isFirstLine = true;

        while (std::getline(file, line)) {
            if (isFirstLine) {
                isFirstLine = false;
                continue;
            }

            if (line.empty()) continue;

            try {
                std::vector<std::string> fields = parseCSVLine(line);
                std::shared_ptr<Lesson> tutorial = parseLessonFromFields(courseId, fields, "Tutorial");
                courseLessons.push_back(tutorial);
            }
            catch (const std::exception& e) {
                std::cerr << "Error parsing tutorial line: " << line << " - " << e.what() << std::endl;
            }
        }
        file.close();
    }

    // Load labs
    std::string labsFile = std::to_string(courseId) + "_labs.csv";
    file.open(labsFile);
    if (file.is_open()) {
        std::string line;
        bool isFirstLine = true;

        while (std::getline(file, line)) {
            if (isFirstLine) {
                isFirstLine = false;
                continue;
            }

            if (line.empty()) continue;

            try {
                std::vector<std::string> fields = parseCSVLine(line);
                std::shared_ptr<Lesson> lab = parseLessonFromFields(courseId, fields, "Lab");
                courseLessons.push_back(lab);
            }
            catch (const std::exception& e) {
                std::cerr << "Error parsing lab line: " << line << " - " << e.what() << std::endl;
            }
        }
        file.close();
    }

    if (!courseLessons.empty()) {
        lessons[courseId] = courseLessons;
    }
}

void DataManager::loadSchedules() {
    std::ifstream file("schedules.csv");
    if (!file.is_open()) {
        std::cout << "schedules.csv not found, starting with empty schedules list." << std::endl;
        return;
    }

    std::string line;
    bool isFirstLine = true;

    while (std::getline(file, line)) {
        if (isFirstLine) {
            isFirstLine = false;
            continue; // Skip header
        }

        if (line.empty()) continue;

        try {
            std::vector<std::string> fields = parseCSVLine(line);

            // Check if this is the simple format (3 fields) or detailed format (9 fields)
            if (fields.size() == 3) {
                // Simple format: schedule_id, course_id, group_id
                int scheduleId = std::stoi(trimWhitespace(fields[0]));
                int courseId = std::stoi(trimWhitespace(fields[1]));
                int groupId = std::stoi(trimWhitespace(fields[2]));

                // Ensure schedule exists
                while (static_cast<int>(schedules.size()) < scheduleId) {
                    schedules.push_back(Schedule(static_cast<int>(schedules.size()) + 1));
                }

                // Add course to schedule
                try {
                    const std::vector<std::shared_ptr<Lesson>>& courseLessons = getLessonsByCourse(courseId);
                    for (size_t i = 0; i < courseLessons.size(); ++i) {
                        if (courseLessons[i]->getGroupId() == groupId) {
                            schedules[scheduleId - 1].addLesson(courseLessons[i]);
                            break;
                        }
                    }
                }
                catch (const std::exception& e) {
                    std::cerr << "Error adding course " << courseId << " group " << groupId
                        << " to schedule " << scheduleId << ": " << e.what() << std::endl;
                }
            }
            else if (fields.size() >= 9) {
                // Detailed format: schedule_id,lesson_type,course_id,day,start_hour,duration,room,teacher,group_id
                int scheduleId = std::stoi(trimWhitespace(fields[0]));
                int courseId = std::stoi(trimWhitespace(fields[2]));
                int groupId = std::stoi(trimWhitespace(fields[8]));

                // Ensure schedule exists
                while (static_cast<int>(schedules.size()) < scheduleId) {
                    schedules.push_back(Schedule(static_cast<int>(schedules.size()) + 1));
                }

                // Add course to schedule
                try {
                    const std::vector<std::shared_ptr<Lesson>>& courseLessons = getLessonsByCourse(courseId);
                    for (size_t i = 0; i < courseLessons.size(); ++i) {
                        if (courseLessons[i]->getGroupId() == groupId) {
                            schedules[scheduleId - 1].addLesson(courseLessons[i]);
                            break;
                        }
                    }
                }
                catch (const std::exception& e) {
                    std::cerr << "Error adding course " << courseId << " group " << groupId
                        << " to schedule " << scheduleId << ": " << e.what() << std::endl;
                }
            }

            // Update nextScheduleId
            if (fields.size() >= 1) {
                int scheduleId = std::stoi(trimWhitespace(fields[0]));
                if (scheduleId >= nextScheduleId) {
                    nextScheduleId = scheduleId + 1;
                }
            }
        }
        catch (const std::exception& e) {
            std::cerr << "Error parsing schedule line: " << line << " - " << e.what() << std::endl;
        }
    }

    file.close();
}

void DataManager::saveSchedules() const {
    std::ofstream file("schedules.csv");
    if (!file.is_open()) {
        throw std::runtime_error("Cannot open schedules.csv for writing");
    }

    // Write header in detailed format (matching your manual implementation)
    file << "schedule_id,lesson_type,course_id,day,start_hour,duration,room,teacher,group_id\n";

    // Write schedule data in detailed format
    for (size_t i = 0; i < schedules.size(); ++i) {
        const Schedule& schedule = schedules[i];
        int scheduleId = static_cast<int>(i + 1);

        const std::vector<std::shared_ptr<Lesson>>& lessonsList = schedule.getLessons();
        for (size_t j = 0; j < lessonsList.size(); ++j) {
            const std::shared_ptr<Lesson>& lesson = lessonsList[j];

            // Convert day number to day name
            std::string dayName = convertDayNumberToName(lesson->getDay());

            // FIXED: Convert start hour back to proper time format based on academic schedule
            std::string startTimeStr = convertHourToTimeString(lesson->getStartHour());

            file << scheduleId << ","
                << lesson->getLessonType() << ","
                << lesson->getCourseId() << ","
                << dayName << ","
                << startTimeStr << ","
                << lesson->getDuration() << ","
                << lesson->getClassroom() << ","
                << lesson->getTeacherName() << ","
                << lesson->getGroupId() << "\n";
        }
    }

    file.close();
}

std::vector<std::string> DataManager::parseCSVLine(const std::string& line) const {
    std::vector<std::string> fields;
    std::stringstream ss(line);
    std::string field;

    while (std::getline(ss, field, ',')) {
        fields.push_back(field);
    }

    return fields;
}

std::string DataManager::trimWhitespace(const std::string& str) const {
    size_t start = str.find_first_not_of(" \t\r\n");
    if (start == std::string::npos) return "";

    size_t end = str.find_last_not_of(" \t\r\n");
    return str.substr(start, end - start + 1);
}

int DataManager::convertDayNameToNumber(const std::string& dayName) const {
    std::string day = dayName;
    // Convert to lowercase for comparison
    std::transform(day.begin(), day.end(), day.begin(), ::tolower);

    if (day == "sunday") return 1;
    if (day == "monday") return 2;
    if (day == "tuesday") return 3;
    if (day == "wednesday") return 4;
    if (day == "thursday") return 5;
    if (day == "friday") return 6;
    if (day == "saturday") return 7;

    throw std::invalid_argument("Invalid day name: " + dayName);
}

// FIXED: New function to properly convert time string to hour considering academic schedule
int DataManager::convertTimeToHour(const std::string& timeStr) const {
    // Map the academic time slots to internal hour representation
    // Academic times: 8:30, 9:30, 10:30, 11:30, 12:50, 13:50, 14:50, 15:50, 16:50, 17:50, 18:50, 19:50, 20:50
    // Internal hours:  8,    9,    10,    11,    12,    13,    14,    15,    16,    17,    18,    19,    20 

    if (timeStr == "8:30") return 8;
    if (timeStr == "9:30") return 9;
    if (timeStr == "10:30") return 10;
    if (timeStr == "11:30") return 11;
    if (timeStr == "12:50") return 12;
    if (timeStr == "13:50") return 13;
    if (timeStr == "14:50") return 14;
    if (timeStr == "15:50") return 15;
    if (timeStr == "16:50") return 16;
    if (timeStr == "17:50") return 17;
    if (timeStr == "18:50") return 18;
    if (timeStr == "19:50") return 19;
    if (timeStr == "20:50") return 20;

    // For other formats, try to extract hour and convert based on minutes
    size_t colonPos = timeStr.find(':');
    if (colonPos == std::string::npos) {
        throw std::invalid_argument("Invalid time format: " + timeStr);
    }

    int hour = std::stoi(timeStr.substr(0, colonPos));
    int minutes = std::stoi(timeStr.substr(colonPos + 1));

    // If it's a standard academic time with 50 minutes, subtract 1 from hour for internal representation
    if (minutes == 50 && hour >= 13 && hour <= 20) {
        return hour - 1;
    }

    // For 30-minute times (8:30, 9:30, etc.) use the hour as-is
    return hour;
}

// FIXED: New function to convert internal hour back to proper academic time format
std::string DataManager::convertHourToTimeString(int hour) const {
    // Convert internal hour representation back to academic time format
    switch (hour) {
    case 8: return "8:30";
    case 9: return "9:30";
    case 10: return "10:30";
    case 11: return "11:30";
    case 12: return "12:50";
    case 13: return "13:50";
    case 14: return "14:50";
    case 15: return "15:50";
    case 16: return "16:50";
    case 17: return "17:50";
    case 18: return "18:50";
    case 19: return "19:50";
    case 20: return "20:50";
    default: return std::to_string(hour) + ":00"; // Fallback for non-standard times
    }
}

std::string DataManager::convertDayNumberToName(int dayNumber) const {
    switch (dayNumber) {
    case 1: return "Sunday";
    case 2: return "Monday";
    case 3: return "Tuesday";
    case 4: return "Wednesday";
    case 5: return "Thursday";
    case 6: return "Friday";
    case 7: return "Saturday";
    default: return "Unknown";
    }
}

std::shared_ptr<Lesson> DataManager::parseLessonFromFields(int courseId, const std::vector<std::string>& fields, const std::string& lessonType) const {
    if (fields.size() < 7) {
        throw std::invalid_argument("Not enough fields: " + std::to_string(fields.size()) + " < 7");
    }

    // Parse fields
    std::string dayName = trimWhitespace(fields[1]);        // B: day
    std::string timeStr = trimWhitespace(fields[2]);        // C: start_time  
    std::string durationStr = trimWhitespace(fields[3]);    // D: duration
    std::string classroom = trimWhitespace(fields[4]);      // E: room
    std::string teacher = trimWhitespace(fields[5]);        // F: teacher

    // Handle group_id - might be in field 6 or 7 depending on header issues
    std::string groupIdStr;
    if (fields.size() >= 8) {
        // If 8 fields, group_id is probably split (group,id) - use last field
        groupIdStr = trimWhitespace(fields[7]);
    }
    else {
        // If 7 fields, group_id is in field 6
        groupIdStr = trimWhitespace(fields[6]);
    }

    // Convert to proper types
    int duration = std::stoi(durationStr);
    int groupId = std::stoi(groupIdStr);
    int day = convertDayNameToNumber(dayName);
    int startHour = convertTimeToHour(timeStr); // FIXED: Now properly converts academic times

    // Create appropriate lesson type
    if (lessonType == "Lecture") {
        return std::make_shared<Lecture>(courseId, day, startHour, duration, classroom, teacher, groupId);
    }
    else if (lessonType == "Tutorial") {
        return std::make_shared<Tutorial>(courseId, day, startHour, duration, classroom, teacher, groupId);
    }
    else if (lessonType == "Lab") {
        return std::make_shared<Lab>(courseId, day, startHour, duration, classroom, teacher, groupId);
    }
    else {
        throw std::invalid_argument("Unknown lesson type: " + lessonType);
    }
}

// Course management methods
const std::map<int, Course>& DataManager::getAllCourses() const {
    return courses;
}

const Course& DataManager::getCourseById(int courseId) const {
    std::map<int, Course>::const_iterator it = courses.find(courseId);
    if (it == courses.end()) {
        throw std::invalid_argument("Course with ID " + std::to_string(courseId) + " not found");
    }
    return it->second;
}

bool DataManager::courseExists(int courseId) const {
    return courses.find(courseId) != courses.end();
}

// Lesson management methods
const std::vector<std::shared_ptr<Lesson>>& DataManager::getLessonsByCourse(int courseId) const {
    std::map<int, std::vector<std::shared_ptr<Lesson>>>::const_iterator it = lessons.find(courseId);
    if (it == lessons.end()) {
        throw std::invalid_argument("No lessons found for course ID " + std::to_string(courseId));
    }
    return it->second;
}

std::shared_ptr<Lesson> DataManager::getLessonByGroup(int courseId, int groupId) const {
    const std::vector<std::shared_ptr<Lesson>>& courseLessons = getLessonsByCourse(courseId);

    for (size_t i = 0; i < courseLessons.size(); ++i) {
        if (courseLessons[i]->getGroupId() == groupId) {
            return courseLessons[i];
        }
    }

    throw std::invalid_argument("No lesson found for course " + std::to_string(courseId) +
        " with group " + std::to_string(groupId));
}

//third own demanded method: print the list of the lessons by choosen day
void DataManager::printLessonsByDay(const std::string& dayName) const {
    std::cout << "\n=== All Lessons on " << dayName << " ===" << std::endl;

    try {
        // Convert day name to number
        int dayNumber = convertDayNameToNumber(dayName);

        std::vector<std::shared_ptr<Lesson>> dayLessons;

        // Go through all courses and collect lessons for the specified day
        for (std::map<int, std::vector<std::shared_ptr<Lesson>>>::const_iterator courseIt = lessons.begin();
            courseIt != lessons.end(); ++courseIt) {

            const std::vector<std::shared_ptr<Lesson>>& courseLessons = courseIt->second;

            for (size_t i = 0; i < courseLessons.size(); ++i) {
                if (courseLessons[i] && courseLessons[i]->getDay() == dayNumber) {
                    dayLessons.push_back(courseLessons[i]);
                }
            }
        }

        if (dayLessons.empty()) {
            std::cout << "No lessons found for " << dayName << "." << std::endl;
        }
        else {
            // Sort lessons by start hour for better readability
            std::sort(dayLessons.begin(), dayLessons.end(),
                [](const std::shared_ptr<Lesson>& a, const std::shared_ptr<Lesson>& b) {
                    if (a->getStartHour() != b->getStartHour()) {
                        return a->getStartHour() < b->getStartHour();
                    }
                    return a->getCourseId() < b->getCourseId();
                });

            std::cout << "Found " << dayLessons.size() << " lessons:" << std::endl;

            for (size_t i = 0; i < dayLessons.size(); ++i) {
                const std::shared_ptr<Lesson>& lesson = dayLessons[i];

                // Get course name
                std::string courseName = "Unknown";
                try {
                    const Course& course = getCourseById(lesson->getCourseId());
                    courseName = course.getCourseName();
                }
                catch (const std::exception&) {
                    // Course not found, keep default name
                }

                std::cout << "\nLesson " << (i + 1) << ":" << std::endl;
                std::cout << "  Course: " << lesson->getCourseId() << " (" << courseName << ")" << std::endl;
                std::cout << "  Type: " << lesson->getLessonType() << std::endl;

                // FIXED: Display proper academic time format
                std::string startTimeStr = convertHourToTimeString(lesson->getStartHour());
                std::string endTimeStr = convertHourToTimeString(lesson->getStartHour() + lesson->getDuration());
                std::cout << "  Time: " << startTimeStr << " - " << endTimeStr << std::endl;

                std::cout << "  Duration: " << lesson->getDuration() << " hours" << std::endl;
                std::cout << "  Room: " << lesson->getClassroom() << std::endl;
                std::cout << "  Teacher: " << lesson->getTeacherName() << std::endl;
                std::cout << "  Group: " << lesson->getGroupId() << std::endl;
            }
        }
    }
    catch (const std::invalid_argument& e) {
        std::cout << "Error: Invalid day name '" << dayName << "'. Please use: Sunday, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday" << std::endl;
    }
    catch (const std::exception& e) {
        std::cout << "Error: " << e.what() << std::endl;
    }

    std::cout << std::endl;
}

// Schedule management methods
const std::vector<Schedule>& DataManager::getSchedules() const {
    return schedules;
}

const Schedule& DataManager::getScheduleById(int scheduleId) const {
    if (scheduleId < 1 || scheduleId > static_cast<int>(schedules.size())) {
        throw std::invalid_argument("Schedule with ID " + std::to_string(scheduleId) + " not found");
    }
    return schedules[scheduleId - 1];
}

Schedule& DataManager::getScheduleById(int scheduleId) {
    if (scheduleId < 1 || scheduleId > static_cast<int>(schedules.size())) {
        throw std::invalid_argument("Schedule with ID " + std::to_string(scheduleId) + " not found");
    }
    return schedules[scheduleId - 1];
}

int DataManager::addSchedule() {
    int newId = nextScheduleId++;
    schedules.push_back(Schedule(newId));
    return newId;
}

void DataManager::removeSchedule(int scheduleId) {
    if (scheduleId < 1 || scheduleId > static_cast<int>(schedules.size())) {
        throw std::invalid_argument("Schedule with ID " + std::to_string(scheduleId) + " not found");
    }

    // Remove the schedule
    schedules.erase(schedules.begin() + scheduleId - 1);

    // Update schedule IDs to maintain sequential numbering
    for (size_t i = 0; i < schedules.size(); ++i) {
        schedules[i].setScheduleId(static_cast<int>(i + 1));
    }

    // Update nextScheduleId
    nextScheduleId = static_cast<int>(schedules.size()) + 1;
}

void DataManager::addCourseToSchedule(int scheduleId, int courseId, int groupId) {
    // Validate schedule exists
    Schedule& schedule = getScheduleById(scheduleId);

    // Find the lesson
    std::shared_ptr<Lesson> lesson = getLessonByGroup(courseId, groupId);

    // Add the lesson
    schedule.addLesson(lesson);
}

void DataManager::removeCourseFromSchedule(int scheduleId, int courseId, int groupId) {
    // Validate schedule exists
    Schedule& schedule = getScheduleById(scheduleId);

    // Find the lesson in the course database
    std::shared_ptr<Lesson> lessonToRemove = getLessonByGroup(courseId, groupId);

    // Check if this lesson actually exists in THIS schedule
    const std::vector<std::shared_ptr<Lesson>>& scheduleLessons = schedule.getLessons();
    bool found = false;

    for (const auto& lesson : scheduleLessons) {
        if (lesson && lesson->getCourseId() == courseId && lesson->getGroupId() == groupId) {
            found = true;
            break;
        }
    }

    if (!found) {
        throw std::invalid_argument("Course " + std::to_string(courseId) +
            " (group " + std::to_string(groupId) +
            ") is not in schedule " + std::to_string(scheduleId));
    }

    // Remove the lesson
    schedule.removeLesson(lessonToRemove);
}

// Utility methods
size_t DataManager::getCoursesCount() const {
    return courses.size();
}

size_t DataManager::getSchedulesCount() const {
    return schedules.size();
}

int DataManager::getNextScheduleId() const {
    return nextScheduleId;
}

// Iterator support
DataManager::CourseIterator DataManager::coursesBegin() const {
    return courses.begin();
}

DataManager::CourseIterator DataManager::coursesEnd() const {
    return courses.end();
}
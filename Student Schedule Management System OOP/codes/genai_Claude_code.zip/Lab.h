#ifndef LAB_H
#define LAB_H

#include "Lesson.h"

/**
 * @class Lab
 * @brief Represents a laboratory lesson in the schedule system
 *
 * This class inherits from Lesson and represents lab-type lessons.
 * Labs are typically hands-on practical sessions with equipment or computers.
 */
class Lab : public Lesson {
public:
    /**
     * @brief Default constructor
     */
    Lab();

    /**
     * @brief Parameterized constructor (updated for DataManager compatibility)
     * @param courseNum Course number
     * @param dayNum Day of the week (1-7, 1=Sunday)
     * @param startHourNum Start hour (24-hour format)
     * @param dur Duration in hours
     * @param room Classroom (room + building)
     * @param teacher Teacher name
     * @param groupNum Group number
     * @throws std::invalid_argument if any parameter is invalid
     */
    Lab(int courseNum, int dayNum, int startHourNum, int dur,
        const std::string& room, const std::string& teacher, int groupNum);

    /**
     * @brief Copy constructor
     * @param other Lab object to copy from
     */
    Lab(const Lab& other);

    /**
     * @brief Assignment operator
     * @param other Lab object to assign from
     * @return Reference to this object
     */
    Lab& operator=(const Lab& other);

    /**
     * @brief Virtual destructor
     */
    virtual ~Lab() = default;

    /**
     * @brief Gets the lesson type
     * @return String "Lab"
     */
    virtual std::string getLessonType() const override;

    /**
     * @brief Displays lab-specific information
     */
    virtual void displaySpecificInfo() const override;

    /**
     * @brief Clone method for polymorphic copying
     * @return Pointer to a new Lab object that is a copy of this one
     */
    virtual Lab* clone() const override;
};

#endif // LAB_H
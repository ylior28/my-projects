#include "Tutorial.h"
#include <iostream>

// Constructors
Tutorial::Tutorial() : Lesson() {
}

Tutorial::Tutorial(int courseNum, int dayNum, int startHourNum, int dur,
    const std::string& room, const std::string& teacher, int groupNum)
    : Lesson(courseNum, dayNum, startHourNum, dur, room, teacher, groupNum) {
}

Tutorial::Tutorial(const Tutorial& other) : Lesson(other) {
}

// Assignment operator
Tutorial& Tutorial::operator=(const Tutorial& other) {
    if (this != &other) {
        Lesson::operator=(other);
    }
    return *this;
}

// Virtual methods implementation
std::string Tutorial::getLessonType() const {
    return "Tutorial";
}

void Tutorial::displaySpecificInfo() const {
    std::cout << std::endl << "  Type: Practice session with exercises";
}

Tutorial* Tutorial::clone() const {
    return new Tutorial(*this);
}
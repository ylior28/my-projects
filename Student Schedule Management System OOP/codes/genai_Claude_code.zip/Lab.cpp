#include "Lab.h"
#include <iostream>

// Constructors
Lab::Lab() : Lesson() {
}

Lab::Lab(int courseNum, int dayNum, int startHourNum, int dur,
    const std::string& room, const std::string& teacher, int groupNum)
    : Lesson(courseNum, dayNum, startHourNum, dur, room, teacher, groupNum) {
}

Lab::Lab(const Lab& other) : Lesson(other) {
}

// Assignment operator
Lab& Lab::operator=(const Lab& other) {
    if (this != &other) {
        Lesson::operator=(other);
    }
    return *this;
}

// Virtual methods implementation
std::string Lab::getLessonType() const {
    return "Lab";
}

void Lab::displaySpecificInfo() const {
    std::cout << std::endl << "  Type: Hands-on laboratory session";
}

Lab* Lab::clone() const {
    return new Lab(*this);
}
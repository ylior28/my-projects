#ifndef COURSE_H
#define COURSE_H

#include <string>
#include <iostream>
#include <stdexcept>

/**
 * @class Course
 * @brief Represents a course in the academic system
 *
 * This class manages course information including course number, name,
 * credit points, exam dates, and responsible lecturer.
 */
class Course {
private:
    int courseNumber;           ///< Unique course identifier
    std::string courseName;     ///< Name of the course
    double creditPoints;         ///< Number of credit points (Nekudot Zchut)
    std::string examDateA;      ///< First exam date (Moed A)
    std::string examDateB;      ///< Second exam date (Moed B)
    std::string lecturer;       ///< Responsible lecturer name

    /**
     * @brief Validates course number
     * @param courseNum The course number to validate
     * @throws std::invalid_argument if course number is invalid
     */
    void validateCourseNumber(int courseNum) const;

    /**
     * @brief Validates credit points
     * @param credits The credit points to validate
     * @throws std::invalid_argument if credit points are invalid
     */
    void validateCreditPoints(double credits) const;

    /**
     * @brief Validates that a string is not empty
     * @param str The string to validate
     * @param fieldName The name of the field for error messages
     * @throws std::invalid_argument if string is empty
     */
    void validateNonEmptyString(const std::string& str, const std::string& fieldName) const;

public:
    /**
     * @brief Default constructor
     */
    Course();

    /**
     * @brief Parameterized constructor
     * @param courseNum Course number
     * @param name Course name
     * @param credits Credit points
     * @param dateA First exam date
     * @param dateB Second exam date
     * @param lect Lecturer name
     * @throws std::invalid_argument if any parameter is invalid
     */
    Course(int courseNum, const std::string& name, double credits,
        const std::string& dateA, const std::string& dateB,
        const std::string& lect);

    /**
     * @brief Copy constructor
     * @param other Course object to copy from
     */
    Course(const Course& other);

    /**
     * @brief Assignment operator
     * @param other Course object to assign from
     * @return Reference to this object
     */
    Course& operator=(const Course& other);

    /**
     * @brief Destructor
     */
    ~Course() = default;

    // Getter methods
    /**
     * @brief Gets the course number
     * @return Course number
     */
    int getCourseNumber() const;

    /**
     * @brief Gets the course name
     * @return Course name
     */
    const std::string& getCourseName() const;

    /**
     * @brief Gets the credit points
     * @return Credit points
     */
    double getCreditPoints() const;

    /**
     * @brief Gets the first exam date
     * @return First exam date
     */
    const std::string& getExamDateA() const;

    /**
     * @brief Gets the second exam date
     * @return Second exam date
     */
    const std::string& getExamDateB() const;

    /**
     * @brief Gets the lecturer name
     * @return Lecturer name
     */
    const std::string& getLecturer() const;

    // Setter methods
    /**
     * @brief Sets the course number
     * @param courseNum New course number
     * @throws std::invalid_argument if course number is invalid
     */
    void setCourseNumber(int courseNum);

    /**
     * @brief Sets the course name
     * @param name New course name
     * @throws std::invalid_argument if name is empty
     */
    void setCourseName(const std::string& name);

    /**
     * @brief Sets the credit points
     * @param credits New credit points
     * @throws std::invalid_argument if credit points are invalid
     */
    void setCreditPoints(double credits);

    /**
     * @brief Sets the first exam date
     * @param dateA New first exam date
     * @throws std::invalid_argument if date is empty
     */
    void setExamDateA(const std::string& dateA);

    /**
     * @brief Sets the second exam date
     * @param dateB New second exam date
     * @throws std::invalid_argument if date is empty
     */
    void setExamDateB(const std::string& dateB);

    /**
     * @brief Sets the lecturer name
     * @param lect New lecturer name
     * @throws std::invalid_argument if name is empty
     */
    void setLecturer(const std::string& lect);

    // Operator overloads
    /**
     * @brief Equality operator
     * @param other Course to compare with
     * @return true if courses are equal, false otherwise
     */
    bool operator==(const Course& other) const;

    /**
     * @brief Inequality operator
     * @param other Course to compare with
     * @return true if courses are not equal, false otherwise
     */
    bool operator!=(const Course& other) const;

    /**
     * @brief Less than operator (compares by course number)
     * @param other Course to compare with
     * @return true if this course number is less than other's
     */
    bool operator<(const Course& other) const;

    /**
     * @brief Output stream operator
     * @param os Output stream
     * @param course Course object to output
     * @return Reference to output stream
     */
    friend std::ostream& operator<<(std::ostream& os, const Course& course);
};

#endif // COURSE_H
#ifndef DATAMANAGER_H
#define DATAMANAGER_H

#include <map>
#include <vector>
#include <string>
#include <memory>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <stdexcept>
#include "Course.h"
#include "Lesson.h"
#include "Lecture.h"
#include "Tutorial.h"  
#include "Lab.h"
#include "Schedule.h"

/**
 * @class DataManager
 * @brief Manages all data operations for the student scheduling system
 *
 * This class is responsible for:
 * - Loading courses from courses.csv
 * - Loading lessons from course-specific CSV files
 * - Loading and saving schedules from/to schedules.csv
 * - Providing data access interface for the CLI
 */
class DataManager {
private:
    std::map<int, Course> courses;                                    // All courses indexed by course ID
    std::map<int, std::vector<std::shared_ptr<Lesson>>> lessons;     // All lessons per course
    std::vector<Schedule> schedules;                                 // All student schedules
    int nextScheduleId;                                              // Auto-increment for schedule IDs

    // Private helper methods for file operations
    void loadCourses();
    void loadLessons();
    void loadSchedules();
    void loadLessonsForCourse(int courseId);
    std::vector<std::string> parseCSVLine(const std::string& line) const;
    std::string trimWhitespace(const std::string& str) const;

    // Helper functions for parsing your CSV format
    int convertDayNameToNumber(const std::string& dayName) const;
    int convertTimeToHour(const std::string& timeStr) const;
    std::string convertHourToTimeString(int hour) const; // ADDED: Convert hour back to time string
    std::string convertDayNumberToName(int dayNumber) const;
    std::shared_ptr<Lesson> parseLessonFromFields(int courseId, const std::vector<std::string>& fields, const std::string& lessonType) const;

public:
    /**
     * @brief Constructor - loads all data from CSV files
     * @throws std::runtime_error if critical files cannot be loaded
     */
    DataManager();

    /**
     * @brief Destructor - saves all schedules to CSV
     */
    ~DataManager();

    // Copy constructor and assignment operator (disabled for singleton-like behavior)
    DataManager(const DataManager&) = delete;
    DataManager& operator=(const DataManager&) = delete;

    // Course management
    /**
     * @brief Get all courses
     * @return const reference to courses map
     */
    const std::map<int, Course>& getAllCourses() const;

    /**
     * @brief Get specific course by ID
     * @param courseId the course identifier
     * @return const reference to the course
     * @throws std::invalid_argument if course not found
     */
    const Course& getCourseById(int courseId) const;

    /**
     * @brief Check if course exists
     * @param courseId the course identifier
     * @return true if course exists, false otherwise
     */
    bool courseExists(int courseId) const;

    // Lesson management
    /**
     * @brief Get all lessons for a specific course
     * @param courseId the course identifier
     * @return const reference to lessons vector
     * @throws std::invalid_argument if course not found
     */
    const std::vector<std::shared_ptr<Lesson>>& getLessonsByCourse(int courseId) const;

    /**
     * @brief Get specific lesson by course ID and group ID
     * @param courseId the course identifier
     * @param groupId the group identifier
     * @return shared pointer to the lesson
     * @throws std::invalid_argument if lesson not found
     */
    std::shared_ptr<Lesson> getLessonByGroup(int courseId, int groupId) const;

    //third own demanded method: print the list of the lessons by choosen day
    /**
     * @brief Print all lessons for a specific day
     * @param dayName the day name (Sunday, Monday, etc.)
     */
    void printLessonsByDay(const std::string& dayName) const;

    // Schedule management
    /**
     * @brief Get all schedules
     * @return const reference to schedules vector
     */
    const std::vector<Schedule>& getSchedules() const;

    /**
     * @brief Get specific schedule by ID
     * @param scheduleId the schedule identifier
     * @return const reference to the schedule
     * @throws std::invalid_argument if schedule not found
     */
    const Schedule& getScheduleById(int scheduleId) const;

    /**
     * @brief Get mutable reference to schedule by ID
     * @param scheduleId the schedule identifier
     * @return reference to the schedule
     * @throws std::invalid_argument if schedule not found
     */
    Schedule& getScheduleById(int scheduleId);

    /**
     * @brief Add new empty schedule
     * @return ID of the newly created schedule
     */
    int addSchedule();

    /**
     * @brief Remove schedule by ID
     * @param scheduleId the schedule identifier
     * @throws std::invalid_argument if schedule not found
     */
    void removeSchedule(int scheduleId);

    /**
     * @brief Add course to schedule
     * @param scheduleId the schedule identifier
     * @param courseId the course identifier
     * @param groupId the group identifier
     * @throws std::invalid_argument if schedule, course, or group not found
     * @throws std::runtime_error if there's a scheduling conflict
     */
    void addCourseToSchedule(int scheduleId, int courseId, int groupId);

    /**
     * @brief Remove course from schedule
     * @param scheduleId the schedule identifier
     * @param courseId the course identifier
     * @param groupId the group identifier
     * @throws std::invalid_argument if schedule, course, or group not found
     */
    void removeCourseFromSchedule(int scheduleId, int courseId, int groupId);

    /**
     * @brief Save all schedules to CSV file
     * @throws std::runtime_error if file cannot be written
     */
    void saveSchedules() const;

    /**
     * @brief Get next available schedule ID
     * @return next schedule ID
     */
    int getNextScheduleId() const;

    // Utility methods
    /**
     * @brief Get total number of courses
     * @return number of courses
     */
    size_t getCoursesCount() const;

    /**
     * @brief Get total number of schedules
     * @return number of schedules
     */
    size_t getSchedulesCount() const;

    // Iterator support for courses (for PrintCourses with pagination)
    using CourseIterator = std::map<int, Course>::const_iterator;
    CourseIterator coursesBegin() const;
    CourseIterator coursesEnd() const;
};

#endif // DATAMANAGER_H
#ifndef LESSON_H
#define LESSON_H

#include <string>
#include <iostream>
#include <stdexcept>

/**
 * @class Lesson
 * @brief Abstract base class representing a lesson in the schedule system
 *
 * This abstract class defines the common interface and data for all types
 * of lessons (lectures, tutorials, labs) in the academic schedule.
 */
class Lesson {
protected:
    int courseNumber;           ///< Course number this lesson belongs to
    int day;                    ///< Day of the week (1=Sunday, 2=Monday, etc.)
    int startHour;              ///< Start hour (24-hour format)
    int duration;               ///< Duration in hours
    std::string classroom;      ///< Room number and building
    std::string teacherName;    ///< Name of the teacher
    int groupNumber;            ///< Group number for this lesson

    /**
     * @brief Validates course number
     * @param courseNum The course number to validate
     * @throws std::invalid_argument if course number is invalid
     */
    void validateCourseNumber(int courseNum) const;

    /**
     * @brief Validates day (1-7)
     * @param dayNum The day to validate
     * @throws std::invalid_argument if day is invalid
     */
    void validateDay(int dayNum) const;

    /**
     * @brief Validates start hour (8-22)
     * @param hour The hour to validate
     * @throws std::invalid_argument if hour is invalid
     */
    void validateStartHour(int hour) const;

    /**
     * @brief Validates duration
     * @param dur The duration to validate
     * @throws std::invalid_argument if duration is invalid
     */
    void validateDuration(int dur) const;

    /**
     * @brief Validates group number
     * @param groupNum The group number to validate
     * @throws std::invalid_argument if group number is invalid
     */
    void validateGroupNumber(int groupNum) const;

    /**
     * @brief Validates that a string is not empty
     * @param str The string to validate
     * @param fieldName The name of the field for error messages
     * @throws std::invalid_argument if string is empty
     */
    void validateNonEmptyString(const std::string& str, const std::string& fieldName) const;

public:
    /**
     * @brief Default constructor
     */
    Lesson();

    /**
     * @brief Parameterized constructor
     * @param courseNum Course number
     * @param dayNum Day of the week (1-7)
     * @param startHourNum Start hour (24-hour format)
     * @param dur Duration in hours
     * @param room Classroom
     * @param teacher Teacher name
     * @param groupNum Group number
     * @throws std::invalid_argument if any parameter is invalid
     */
    Lesson(int courseNum, int dayNum, int startHourNum, int dur,
        const std::string& room, const std::string& teacher, int groupNum);

    /**
     * @brief Copy constructor
     * @param other Lesson object to copy from
     */
    Lesson(const Lesson& other);

    /**
     * @brief Assignment operator
     * @param other Lesson object to assign from
     * @return Reference to this object
     */
    Lesson& operator=(const Lesson& other);

    /**
     * @brief Virtual destructor
     */
    virtual ~Lesson() = default;

    /**
     * @brief Creates a deep copy of the Lesson object (pure virtual).
     * @return A pointer to a newly created Lesson object (or derived type).
     */
    virtual Lesson* clone() const = 0;

    // Getter methods - REQUIRED BY DATAMANAGER
    /**
     * @brief Gets the course number (required by DataManager)
     * @return Course number
     */
    int getCourseId() const;

    /**
     * @brief Gets the group number (required by DataManager)
     * @return Group number
     */
    int getGroupId() const;

    /**
     * @brief Gets the course number (legacy method)
     * @return Course number
     */
    int getCourseNumber() const;

    /**
     * @brief Gets the day
     * @return Day of the week (1-7)
     */
    int getDay() const;

    /**
     * @brief Gets the start hour
     * @return Start hour
     */
    int getStartHour() const;

    /**
     * @brief Gets the duration
     * @return Duration in hours
     */
    int getDuration() const;

    /**
     * @brief Gets the classroom
     * @return Classroom
     */
    const std::string& getClassroom() const;

    /**
     * @brief Gets the teacher name
     * @return Teacher name
     */
    const std::string& getTeacherName() const;

    /**
     * @brief Gets the group number (legacy method)
     * @return Group number
     */
    int getGroupNumber() const;

    // Setter methods
    /**
     * @brief Sets the course number
     * @param courseNum New course number
     * @throws std::invalid_argument if course number is invalid
     */
    void setCourseNumber(int courseNum);

    /**
     * @brief Sets the day
     * @param dayNum New day
     * @throws std::invalid_argument if day is invalid
     */
    void setDay(int dayNum);

    /**
     * @brief Sets the start hour
     * @param hour New start hour
     * @throws std::invalid_argument if hour is invalid
     */
    void setStartHour(int hour);

    /**
     * @brief Sets the duration
     * @param dur New duration
     * @throws std::invalid_argument if duration is invalid
     */
    void setDuration(int dur);

    /**
     * @brief Sets the classroom
     * @param room New classroom
     * @throws std::invalid_argument if classroom is empty
     */
    void setClassroom(const std::string& room);

    /**
     * @brief Sets the teacher name
     * @param teacher New teacher name
     * @throws std::invalid_argument if name is empty
     */
    void setTeacherName(const std::string& teacher);

    /**
     * @brief Sets the group number
     * @param groupNum New group number
     * @throws std::invalid_argument if group number is invalid
     */
    void setGroupNumber(int groupNum);

    // Time conflict checking methods
    /**
     * @brief Checks if this lesson conflicts with another lesson
     * @param other The other lesson to check against
     * @return true if there is a time conflict, false otherwise
     */
    bool hasConflictWith(const Lesson& other) const;

    /**
     * @brief Gets the end hour of this lesson
     * @return End hour (start hour + duration)
     */
    int getEndHour() const;

    // Pure virtual methods - must be implemented by derived classes
    /**
     * @brief Gets the lesson type (pure virtual)
     * @return String representing the lesson type
     */
    virtual std::string getLessonType() const = 0;

    /**
     * @brief Displays lesson-specific information (pure virtual)
     */
    virtual void displaySpecificInfo() const = 0;

    // Operator overloads
    /**
     * @brief Equality operator
     * @param other Lesson to compare with
     * @return true if lessons are equal, false otherwise
     */
    virtual bool operator==(const Lesson& other) const;

    /**
     * @brief Inequality operator
     * @param other Lesson to compare with
     * @return true if lessons are not equal, false otherwise
     */
    bool operator!=(const Lesson& other) const;

    /**
     * @brief Less than operator (compares by course number, then group number)
     * @param other Lesson to compare with
     * @return true if this lesson is less than other
     */
    bool operator<(const Lesson& other) const;

    /**
     * @brief Output stream operator
     * @param os Output stream
     * @param lesson Lesson object to output
     * @return Reference to output stream
     */
    friend std::ostream& operator<<(std::ostream& os, const Lesson& lesson);
};

#endif // LESSON_H
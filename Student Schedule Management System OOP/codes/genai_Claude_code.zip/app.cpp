#include "DataManager.h"
#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <algorithm>
#include <crtdbg.h>

/**
 * @brief Splits a string into tokens by space delimiter
 * @param str The string to split
 * @return Vector of tokens
 */
std::vector<std::string> splitString(const std::string& str) {
    std::vector<std::string> tokens;
    std::stringstream ss(str);
    std::string token;

    while (ss >> token) {
        tokens.push_back(token);
    }

    return tokens;
}

/**
 * @brief Trims whitespace from both ends of a string
 * @param str The string to trim
 * @return Trimmed string
 */
std::string trimString(const std::string& str) {
    size_t start = str.find_first_not_of(" \t\r\n");
    if (start == std::string::npos) return "";

    size_t end = str.find_last_not_of(" \t\r\n");
    return str.substr(start, end - start + 1);
}

/**
 * @brief Prints a specific course with all its lessons
 * @param dm DataManager reference
 * @param courseId Course ID to print
 */
void printCourseCommand(const DataManager& dm, int courseId) {
    try {
        const Course& course = dm.getCourseById(courseId);
        std::cout << course << std::endl;

        // Print all lessons for this course
        try {
            const std::vector<std::shared_ptr<Lesson>>& lessons = dm.getLessonsByCourse(courseId);
            std::cout << "\nLessons for this course:" << std::endl;

            for (size_t i = 0; i < lessons.size(); ++i) {
                std::cout << "  " << *lessons[i] << std::endl;
            }
        }
        catch (const std::exception& e) {
            std::cout << "No lessons found for this course." << std::endl;
        }
        std::cout << std::endl;
    }
    catch (const std::exception& e) {
        std::cout << "Error: " << e.what() << std::endl;
    }
}

/**
 * @brief Prints courses with pagination support
 * @param dm DataManager reference
 * @param startIndex Starting index for pagination
 * @param currentIndex Reference to update current position
 * @return true if more courses exist, false otherwise
 */
bool printCoursesCommand(const DataManager& dm, int startIndex, int& currentIndex) {
    const std::map<int, Course>& courses = dm.getAllCourses();

    if (courses.empty()) {
        std::cout << "No courses available." << std::endl;
        return false;
    }

    std::map<int, Course>::const_iterator it = courses.begin();
    std::advance(it, startIndex);

    int count = 0;
    currentIndex = startIndex;

    for (; it != courses.end() && count < 10; ++it, ++count, ++currentIndex) {
        std::cout << it->second << std::endl << std::endl;
    }

    // Return true if there are more courses
    return (it != courses.end());
}

/**
 * @brief Prints a specific schedule
 * @param dm DataManager reference
 * @param scheduleId Schedule ID to print
 */
void printScheduleCommand(const DataManager& dm, int scheduleId) {
    try {
        const Schedule& schedule = dm.getScheduleById(scheduleId);
        schedule.printScheduleTable();
    }
    catch (const std::exception& e) {
        std::cout << "Error: " << e.what() << std::endl;
    }
}

/**
 * @brief Prints all schedules
 * @param dm DataManager reference
 */
void printSchedulesCommand(const DataManager& dm) {
    const std::vector<Schedule>& schedules = dm.getSchedules();

    if (schedules.empty()) {
        std::cout << "No schedules available." << std::endl;
        return;
    }

    std::cout << "=== All Schedules ===" << std::endl;
    for (size_t i = 0; i < schedules.size(); ++i) {
        schedules[i].printScheduleTable();
        if (i < schedules.size() - 1) {
            std::cout << "----------------------------------------" << std::endl;
        }
    }
}

/**
 * @brief Adds a new empty schedule
 * @param dm DataManager reference
 */
void addScheduleCommand(DataManager& dm) {
    try {
        int newScheduleId = dm.addSchedule();
        std::cout << "Successfully created new schedule with ID: " << newScheduleId << std::endl;
    }
    catch (const std::exception& e) {
        std::cout << "Error creating schedule: " << e.what() << std::endl;
    }
}

/**
 * @brief Removes a schedule by ID
 * @param dm DataManager reference
 * @param scheduleId Schedule ID to remove
 */
void removeScheduleCommand(DataManager& dm, int scheduleId) {
    try {
        dm.removeSchedule(scheduleId);
        std::cout << "Successfully removed schedule " << scheduleId << std::endl;
        std::cout << "Schedule IDs have been updated to maintain sequential numbering." << std::endl;
    }
    catch (const std::exception& e) {
        std::cout << "Error removing schedule: " << e.what() << std::endl;
    }
}

/**
 * @brief Adds a course to a schedule
 * @param dm DataManager reference
 * @param scheduleId Schedule ID
 * @param courseId Course ID
 * @param groupId Group ID
 */
void addCourseToScheduleCommand(DataManager& dm, int scheduleId, int courseId, int groupId) {
    try {
        dm.addCourseToSchedule(scheduleId, courseId, groupId);
        std::cout << "Successfully added course " << courseId
            << " (group " << groupId << ") to schedule " << scheduleId << std::endl;
    }
    catch (const std::exception& e) {
        std::cout << "Error adding course to schedule: " << e.what() << std::endl;
    }
}

/**
 * @brief Prints overlapping lessons in a specific schedule
 * @param dm DataManager reference
 * @param scheduleId Schedule ID to check for overlaps
 */
void overlapLessonsCommand(const DataManager& dm, int scheduleId) {
    try {
        const Schedule& schedule = dm.getScheduleById(scheduleId);
        schedule.printOverlappingLessons();
    }
    catch (const std::exception& e) {
        std::cout << "Error: " << e.what() << std::endl;
    }
}

/**
 * @brief Prints total credits in a specific schedule
 * @param dm DataManager reference
 * @param scheduleId Schedule ID to calculate credits for
 */
void totalCreditsCommand(const DataManager& dm, int scheduleId) {
    try {
        const Schedule& schedule = dm.getScheduleById(scheduleId);
        const std::map<int, Course>& courses = dm.getAllCourses();
        schedule.printTotalCredits(courses);
    }
    catch (const std::exception& e) {
        std::cout << "Error: " << e.what() << std::endl;
    }
}

/**
 * @brief Prints lessons for a specific day
 * @param dm DataManager reference
 * @param dayName Day name (Sunday, Monday, etc.)
 */
void lessonsDayCommand(const DataManager& dm, const std::string& dayName) {
    dm.printLessonsByDay(dayName);
}

/**
 * @brief Removes a course from a schedule
 * @param dm DataManager reference
 * @param scheduleId Schedule ID
 * @param courseId Course ID
 * @param groupId Group ID
 */
void removeCourseFromScheduleCommand(DataManager& dm, int scheduleId, int courseId, int groupId) {
    try {
        dm.removeCourseFromSchedule(scheduleId, courseId, groupId);
        std::cout << "Successfully removed course " << courseId
            << " (group " << groupId << ") from schedule " << scheduleId << std::endl;
    }
    catch (const std::exception& e) {
        std::cout << "Error removing course from schedule: " << e.what() << std::endl;
    }
}

/**
 * @brief Displays available commands
 */
void displayHelp() {
    std::cout << "\n=== Available Commands ===" << std::endl;
    std::cout << "PrintCourse <course_id>                    - Print specific course details" << std::endl;
    std::cout << "PrintCourses                               - Print first 10 courses" << std::endl;
    std::cout << "More                                       - Print next 10 courses (after PrintCourses)" << std::endl;
    std::cout << "PrintSchedule <schedule_id>                - Print specific schedule" << std::endl;
    std::cout << "PrintSchedules                             - Print all schedules" << std::endl;
    std::cout << "AddSchedule                                - Add new empty schedule" << std::endl;
    std::cout << "RmSchedule <schedule_id>                   - Remove schedule" << std::endl;
    std::cout << "Add <schedule_id> <course_id> <group_id>   - Add course to schedule" << std::endl;
    std::cout << "Rm <schedule_id> <course_id> <group_id>    - Remove course from schedule" << std::endl;
    std::cout << "OverlapLessons <schedule_id>               - Show overlapping lessons in schedule" << std::endl;
    std::cout << "TotalCredits <schedule_id>                 - Show total credits in schedule" << std::endl;
    std::cout << "LessonsDay <day_name>                      - Show all lessons for specific day" << std::endl;
    std::cout << "help                                       - Show this help message" << std::endl;
    std::cout << "exit                                       - Exit the program" << std::endl;
    std::cout << "=========================" << std::endl << std::endl;
}

/**
 * @brief Main function - Entry point of the CLI application
 */
int main() {
    _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);

  //  std::cout << "=== Student Schedule Management System ===" << std::endl;
 //   std::cout << "Loading data..." << std::endl;

    try {
        // Initialize DataManager - loads all CSV files
        DataManager dm;
   //     std::cout << "System initialized successfully!" << std::endl;
   //     std::cout << "Loaded " << dm.getCoursesCount() << " courses and "
    //        << dm.getSchedulesCount() << " schedules." << std::endl;

        // Display help
        displayHelp();

        // State variables for pagination
        int courseIndex = 0;
        bool lastCommandWasPrintCourses = false;

        std::string input;

        // Main command loop - FIX: Proper loop condition and exit handling
        while (true) {
            std::cout << "> ";

            // Check if getline succeeded
            if (!std::getline(std::cin, input)) {
                // EOF or error occurred - break the loop
                break;
            }

            input = trimString(input);

            if (input.empty()) {
                continue;
            }

            // Parse command
            std::vector<std::string> tokens = splitString(input);
            std::string command = tokens[0];

            // Convert command to lowercase for case-insensitive comparison
            std::transform(command.begin(), command.end(), command.begin(), ::tolower);

            // Process commands
            if (command == "exit") {
                std::cout << "Saving data and exiting..." << std::endl;
                break; // Proper exit from loop
            }
            else if (command == "help") {
                displayHelp();
                lastCommandWasPrintCourses = false;
            }
            else if (command == "printcourse") {
                if (tokens.size() != 2) {
                    std::cout << "Usage: PrintCourse <course_id>" << std::endl;
                }
                else {
                    try {
                        int courseId = std::stoi(tokens[1]);
                        printCourseCommand(dm, courseId);
                    }
                    catch (const std::invalid_argument&) {
                        std::cout << "Error: Invalid course ID. Please enter a number." << std::endl;
                    }
                    catch (const std::out_of_range&) {
                        std::cout << "Error: Course ID out of range." << std::endl;
                    }
                }
                lastCommandWasPrintCourses = false;
            }
            else if (command == "printcourses") {
                courseIndex = 0;
                bool hasMore = printCoursesCommand(dm, courseIndex, courseIndex);
                if (hasMore) {
                    std::cout << "Use 'More' to see additional courses." << std::endl;
                }
                lastCommandWasPrintCourses = true;
            }
            else if (command == "more") {
                if (!lastCommandWasPrintCourses) {
                    std::cout << "Error: 'More' command can only be used after 'PrintCourses'." << std::endl;
                }
                else {
                    bool hasMore = printCoursesCommand(dm, courseIndex, courseIndex);
                    if (!hasMore) {
                        std::cout << "No more courses to display." << std::endl;
                        lastCommandWasPrintCourses = false;
                    }
                }
            }
            else if (command == "printschedule") {
                if (tokens.size() != 2) {
                    std::cout << "Usage: PrintSchedule <schedule_id>" << std::endl;
                }
                else {
                    try {
                        int scheduleId = std::stoi(tokens[1]);
                        printScheduleCommand(dm, scheduleId);
                    }
                    catch (const std::invalid_argument&) {
                        std::cout << "Error: Invalid schedule ID. Please enter a number." << std::endl;
                    }
                    catch (const std::out_of_range&) {
                        std::cout << "Error: Schedule ID out of range." << std::endl;
                    }
                }
                lastCommandWasPrintCourses = false;
            }
            else if (command == "printschedules") {
                printSchedulesCommand(dm);
                lastCommandWasPrintCourses = false;
            }
            else if (command == "addschedule") {
                addScheduleCommand(dm);
                dm.saveSchedules(); // Save immediately after adding schedule
                lastCommandWasPrintCourses = false;
            }
            else if (command == "rmschedule") {
                if (tokens.size() != 2) {
                    std::cout << "Usage: RmSchedule <schedule_id>" << std::endl;
                }
                else {
                    try {
                        int scheduleId = std::stoi(tokens[1]);
                        removeScheduleCommand(dm, scheduleId);
                        dm.saveSchedules(); // Save immediately after removing schedule
                    }
                    catch (const std::invalid_argument&) {
                        std::cout << "Error: Invalid schedule ID. Please enter a number." << std::endl;
                    }
                    catch (const std::out_of_range&) {
                        std::cout << "Error: Schedule ID out of range." << std::endl;
                    }
                }
                lastCommandWasPrintCourses = false;
            }
            else if (command == "overlaplessons") {
                if (tokens.size() != 2) {
                    std::cout << "Usage: OverlapLessons <schedule_id>" << std::endl;
                }
                else {
                    try {
                        int scheduleId = std::stoi(tokens[1]);
                        overlapLessonsCommand(dm, scheduleId);
                    }
                    catch (const std::invalid_argument&) {
                        std::cout << "Error: Invalid schedule ID. Please enter a number." << std::endl;
                    }
                    catch (const std::out_of_range&) {
                        std::cout << "Error: Schedule ID out of range." << std::endl;
                    }
                }
                lastCommandWasPrintCourses = false;
            }
            else if (command == "totalcredits") {
                if (tokens.size() != 2) {
                    std::cout << "Usage: TotalCredits <schedule_id>" << std::endl;
                }
                else {
                    try {
                        int scheduleId = std::stoi(tokens[1]);
                        totalCreditsCommand(dm, scheduleId);
                    }
                    catch (const std::invalid_argument&) {
                        std::cout << "Error: Invalid schedule ID. Please enter a number." << std::endl;
                    }
                    catch (const std::out_of_range&) {
                        std::cout << "Error: Schedule ID out of range." << std::endl;
                    }
                }
                lastCommandWasPrintCourses = false;
            }
            else if (command == "lessonsday") {
                if (tokens.size() != 2) {
                    std::cout << "Usage: LessonsDay <day_name>" << std::endl;
                    std::cout << "Valid days: Sunday, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday" << std::endl;
                }
                else {
                    std::string dayName = tokens[1];
                    // Capitalize first letter for consistency
                    if (!dayName.empty()) {
                        dayName[0] = std::toupper(dayName[0]);
                        for (size_t i = 1; i < dayName.length(); ++i) {
                            dayName[i] = std::tolower(dayName[i]);
                        }
                    }
                    lessonsDayCommand(dm, dayName);
                }
                lastCommandWasPrintCourses = false;
            }
            else if (command == "add") {
                if (tokens.size() != 4) {
                    std::cout << "Usage: Add <schedule_id> <course_id> <group_id>" << std::endl;
                }
                else {
                    try {
                        int scheduleId = std::stoi(tokens[1]);
                        int courseId = std::stoi(tokens[2]);
                        int groupId = std::stoi(tokens[3]);
                        addCourseToScheduleCommand(dm, scheduleId, courseId, groupId);
                        dm.saveSchedules(); // Save immediately after adding course
                    }
                    catch (const std::invalid_argument&) {
                        std::cout << "Error: Invalid parameters. Please enter numbers only." << std::endl;
                    }
                    catch (const std::out_of_range&) {
                        std::cout << "Error: One or more parameters out of range." << std::endl;
                    }
                }
                lastCommandWasPrintCourses = false;
            }
            else if (command == "rm") {
                if (tokens.size() != 4) {
                    std::cout << "Usage: Rm <schedule_id> <course_id> <group_id>" << std::endl;
                }
                else {
                    try {
                        int scheduleId = std::stoi(tokens[1]);
                        int courseId = std::stoi(tokens[2]);
                        int groupId = std::stoi(tokens[3]);
                        removeCourseFromScheduleCommand(dm, scheduleId, courseId, groupId);
                        dm.saveSchedules(); // Save immediately after removing course
                    }
                    catch (const std::invalid_argument&) {
                        std::cout << "Error: Invalid parameters. Please enter numbers only." << std::endl;
                    }
                    catch (const std::out_of_range&) {
                        std::cout << "Error: One or more parameters out of range." << std::endl;
                    }
                }
                lastCommandWasPrintCourses = false;
            }
            else {
                std::cout << "Unknown command: " << command << std::endl;
                std::cout << "Type 'help' to see available commands." << std::endl;
                lastCommandWasPrintCourses = false;
            }
        } // End of main loop

        std::cout << "Data saved successfully. Goodbye!" << std::endl;

    }
    catch (const std::exception& e) {
        std::cerr << "Fatal error: " << e.what() << std::endl;
        std::cerr << "Please check that all required CSV files exist and are properly formatted." << std::endl;
        return 1;
    }

    // Check for memory leaks
    int leaks = _CrtDumpMemoryLeaks();
    std::cout << "Leaks: " << leaks << std::endl;

    return 0;
}
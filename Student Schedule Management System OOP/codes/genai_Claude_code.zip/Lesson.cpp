#include "Lesson.h"
#include <sstream>

// Validation methods
void Lesson::validateCourseNumber(int courseNum) const {
    if (courseNum < 1000 || courseNum > 99999) {
        throw std::invalid_argument("Course number must be between 1000 and 99999");
    }
}

void Lesson::validateDay(int dayNum) const {
    if (dayNum < 1 || dayNum > 7) {
        throw std::invalid_argument("Day must be between 1 (Sunday) and 7 (Saturday)");
    }
}

void Lesson::validateStartHour(int hour) const {
    if (hour < 8 || hour > 20) {
        throw std::invalid_argument("Start hour must be between 8 and 20 (8:30-20:50 academic time)");
    }
}

void Lesson::validateDuration(int dur) const {
    if (dur < 1 || dur > 8) {
        throw std::invalid_argument("Duration must be between 1 and 8 hours");
    }
}

void Lesson::validateGroupNumber(int groupNum) const {
    if (groupNum < 1) {
        throw std::invalid_argument("Group number must be positive");
    }
}

void Lesson::validateNonEmptyString(const std::string& str, const std::string& fieldName) const {
    if (str.empty()) {
        throw std::invalid_argument(fieldName + " cannot be empty");
    }
}

// Constructors
Lesson::Lesson()
    : courseNumber(0), day(1), startHour(8), duration(1),
    classroom(""), teacherName(""), groupNumber(1) {
}

Lesson::Lesson(int courseNum, int dayNum, int startHourNum, int dur,
    const std::string& room, const std::string& teacher, int groupNum)
    : courseNumber(courseNum), day(dayNum), startHour(startHourNum),
    duration(dur), classroom(room), teacherName(teacher), groupNumber(groupNum) {

    validateCourseNumber(courseNum);
    validateDay(dayNum);
    validateStartHour(startHourNum);
    validateDuration(dur);
    validateNonEmptyString(room, "Classroom");
    validateNonEmptyString(teacher, "Teacher name");
    validateGroupNumber(groupNum);
}

Lesson::Lesson(const Lesson& other)
    : courseNumber(other.courseNumber), day(other.day), startHour(other.startHour),
    duration(other.duration), classroom(other.classroom),
    teacherName(other.teacherName), groupNumber(other.groupNumber) {
}

Lesson& Lesson::operator=(const Lesson& other) {
    if (this != &other) {
        courseNumber = other.courseNumber;
        day = other.day;
        startHour = other.startHour;
        duration = other.duration;
        classroom = other.classroom;
        teacherName = other.teacherName;
        groupNumber = other.groupNumber;
    }
    return *this;
}

// Getter methods
int Lesson::getCourseId() const {
    return courseNumber;
}

int Lesson::getGroupId() const {
    return groupNumber;
}

int Lesson::getCourseNumber() const {
    return courseNumber;
}

int Lesson::getDay() const {
    return day;
}

int Lesson::getStartHour() const {
    return startHour;
}

int Lesson::getDuration() const {
    return duration;
}

const std::string& Lesson::getClassroom() const {
    return classroom;
}

const std::string& Lesson::getTeacherName() const {
    return teacherName;
}

int Lesson::getGroupNumber() const {
    return groupNumber;
}

int Lesson::getEndHour() const {
    return startHour + duration;
}

// Setter methods
void Lesson::setCourseNumber(int courseNum) {
    validateCourseNumber(courseNum);
    courseNumber = courseNum;
}

void Lesson::setDay(int dayNum) {
    validateDay(dayNum);
    day = dayNum;
}

void Lesson::setStartHour(int hour) {
    validateStartHour(hour);
    startHour = hour;
}

void Lesson::setDuration(int dur) {
    validateDuration(dur);
    duration = dur;
}

void Lesson::setClassroom(const std::string& room) {
    validateNonEmptyString(room, "Classroom");
    classroom = room;
}

void Lesson::setTeacherName(const std::string& teacher) {
    validateNonEmptyString(teacher, "Teacher name");
    teacherName = teacher;
}

void Lesson::setGroupNumber(int groupNum) {
    validateGroupNumber(groupNum);
    groupNumber = groupNum;
}

// Time conflict checking
bool Lesson::hasConflictWith(const Lesson& other) const {
    // Different days - no conflict
    if (day != other.day) {
        return false;
    }

    // Check time overlap
    int thisEnd = startHour + duration;
    int otherEnd = other.startHour + other.duration;

    return !(thisEnd <= other.startHour || startHour >= otherEnd);
}

// Operator overloads
bool Lesson::operator==(const Lesson& other) const {
    return courseNumber == other.courseNumber &&
        day == other.day &&
        startHour == other.startHour &&
        duration == other.duration &&
        classroom == other.classroom &&
        teacherName == other.teacherName &&
        groupNumber == other.groupNumber;
}

bool Lesson::operator!=(const Lesson& other) const {
    return !(*this == other);
}

bool Lesson::operator<(const Lesson& other) const {
    if (courseNumber != other.courseNumber) {
        return courseNumber < other.courseNumber;
    }
    return groupNumber < other.groupNumber;
}

std::ostream& operator<<(std::ostream& os, const Lesson& lesson) {
    os << "Course: " << lesson.courseNumber
        << ", Type: " << lesson.getLessonType()
        << ", Day: " << lesson.day
        << ", Start: " << lesson.startHour << ":00"
        << ", Duration: " << lesson.duration << "h"
        << ", Room: " << lesson.classroom
        << ", Teacher: " << lesson.teacherName
        << ", Group: " << lesson.groupNumber;
    return os;
}
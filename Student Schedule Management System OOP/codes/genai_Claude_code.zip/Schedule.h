#ifndef SCHEDULE_H
#define SCHEDULE_H

#include "Lesson.h"
#include "Course.h"
#include <vector>
#include <memory>
#include <iostream>
#include <map>
#include <string>

/**
 * @class Schedule
 * @brief Simple schedule class focused on DataManager compatibility
 */
class Schedule {
private:
    int scheduleId;
    std::vector<std::shared_ptr<Lesson>> lessons;
    // smart pointer that responsible automatic memory management:prevents memory leaks

    // Helper methods for time checking
    bool isLessonActiveAtTime(int lessonStartHour, int durationHours, const std::string& timeSlot) const;
    std::string convertHourToAcademicTime(int hour) const; // ADDED: Convert internal hour to academic time format

public:
    // Constructors required by DataManager
    Schedule();
    Schedule(int id);

    // Copy constructor and assignment operator
    Schedule(const Schedule& other);
    Schedule& operator=(const Schedule& other);

    // Destructor
    ~Schedule() = default;

    // Core methods required by DataManager
    int getScheduleId() const;
    void setScheduleId(int id);

    const std::vector<std::shared_ptr<Lesson>>& getLessons() const;

    void addLesson(std::shared_ptr<Lesson> lesson);
    bool removeLesson(std::shared_ptr<Lesson> lesson);
    bool hasConflict(std::shared_ptr<Lesson> lesson) const;

    // Display method
    void printScheduleTable() const;

    //first demand method: print overlaps lessons in the schedule
    void printOverlappingLessons() const;

    //second own demanded method: print the sum of credits in the schedule
    void printTotalCredits(const std::map<int, Course>& courses) const;

    // Utility methods
    size_t getLessonsCount() const;
    bool isEmpty() const;
    void clear();

    // Operators
    bool operator==(const Schedule& other) const;
    bool operator!=(const Schedule& other) const;
    friend std::ostream& operator<<(std::ostream& os, const Schedule& schedule);
};

#endif // SCHEDULE_H
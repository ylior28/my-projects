#ifndef TUTORIAL_H
#define TUTORIAL_H

#include "Lesson.h"

/**
 * @class Tutorial
 * @brief Represents a tutorial lesson in the schedule system
 *
 * This class inherits from Lesson and represents tutorial-type lessons.
 * Tutorials are typically smaller practice sessions with exercises.
 */
class Tutorial : public Lesson {
public:
    /**
     * @brief Default constructor
     */
    Tutorial();

    /**
     * @brief Parameterized constructor (updated for DataManager compatibility)
     * @param courseNum Course number
     * @param dayNum Day of the week (1-7, 1=Sunday)
     * @param startHourNum Start hour (24-hour format)
     * @param dur Duration in hours
     * @param room Classroom (room + building)
     * @param teacher Teacher name
     * @param groupNum Group number
     * @throws std::invalid_argument if any parameter is invalid
     */
    Tutorial(int courseNum, int dayNum, int startHourNum, int dur,
        const std::string& room, const std::string& teacher, int groupNum);

    /**
     * @brief Copy constructor
     * @param other Tutorial object to copy from
     */
    Tutorial(const Tutorial& other);

    /**
     * @brief Assignment operator
     * @param other Tutorial object to assign from
     * @return Reference to this object
     */
    Tutorial& operator=(const Tutorial& other);

    /**
     * @brief Virtual destructor
     */
    virtual ~Tutorial() = default;

    /**
     * @brief Gets the lesson type
     * @return String "Tutorial"
     */
    virtual std::string getLessonType() const override;

    /**
     * @brief Displays tutorial-specific information
     */
    virtual void displaySpecificInfo() const override;

    /**
     * @brief Clone method for polymorphic copying
     * @return Pointer to a new Tutorial object that is a copy of this one
     */
    virtual Tutorial* clone() const override;
};

#endif // TUTORIAL_H
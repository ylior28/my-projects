#include "Course.h"
#include <sstream>

// Private validation methods
void Course::validateCourseNumber(int courseNum) const {
    if (courseNum < 1000 || courseNum > 99999) {
        throw std::invalid_argument("Course number must be between 1000 and 99999");
    }
}

void Course::validateCreditPoints(double  credits) const {
    if (credits <= 0 || credits > 20) {
        throw std::invalid_argument("Credit points must be between 1 and 20");
    }
}

void Course::validateNonEmptyString(const std::string& str, const std::string& fieldName) const {
    if (str.empty()) {
        throw std::invalid_argument(fieldName + " cannot be empty");
    }
}

// Constructors
Course::Course()
    : courseNumber(0), courseName(""), creditPoints(0),
    examDateA(""), examDateB(""), lecturer("") {
}

Course::Course(int courseNum, const std::string& name, double credits,
    const std::string& dateA, const std::string& dateB,
    const std::string& lect)
    : courseNumber(courseNum), courseName(name), creditPoints(credits),
    examDateA(dateA), examDateB(dateB), lecturer(lect) {

    try {
        validateCourseNumber(courseNum);
        validateNonEmptyString(name, "Course name");
        validateCreditPoints(credits);
        validateNonEmptyString(dateA, "Exam date A");
        validateNonEmptyString(dateB, "Exam date B");
        validateNonEmptyString(lect, "Lecturer name");
    }
    catch (const std::invalid_argument& e) {
        // Reset to default values if validation fails
        courseNumber = 0;
        courseName = "";
        creditPoints = 0;
        examDateA = "";
        examDateB = "";
        lecturer = "";
        throw; // Re-throw the exception
    }
}

Course::Course(const Course& other)
    : courseNumber(other.courseNumber), courseName(other.courseName),
    creditPoints(other.creditPoints), examDateA(other.examDateA),
    examDateB(other.examDateB), lecturer(other.lecturer) {
}

// Assignment operator
Course& Course::operator=(const Course& other) {
    if (this != &other) {
        courseNumber = other.courseNumber;
        courseName = other.courseName;
        creditPoints = other.creditPoints;
        examDateA = other.examDateA;
        examDateB = other.examDateB;
        lecturer = other.lecturer;
    }
    return *this;
}

// Getter methods
int Course::getCourseNumber() const {
    return courseNumber;
}

const std::string& Course::getCourseName() const {
    return courseName;
}

double Course::getCreditPoints() const {
    return creditPoints;
}

const std::string& Course::getExamDateA() const {
    return examDateA;
}

const std::string& Course::getExamDateB() const {
    return examDateB;
}

const std::string& Course::getLecturer() const {
    return lecturer;
}

// Setter methods
void Course::setCourseNumber(int courseNum) {
    validateCourseNumber(courseNum);
    courseNumber = courseNum;
}

void Course::setCourseName(const std::string& name) {
    validateNonEmptyString(name, "Course name");
    courseName = name;
}

void Course::setCreditPoints(double credits) {
    validateCreditPoints(credits);
    creditPoints = credits;
}

void Course::setExamDateA(const std::string& dateA) {
    validateNonEmptyString(dateA, "Exam date A");
    examDateA = dateA;
}

void Course::setExamDateB(const std::string& dateB) {
    validateNonEmptyString(dateB, "Exam date B");
    examDateB = dateB;
}

void Course::setLecturer(const std::string& lect) {
    validateNonEmptyString(lect, "Lecturer name");
    lecturer = lect;
}

// Operator overloads
bool Course::operator==(const Course& other) const {
    return courseNumber == other.courseNumber &&
        courseName == other.courseName &&
        creditPoints == other.creditPoints &&
        examDateA == other.examDateA &&
        examDateB == other.examDateB &&
        lecturer == other.lecturer;
}

bool Course::operator!=(const Course& other) const {
    return !(*this == other);
}

bool Course::operator<(const Course& other) const {
    return courseNumber < other.courseNumber;
}

std::ostream& operator<<(std::ostream& os, const Course& course) {
    os << "Course [" << course.courseNumber << "]: " << course.courseName
        << " (" << course.creditPoints << " credits)" << std::endl
        << "  Lecturer: " << course.lecturer << std::endl
        << "  Exam A: " << course.examDateA << std::endl
        << "  Exam B: " << course.examDateB;
    return os;
}
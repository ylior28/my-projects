from google.colab import drive
import matplotlib.pyplot as plt
import seaborn as sns
import tensorflow
import tensorflow as tf
from tensorflow import keras
from keras import optimizers
from keras.callbacks import ReduceLROnPlateau
from keras.models import Sequential
from keras.layers import Dense, Conv2D , MaxPool2D , Flatten , Dropout , BatchNormalization
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report,confusion_matrix
from sklearn.metrics import confusion_matrix, precision_score, recall_score, f1_score, precision_recall_curve
import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import os
import cv2 as cv
import random
from sklearn.metrics import auc
from tensorflow.keras.applications import MobileNetV2
from glob import glob
from PIL import Image
import re
from tensorflow.keras import layers


#########################################################################################
######## RECIEVE DATA ###################################################################

#import dataset from google drive (run in colab)
drive.mount('/content/drive')

paths = [] #TOTAL 5866
for dirname, _, filenames in os.walk('/content/drive/My Drive/chest_xray'):
    for filename in filenames:
        paths.append(os.path.join(dirname, filename))

#separate to 2 lists of normal and pneumonia
normal = []
pneumonia = []
for img in paths:
    if ".DS_Store" in img:
        pass
    elif "NORMAL" in img:
        normal.append((img, 0))  #Label 0, Total NORMAL:1585
    else:
        pneumonia.append(img)   #Total PNEUMONIA:4273


#separate pneumonia list to 2 lists of bacteria and virus
bacteria = []
virus = []
for i in pneumonia:
    if "bacteria" in i:
        bacteria.append((i, 1))  #Label 1, Total BACTERIS images:2780
    elif "virus" in i:
        virus.append((i, 2))  #Label 2, Total VIRUS:1493

#arrage the lists randomally
random.shuffle(normal)
random.shuffle(bacteria)
random.shuffle(virus)

# Initialize train, test, and validation lists
train = []
test = []
val = []

#Makes sure that train list will have at least 200 of normal and 200 of pneumonia but not more than 60%
train_size_normal = max(200, int(0.6 * len(normal)))      #Takes the max images from (200,60%)
train_size_bacteria = max(100, int(0.6 * len(bacteria)))  #Takes the max images from (100,60%)
train_size_virus = max(100, int(0.6 * len(virus)))        #Takes the max images from (100,60%)

#split NORMAL list to train , val , test
train.extend(normal[:train_size_normal])             #add the first images to the train list by train_size_normal
remaining_normal = normal[train_size_normal:]        #store the remaining normal images (those not added to the training set)
test_size_normal = len(remaining_normal) // 2        #calc the number of remaining images to use for the test and val lists
test.extend(remaining_normal[:test_size_normal])     #half to test list
val.extend(remaining_normal[test_size_normal:])      #half to val list

#split BACTERIA list to train , val , test
train.extend(bacteria[:train_size_bacteria])
remaining_bacteria = bacteria[train_size_bacteria:]
test_size_bacteria = len(remaining_bacteria) // 2
test.extend(remaining_bacteria[:test_size_bacteria])
val.extend(remaining_bacteria[test_size_bacteria:])

#split VIRUS list to train , val , test
train.extend(virus[:train_size_virus])
remaining_virus = virus[train_size_virus:]
test_size_virus = len(remaining_virus) // 2
test.extend(remaining_virus[:test_size_virus])
val.extend(remaining_virus[test_size_virus:])

##############################################################################
## EXCPECTED LISTS ##
##############################################################################

## TRAIN LIST :  normal:951   bacteria:1668 virus:895
## TEST LIST  :  normal:317   bacteria:556  virus:299
## VAL LIST   :  normal:317   bacteria:556  virus:299

##############################################################################
##############################################################################


#########################################################################################
#####  IMAGES PROCESS ###################################################################


def image_processor(data):
    normalized = []
    labels = []

    for im_path, label in data:
        # Convert label 2 to 1 (for Q1 we don't need to differentiate between bacteria and virus)
        if label == 2:
            labels.append(1)
        else:
            labels.append(label)

        # Open the image in RGB format
        image = Image.open(im_path).convert('RGB')

        # Resize the image to (160, 160)
        resized_image = image.resize((160, 160))

        # Convert the resized image to a NumPy array (160, 160, 3)
        image_array = np.array(resized_image)

        # Normalize pixel values to [0, 1]
        im_normal = image_array / 255.0

        # Append the normalized image
        normalized.append(im_normal)

    return np.array(normalized), np.array(labels)

#Initialize dictionary to hold the processed data
norm_data = {}

# Process each dataset and store the results
for name, data in {'train': train, 'val': val, 'test': test}.items():
    normalized, labels = image_processor(data)
    norm_data[name] = (normalized, labels)

# Extract processed data
train_normlized, train_label = norm_data['train']
val_normlized,   val_label   = norm_data['val']
test_normlized,  test_label  = norm_data['test']

######################################################################################################
## CNN- TRANSFER LEARNING #########################################################################################
# CNN Transfer Learning Model
#
# Define hyperparameters to test
epochs_list = [7,12,17]
learning_rates = [0.01, 0.001, 0.0001]
optimizers_list = [('Adam', keras.optimizers.Adam),
   ('SGD', keras.optimizers.SGD),('SGD with momentum', lambda lr: keras.optimizers.SGD(lr, momentum=0.9)),
    ('RMSprop', keras.optimizers.RMSprop)]
# Create a dictionary to store the results for each combination
results = {}

for opt_name, opt_fn in optimizers_list:
    for lr in learning_rates:
        for epochs in epochs_list:
          # Load the MobileNetV2 base model
          base_model = tf.keras.applications.MobileNetV2(input_shape=(160, 160, 3), include_top=False, weights='imagenet')
          # Freeze the base model's layers
          base_model.trainable = False

          # Define a new model with the functional API
          inputs = tf.keras.Input(shape=(160, 160, 3))  # Define the input shape
          x = base_model(inputs, training=False)  # Pass the input through the base model

          # Add global average pooling (or flatten) and dense layers for classification
          x = tf.keras.layers.GlobalAveragePooling2D()(x)  # Reduce dimensions using GlobalAveragePooling2D
          x = tf.keras.layers.Dense(128, activation='relu')(x)  # Add a fully connected layer
          outputs = tf.keras.layers.Dense(1, activation='sigmoid')(x)  # Output layer for binary classification

          # Create the final model
          model = tf.keras.Model(inputs, outputs)

          # Compile the model
          optimizer = opt_fn(lr)
          model.compile(optimizer=optimizer,
                          loss='binary_crossentropy',
                          metrics=['accuracy'])
          # Print the model summary
          model.summary()

          # Train the model
          history = model.fit(train_normlized, train_label, batch_size=32, epochs=epochs, validation_data=(val_normlized, val_label))

          # Evaluate the model
          loss, accuracy = model.evaluate(test_normlized, test_label, verbose=1)
          print(f"Test Loss: {loss}")
          print(f"Test Accuracy: {accuracy}")


          #acuraccy curve
          plt.plot(history.history['accuracy'], label='Training Accuracy')
          plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
          plt.title(f'Accuracy: Optimizer={opt_name}, Epochs={epochs}, LR={lr}')
          plt.xlabel('Epochs')
          plt.ylabel('Accuracy')
          plt.grid()
          plt.legend(loc='lower right')
          plt.show()

          plt.clf() # clear figure
          plt.plot(history.history['loss'], label='Training loss')

          #loss curve
          plt.plot(history.history['val_loss'], label='Validation loss')
          plt.title(f'Loss: Optimizer={opt_name}, Epochs={epochs}, LR={lr}')
          plt.xlabel('Epochs')
          plt.ylabel('Loss')
          plt.grid()
          plt.legend(loc='upper right')
          plt.show()
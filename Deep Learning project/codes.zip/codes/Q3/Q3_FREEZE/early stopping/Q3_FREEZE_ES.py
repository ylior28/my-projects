from google.colab import drive
from glob import glob
from PIL import Image
import os
import random
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import tensorflow as tf
from tensorflow import keras
from keras import optimizers
from tensorflow.keras.applications import MobileNetV2
from keras.callbacks import ReduceLROnPlateau
from keras.models import Sequential
from keras.layers import Dense, Conv2D , MaxPool2D , Flatten , Dropout , BatchNormalization
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report,confusion_matrix
from sklearn.metrics import confusion_matrix, precision_score, recall_score, f1_score, precision_recall_curve
from keras.callbacks import EarlyStopping

#########################################################################################
######## RECIEVE DATA ###################################################################

#import dataset from google drive (run in colab)
drive.mount('/content/drive')

paths = [] #TOTAL 5866
for dirname, _, filenames in os.walk('/content/drive/My Drive/chest_xray'):
    for filename in filenames:
        paths.append(os.path.join(dirname, filename))

#separate to 2 lists of normal and pneumonia
normal = []
pneumonia = []
for img in paths:
    if ".DS_Store" in img:
        pass
    elif "NORMAL" in img:
        normal.append((img, 0))  #Label 0, Total NORMAL:1585
    else:
        pneumonia.append(img)   #Total PNEUMONIA:4273


#separate pneumonia list to 2 lists of bacteria and virus
bacteria = []
virus = []
for i in pneumonia:
    if "bacteria" in i:
        bacteria.append((i, 1))  #Label 1, Total BACTERIS images:2780
    elif "virus" in i:
        virus.append((i, 2))  #Label 2, Total VIRUS:1493

#arrage the lists randomally
random.shuffle(normal)
random.shuffle(bacteria)
random.shuffle(virus)

# Initialize train, test, and validation lists
train = []
test = []
val = []

#Makes sure that train list will have at least 200 of normal and 200 of pneumonia but not more than 60%
train_size_normal = max(200, int(0.6 * len(normal)))      #Takes the max images from (200,60%)
train_size_bacteria = max(100, int(0.6 * len(bacteria)))  #Takes the max images from (100,60%)
train_size_virus = max(100, int(0.6 * len(virus)))        #Takes the max images from (100,60%)

#split NORMAL list to train , val , test
train.extend(normal[:train_size_normal])             #add the first images to the train list by train_size_normal
remaining_normal = normal[train_size_normal:]        #store the remaining normal images (those not added to the training set)
test_size_normal = len(remaining_normal) // 2        #calc the number of remaining images to use for the test and val lists
test.extend(remaining_normal[:test_size_normal])     #half to test list
val.extend(remaining_normal[test_size_normal:])      #half to val list

#split BACTERIA list to train , val , test
train.extend(bacteria[:train_size_bacteria])
remaining_bacteria = bacteria[train_size_bacteria:]
test_size_bacteria = len(remaining_bacteria) // 2
test.extend(remaining_bacteria[:test_size_bacteria])
val.extend(remaining_bacteria[test_size_bacteria:])

#split VIRUS list to train , val , test
train.extend(virus[:train_size_virus])
remaining_virus = virus[train_size_virus:]
test_size_virus = len(remaining_virus) // 2
test.extend(remaining_virus[:test_size_virus])
val.extend(remaining_virus[test_size_virus:])

##############################################################################
## EXCPECTED LISTS ##
##############################################################################

## TRAIN LIST :  normal:951   bacteria:1668 virus:895
## TEST LIST  :  normal:317   bacteria:556  virus:299
## VAL LIST   :  normal:317   bacteria:556  virus:299

##############################################################################
##############################################################################


#########################################################################################
#####  IMAGES PROCESS ###################################################################


def image_processor(data):
    normalized = []
    labels = []

    for im_path, label in data:
        # Convert label 2 to 1 (for Q1 we don't need to differentiate between bacteria and virus)
        if label == 2:
            labels.append(1)
        else:
            labels.append(label)

        # Open the image in RGB format
        image = Image.open(im_path).convert('RGB')

        # Resize the image to (160, 160)
        resized_image = image.resize((160, 160))

        # Convert the resized image to a NumPy array (160, 160, 3)
        image_array = np.array(resized_image)

        # Normalize pixel values to [0, 1]
        im_normal = image_array / 255.0

        # Append the normalized image
        normalized.append(im_normal)

    return np.array(normalized), np.array(labels)

#Initialize dictionary to hold the processed data
norm_data = {}

# Process each dataset and store the results
for name, data in {'train': train, 'val': val, 'test': test}.items():
    normalized, labels = image_processor(data)
    norm_data[name] = (normalized, labels)

# Extract processed data
train_normlized, train_label = norm_data['train']
val_normlized,   val_label   = norm_data['val']
test_normlized,  test_label  = norm_data['test']

######################################################################################################
## CNN- TRANSFER LEARNING #########################################################################################
# CNN Transfer Learning Model

## ADAM optimizer with accuracy=0.955 , epochs=15 , lr= 0.0001

# Load the MobileNetV2 base model
base_model = tf.keras.applications.MobileNetV2(input_shape=(160, 160, 3), include_top=False, weights='imagenet')
# Freeze the base model's layers
base_model.trainable = False

# Define a new model with the functional API
inputs = tf.keras.Input(shape=(160, 160, 3))  # Define the input shape
x = base_model(inputs, training=False)  # Pass the input through the base model

# Add global average pooling (or flatten) and dense layers for classification
x = tf.keras.layers.GlobalAveragePooling2D()(x)  # Reduce dimensions using GlobalAveragePooling2D
x = tf.keras.layers.Dense(128, activation='relu')(x)  # Add a fully connected layer
outputs = tf.keras.layers.Dense(1, activation='sigmoid')(x)  # Output layer for binary classification

# Create the final model
model = tf.keras.Model(inputs, outputs)

# Compile the model
model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.001),
              loss='binary_crossentropy',
              metrics=['accuracy'])

# Print the model summary
model.summary()
# Define early stopping callback
early_stopping = EarlyStopping(monitor='val_loss', patience=5 ,mode='min', verbose=1, restore_best_weights=True)
# Train the model
history = model.fit(train_normlized, train_label, batch_size=32, epochs=7, validation_data=(val_normlized, val_label),callbacks=[early_stopping])

# Evaluate the model
loss, accuracy = model.evaluate(test_normlized, test_label, verbose=1)
print(f"Test Loss: {loss}")
print(f"Test Accuracy: {accuracy}")


#acuraccy curve
plt.plot(history.history['accuracy'], label='Training Accuracy')
plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
plt.title('Training and Validation Accuracy vs. Number of Epochs')
plt.xlabel('Epochs')
plt.ylabel('Accuracy')
plt.grid()
plt.legend(loc='lower right')
plt.show()

plt.clf() # clear figure
plt.plot(history.history['loss'], label='Training loss')

#loss curve
plt.plot(history.history['val_loss'], label='Validation loss')
plt.title('Training and validation loss vs. Number of Epochs')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.grid()
plt.legend(loc='upper right')
plt.show()

# # ploting presicion, recall and F1 score graphs
# predicted_probabilities = model.predict(test_normlized)

# # Convert probabilities to binary predictions (0 or 1) for the confusion matrix
# predicted_labels = (predicted_probabilities > 0.5).astype(int)

# # Compute precision, recall, and F1 score for different thresholds
# precision_values = []
# recall_values = []
# f1_values = []

# for threshold in np.arange(0.1, 0.95, 0.05):
#     # Apply threshold to predicted probabilities
#     predicted_labels = (predicted_probabilities > threshold).astype(int)
#     # Compute precision, recall, and F1 score
#     precision = precision_score(test_label, predicted_labels)
#     recall = recall_score(test_label, predicted_labels)
#     f1 = f1_score(test_label, predicted_labels)
#     precision_values.append(precision)
#     recall_values.append(recall)
#     f1_values.append(f1)

# # precision-recall curve
# plt.figure(figsize=(8, 6))
# plt.plot(recall_values, precision_values, 'b-o')
# for i in range(len(precision_values)):
#     plt.text(recall_values[i], precision_values[i], f'f1={f1_values[i]:.3f}', fontsize=7, rotation=20)

# plt.xlabel('Recall')
# plt.ylabel('Precision')
# plt.title('Precision-Recall Curve')
# plt.grid(True)
# plt.show()

# #get the maximum F1 score and corresponding threshold
# max_f1 = max(f1_values)
# max_index = f1_values.index(max_f1)
# threshold = 0.1 + 0.05 * max_index
# print(f"The best F1 score is {max_f1:.3} with threshold of {threshold:.2}")
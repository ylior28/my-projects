
from google.colab import drive
from glob import glob
from PIL import Image
import os
import random
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import tensorflow as tf
from tensorflow import keras
from keras import optimizers
from keras.callbacks import ReduceLROnPlateau
from keras.models import Sequential
from keras.layers import Dense, Conv2D , MaxPool2D , Flatten , Dropout , BatchNormalization
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report,confusion_matrix
from sklearn.metrics import confusion_matrix, precision_score, recall_score, f1_score, precision_recall_curve
from sklearn.model_selection import train_test_split
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras import layers


#########################################################################################
######## RECIEVE DATA ###################################################################

#import dataset from google drive (run in colab)
drive.mount('/content/drive')

paths = [] #TOTAL 5866
for dirname, _, filenames in os.walk('/content/drive/My Drive/chest_xray'):
    for filename in filenames:
        paths.append(os.path.join(dirname, filename))

#separate to 2 lists of normal and pneumonia
normal = []
pneumonia = []
for img in paths:
    if ".DS_Store" in img:
        pass
    elif "NORMAL" in img:
        normal.append((img, 0))  #Label 0, Total NORMAL:1585
    else:
        pneumonia.append(img)    #Total PNEUMONIA:4273

#separate pneumonia list to 2 lists of bacteria and virus
bacteria = []
virus = []
for i in pneumonia:
    if "bacteria" in i:
        bacteria.append((i, 1))  #Label 1, Total BACTERIS images:2780
    elif "virus" in i:
        virus.append((i, 2))     #Label 2, Total VIRUS:1493

#arrange the lists randomally
random.shuffle(normal)
random.shuffle(bacteria)
random.shuffle(virus)

# Initialize train, test, and validation lists
train = []
test = []
val = []

#Makes sure that train list will have at least 200 of normal and 200 of pneumonia but not more than 60%
train_size_normal = max(200, int(0.6 * len(normal)))      #takes the max images from (200,60%)
train_size_bacteria = max(100, int(0.6 * len(bacteria)))  #takes the max images from (100,60%)
train_size_virus = max(100, int(0.6 * len(virus)))        #takes the max images from (100,60%)

#split NORMAL list to train , val , test
train.extend(normal[:train_size_normal])                 #add the first images to the train list by train_size_normal
remaining_normal = normal[train_size_normal:]            #store the remaining normal images (those not added to the training set)
test_size_normal = len(remaining_normal) // 2            #calc the number of remaining images to use for the test and val lists
test.extend(remaining_normal[:test_size_normal])         #half to test list
val.extend(remaining_normal[test_size_normal:])          #half to val list

#split BACTERIA list to train , val , test
train.extend(bacteria[:train_size_bacteria])
remaining_bacteria = bacteria[train_size_bacteria:]
test_size_bacteria = len(remaining_bacteria) // 2
test.extend(remaining_bacteria[:test_size_bacteria])
val.extend(remaining_bacteria[test_size_bacteria:])

#split VIRUS list to train , val , test
train.extend(virus[:train_size_virus])
remaining_virus = virus[train_size_virus:]
test_size_virus = len(remaining_virus) // 2
test.extend(remaining_virus[:test_size_virus])
val.extend(remaining_virus[test_size_virus:])

##############################################################################
## EXCPECTED LISTS ##
##############################################################################

## TRAIN LIST :  normal:951   bacteria:1668 virus:895
## TEST LIST  :  normal:317   bacteria:556  virus:299
## VAL LIST   :  normal:317   bacteria:556  virus:299

##############################################################################
##############################################################################

#########################################################################################
#####  IMAGES PROCESS ###################################################################

def image_processor(data):
    normalized = []
    labels = []

    for im_path, label in data:
        # Convert label 2 to 1 (for Q1 we don't need to differentiate between bacteria and virus)
        if label == 2:
            labels.append(1)
        else:
            labels.append(label)
        image = Image.open(im_path).convert('RGB')  #RGB format
        resized_image = image.resize((160, 160))    #resize the image
        image_array = np.array(resized_image)       #convert the image to a NumPy array
        im_normal = image_array / 255.0             #normlize the pixels values from 0-1
        normalized.append(im_normal)
    return np.array(normalized), np.array(labels)
#Initialize dictionary to hold the processed data
norm_data = {}

# Process each dataset and store the results
for name, data in {'train': train, 'val': val, 'test': test}.items():
    normalized, labels = image_processor(data)
    norm_data[name] = (normalized, labels)

# Extract processed data
train_normlized, train_label = norm_data['train']
val_normlized,   val_label   = norm_data['val']
test_normlized,  test_label  = norm_data['test']

####### CNN Transfer Learning Model ###############################
### Q1.2
#load the pre-trained MobileNetV2 model without the top layers
base_model = tf.keras.applications.MobileNetV2(
    input_shape=(160, 160, 3),               #use 3 channels for RGB images
    include_top=False,
    weights='imagenet'
)
base_model.trainable = False                 #freeze the pre-trained layers
inputs = tf.keras.Input(shape=(160, 160, 3))
x = base_model(inputs, training=False)       #pass inputs through base model

#add new layers
x = layers.Conv2D(32, (3, 3), activation='relu', padding='same')(x)
x = layers.MaxPooling2D((2, 2))(x)
x = layers.Conv2D(64, (3, 3), activation='relu', padding='same')(x)
x = layers.MaxPooling2D((2, 2))(x)
#flat and add dense layers
x = layers.Flatten()(x)
x = layers.Dense(128, activation='relu')(x)
outputs = layers.Dense(1, activation='sigmoid')(x)

#create the model
model = tf.keras.Model(inputs, outputs)
model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.001),
              loss='binary_crossentropy',
              metrics=['accuracy'])

model.summary()
# history = model.fit(train_normlized, train_label, batch_size=32, epochs=15, validation_data=(val_normlized, val_label))
# loss, accuracy = model.evaluate(test_normlized, test_label, verbose=1)
# print(f"Test Loss: {loss}")
# print(f"Test Accuracy: {accuracy}")
#ifndef _WorstFitAllocator_H_
#define _WorstFitAllocator_H_

#include"Block.h"
#include "MemoryManager.h"
#include "FirstFitAllocator.h"
#include "BestFitAllocator.h"

class WorstFitAllocator :public MemoryManager {
private:
	Block* findWorstFit(int size);
public:
	WorstFitAllocator (int poolSize);
	void* allocate(int size);
	const char* getAlgorithmName() const;
};

#endif

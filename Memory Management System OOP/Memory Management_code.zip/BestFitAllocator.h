#ifndef _BestFitAllocator_H_
#define _BestFitAllocator_H_

#include"Block.h"
#include "MemoryManager.h"
#include "FirstFitAllocator.h"
#include "WorstFitAllocator.h"


class BestFitAllocator :public MemoryManager {
private:
	Block* findBestFit(int size);
public:
	BestFitAllocator(int poolSize);
	void* allocate(int size);
	const char* getAlgorithmName() const;
};

#endif

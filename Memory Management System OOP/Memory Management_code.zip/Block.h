#ifndef _Block_H_
#define _Block_H_
#include <iostream>
#include <stdexcept>
#include <cassert>
#include <cstdlib>
#include <ctime>
#include <crtdbg.h>
#include <cstring>
#include <vector>
//---------------------//
// project libraries :



using namespace std;

//Used to represent a section of memory(allocated or free) 
// and to manage allocations from the pool.
class Block {
private:
	int m_size;
	bool m_isFree;
	Block* m_next;
	friend class MemoryManager;
public:
	Block(int size = 0);
	void setSize(int size);
	void setFree(bool State);
	void setNext(Block* next);
	int getSize() const;
	bool isFree() const;
	Block* getNext(); 
};
#endif
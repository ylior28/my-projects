#ifndef _MemoryManager_H_
#define _MemoryManager_H_

#include"Block.h"

class MemoryManager {
protected:
	Block* m_memoryPool;
	int m_peakUsage;
	int m_totalSize;
	int m_usedSize;
	int m_failedAllocations;
	void mergeBlock(Block* block);
public:
	MemoryManager(int poolSize = 1024);
	bool splitBlock(Block* block, int Size);
	virtual ~MemoryManager();
	virtual void* allocate(int size) = 0;
	void deallocate(void* ptr);
	int getTotalMemory() const;
	int getUsedMemory() const;
	int getFreeMemory() const;
	int getPeakUsage() const;
	int getFailedAllocations() const;
	const Block* getHeader() const;
	virtual const char* getAlgorithmName() const = 0;
	void reset(int poolSize);
	friend ostream& operator<<(ostream& os, const MemoryManager& mm);
};

#endif
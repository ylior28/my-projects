#include "FirstFitAllocator.h"




FirstFitAllocator::FirstFitAllocator(int poolSize) : MemoryManager(poolSize) {}


Block* FirstFitAllocator::findFirstFit(int size)
{
    Block* current_block = m_memoryPool;
    while (current_block) {
        if (current_block->isFree() && current_block->getSize() >= size)
        {
            return current_block;
        }
        current_block = current_block->getNext();
    }
    return nullptr;
}

void* FirstFitAllocator::allocate(int size)
{
    if (size <= 0)
    {
        m_failedAllocations++;
        return nullptr;
    }
    Block* block = findFirstFit(size);
    if (!block) {
        m_failedAllocations++;
        return nullptr;
    }
    if (!splitBlock(block, size))
    {
        if (block->getSize() >= size)
        {
            block->setFree(false);
        }
        else
        {
            m_failedAllocations++;
            return nullptr;
        }
    }
    m_usedSize += size;
    if (m_usedSize > m_peakUsage)
    {
        m_peakUsage = m_usedSize;
    }
    return (char*)block + sizeof(Block); //return the address 
}

const char* FirstFitAllocator::getAlgorithmName() const
{
    return "first fit algorithm";
}
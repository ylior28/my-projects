#include "Block.h"

Block::Block(int size) :m_size(size), m_isFree(true), m_next(nullptr) {}
//m_next is nullptr because it should wait for the 
//next block in the 
// MemoryPool to be created and links it later

void Block::setSize(int size)// set new size 
{
    m_size = size;
}

void Block::setFree(bool State)//true: the block memory is free, false: busy block memory  
{
    m_isFree = State;
}

void Block::setNext(Block* next)// point to next memory block 
{
    m_next = next;
}
int Block::getSize() const
{
    return m_size;
}
bool Block::isFree() const
{
    return m_isFree;
}
Block* Block::getNext()
{
    return m_next;
}
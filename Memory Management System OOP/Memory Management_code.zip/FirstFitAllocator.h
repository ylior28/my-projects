#ifndef _FirstFitAllocator_H_
#define _FirstFitAllocator_H_

#include"Block.h"
#include "MemoryManager.h"
#include "BestFitAllocator.h"
#include "WorstFitAllocator.h"
class FirstFitAllocator:public MemoryManager {
private:
	Block* findFirstFit(int size);
public:
	FirstFitAllocator(int poolSize);
	void* allocate(int size);
	const char* getAlgorithmName() const;
};

#endif

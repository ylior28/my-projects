#include "BestFitAllocator.h"




BestFitAllocator::BestFitAllocator(int poolSize) : MemoryManager(poolSize) {}

Block* BestFitAllocator::findBestFit(int size)
{
    Block* bestFit = nullptr;
    Block* current_block = m_memoryPool;
    while (current_block) {
        if (current_block->isFree() && current_block->getSize() >= size)
        {
            if (!bestFit)
            {
                bestFit = current_block;
            }
            else if (current_block->getSize() < bestFit->getSize())
            {
                bestFit = current_block;
            }
        }
        current_block = current_block->getNext();
    }
    return bestFit;
}

void* BestFitAllocator::allocate(int size)
{
    if (size <= 0)
    {
        m_failedAllocations++;
        return nullptr;
    }
    Block* block = findBestFit(size);
    if (!block)
    {
        m_failedAllocations++;
        return nullptr;
    }

    if (!splitBlock(block, size))
    {
        if (block->getSize() >= size)
        {
            block->setFree(false);
        }
        else
        {
            m_failedAllocations++;
            return nullptr;
        }
    }
    m_usedSize += size;
    if (m_usedSize > m_peakUsage)
    {
        m_peakUsage = m_usedSize;
    }
    return (char*)block + sizeof(Block); //return the address 
}




const char* BestFitAllocator::getAlgorithmName() const
{
    return "best fit algorithm";
}

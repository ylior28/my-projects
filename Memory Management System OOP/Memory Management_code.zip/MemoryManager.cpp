#include "MemoryManager.h"



MemoryManager::MemoryManager(int poolSize) :m_peakUsage(0),
m_totalSize(poolSize), m_usedSize(0), m_failedAllocations(0)
{
    m_memoryPool = (Block*)new char[poolSize];
    m_memoryPool->setSize(poolSize - sizeof(Block));
    m_memoryPool->setFree(true);
    m_memoryPool->setNext(nullptr);
}

MemoryManager::~MemoryManager() //dtor to  free the entire memory pool
{
    delete[](char*)m_memoryPool;
}

bool MemoryManager::splitBlock(Block* block, int Size)
{
    int total_needed = Size + sizeof(Block);
    if (block->getSize() < total_needed)
    {
        return false; //not enough space to split 
    }
    //point to the beginning of the new block in the memory
    Block* new_block = (Block*)((char*)(block + 1) + Size);
    //calculate the remaining size for the new block
    int remaining_size = block->getSize() - total_needed;

    // link the new block to the rest of the list
    new_block->setNext(block->getNext());

    //set  details to the allocated block  
    block->setSize(Size);
    block->setFree(false);
    block->setNext(new_block);

    //set details to new block 
    new_block->setSize(remaining_size);
    new_block->setFree(true);

    return true;
}


void MemoryManager::mergeBlock(Block* block)
{
    while (block->getNext() && (block->getNext())->isFree())
    {
        Block* next = block->getNext();
        block->setSize(block->getSize() + sizeof(Block) + next->getSize());
        block->setNext(next->getNext());
    }
}

void MemoryManager::deallocate(void* ptr)
{
    if (!ptr)
    {
        return;
    }
    // Calculate bounds 
    char* poolStart = (char*)m_memoryPool;
    char* poolEnd = poolStart + m_totalSize;

    // Check if ptr is inside pool addr
    if ((char*)ptr < poolStart + sizeof(Block) || (char*)ptr >= poolEnd)
    {
        cout << "Warning you attempted to deallocate pointer that outside of memory pool.\n" << endl;
        return; // ignore invalid deallocation
    }

    Block* block = (Block*)((char*)ptr - sizeof(Block));//back to main data 
    int size_free = block->getSize();//save value before merging  
    block->setFree(true);
    mergeBlock(block);// merge those data 
    m_usedSize -= size_free;//update the used memory 
}





int MemoryManager::getTotalMemory() const
{
    return m_totalSize;
}

int MemoryManager::getUsedMemory() const
{
    return m_usedSize;
}

int MemoryManager::getFreeMemory() const
{
    return m_totalSize - m_usedSize;
}

int MemoryManager::getPeakUsage() const
{
    return m_peakUsage;
}

int MemoryManager::getFailedAllocations() const
{
    return m_failedAllocations;
}

const Block* MemoryManager::getHeader() const
{
    return m_memoryPool;
}

void MemoryManager::reset(int poolSize) {
    if (m_memoryPool)
    {
        delete[](char*)m_memoryPool;
    }
    m_totalSize = poolSize;
    m_usedSize = 0;
    m_peakUsage = 0;
    m_failedAllocations = 0;

    m_memoryPool = (Block*)new char[poolSize];
    m_memoryPool->setSize(poolSize - sizeof(Block));
    m_memoryPool->setFree(true);
    m_memoryPool->setNext(nullptr);
}


ostream& operator<<(ostream& os, const MemoryManager& mm)
{
    Block* current_block = mm.m_memoryPool;
    int block_num = 0;
    int count_block = 0;
    while (current_block)
    {
        os << "Block number " << block_num++ << endl;
        os << "Size: " << current_block->getSize() << endl;
        if (current_block->isFree())
        {
            os << "Status: free" << endl;
        }
        else
        {
            os << "Status: used" << endl;
        }
        count_block++;
        current_block = current_block->getNext();
    }
    os << "peak usage: " << mm.getPeakUsage() << " bytes" << endl;
    os << "total size: " << mm.getTotalMemory() << " bytes" << endl;
    os << "used size: " << mm.getUsedMemory() << " bytes" << endl;
    os << "Free size(not include headers!): " << mm.getFreeMemory() << " bytes" << endl;
    os << "Actual Free size you have: " << mm.getFreeMemory() - (count_block * sizeof(Block)) << " bytes" << endl;
    os << "failed allocations: " << mm.getFailedAllocations() << " bytes" << endl;
    return os;
}
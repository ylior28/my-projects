#include "FirstFitAllocator.h"
#include "BestFitAllocator.h"
#include "WorstFitAllocator.h"
#include "MemorySimulator.h"
#include <iostream>
using namespace std;


int main(void) {

    const int poolSize = 2048;

    FirstFitAllocator firstFit(poolSize);
    BestFitAllocator bestFit(poolSize);
    WorstFitAllocator worstFit(poolSize);

    MemorySimulator simulator(100);

    simulator.runAllScenarios(&firstFit);
    simulator.runAllScenarios(&bestFit);
    simulator.runAllScenarios(&worstFit);

	return 0;
}

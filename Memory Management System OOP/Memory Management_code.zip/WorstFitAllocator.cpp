#include "WorstFitAllocator.h"




WorstFitAllocator::WorstFitAllocator(int poolSize) : MemoryManager(poolSize) {}

Block* WorstFitAllocator::findWorstFit(int size)
{
    Block* worstFit = nullptr;
    Block* current_block = m_memoryPool;

    while (current_block) {
        if (current_block->isFree() && current_block->getSize() >= size)
        {
            if (!worstFit)
            {
                worstFit = current_block;
            }
            else if (current_block->getSize() >= worstFit->getSize())
            {
                worstFit = current_block;
            }
        }
        current_block = current_block->getNext();
    }

    return worstFit;
}


void* WorstFitAllocator::allocate(int size)
{
    if (size <= 0)
    {
        m_failedAllocations++;
        return nullptr;
    }
    Block* block = findWorstFit(size);
    if (!block)
    {
        m_failedAllocations++;
        return nullptr;
    }
    if (!splitBlock(block, size))
    {
        if (block->getSize() >= size)
        {
            block->setFree(false);
        }
        else
        {
            m_failedAllocations++;
            return nullptr;
        }
    }
    m_usedSize += size;
    if (m_usedSize > m_peakUsage)
    {
        m_peakUsage = m_usedSize;
    }
    return (char*)block + sizeof(Block); //return the address 
}


const char* WorstFitAllocator::getAlgorithmName() const
{
    return "worst fit algorithm";
}

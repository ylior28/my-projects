#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <cassert>
#include <crtdbg.h>
#include <cstring>
#include "FirstFitAllocator.h"
#include "BestFitAllocator.h"
#include "WorstFitAllocator.h"

using namespace std;

const int POOL_SIZE = 1024;

void printBlocks(const MemoryManager& allocator)
{
    cout << allocator << endl;
}

void testAllScenarios(MemoryManager& allocator)
{
    cout << "=== Testing: " << allocator.getAlgorithmName() << " ===" << endl;

    // 1. Basic allocation
    void* a = allocator.allocate(100);
    void* b = allocator.allocate(100);
    void* c = allocator.allocate(100);
    assert(a && b && c);
    printBlocks(allocator);


    allocator.deallocate(a); 
    allocator.deallocate(c);
    allocator.deallocate(b); // middle one last
    printBlocks(allocator);
 
    // 3. Edge-split allocation (just enough to avoid creating another block)
    void* big = allocator.allocate(POOL_SIZE-100-sizeof(Block)*2); 
    printBlocks(allocator);
    assert(big);
    allocator.deallocate(big);

    // 4. Invalid allocation size (zero or negative)
    void* zero = allocator.allocate(0);
    assert(zero == nullptr);

    // 5. Deallocating nullptr should do nothing
    allocator.deallocate(nullptr); // Should be safe

    // 6. Allocate as many blocks as possible until memory is exhausted
    void* blocks[50];
    int count = 0;
    while ((blocks[count] = allocator.allocate(64))) {
        count++;
    }
    cout << "Allocated " << count << " blocks of 64 bytes" << endl;

    // 7. Attempt to deallocate an address not from the pool
    int dummy = 42;
    cout << "[Expected safe behavior] Attempting to deallocate external address..." << endl;
    allocator.deallocate(&dummy); // Should not crash

    // 8. Double free test
    if (count >= 2) {
        allocator.deallocate(blocks[0]);
        allocator.deallocate(blocks[0]); // Should not crash
    }

    // 9. Test getHeader directly
    const Block* header = allocator.getHeader();
    assert(header != nullptr);
    cout << "Header size: " << header->getSize()
        << ", isFree: " << (header->isFree() ? "true" : "false") << endl;

    // 10. Reset during usage (should clear everything)
    allocator.reset(POOL_SIZE);
    assert(allocator.getUsedMemory() == 0);
    assert(allocator.getFailedAllocations() == 0);

    cout << "[All checks passed for: " << allocator.getAlgorithmName() << "]\n" << endl;
}



void testStrategyLogic(MemoryManager& allocator)
{
    cout << "=== Strategy Logic Test: " << allocator.getAlgorithmName() << " ===" << endl;

    allocator.reset(POOL_SIZE);

    // Step 1: Allocate three blocks
    void* b0 = allocator.allocate(50); // Block 0
    void* b1 = allocator.allocate(200); // Block 1
    void* b2 = allocator.allocate(100); // Block 2
    void* b3 = allocator.allocate(300); // Block 3
    void* b4 = allocator.allocate(50); // Block 4 used
    assert(b1 && b2 && b3);
    // Step 2: Deallocate blocks
    allocator.deallocate(b0);  
    allocator.deallocate(b1); 
    allocator.deallocate(b2);  
    allocator.deallocate(b3);  
    printBlocks(allocator);
    // Step 3: Allocate 100 bytes, algorithm should select different block
    void* testAlloc = allocator.allocate(100);
    assert(testAlloc);

    // Get header to check size of selected block
    Block* header = (Block*)((char*)testAlloc - sizeof(Block));
    Block* nextBlock = header->getNext();
    int actualSize = nextBlock->getSize();
    printBlocks(allocator);

    // Verify according to strategy
    const char* algo = allocator.getAlgorithmName();

    if (strcmp(algo, "first fit algorithm") == 0)
    {
        assert(actualSize == 84);
        cout << "First Fit selected block size: " << actualSize << " (Expected:use block with size 200))" << endl;
    }
    else if (strcmp(algo, "best fit algorithm") == 0)
    {
        assert(actualSize == 300);
        cout << "Best Fit selected block size: " << actualSize << " (Expected: use block with size 100)" << endl;
    }
    else if (strcmp(algo, "worst fit algorithm") == 0)
    {
        assert(actualSize == 184);
        cout << "Worst Fit selected block size: " << actualSize << " (Expected: use block with size 300)" << endl;
    }
    else
    {
        assert(false && "Unknown allocator type");
    }

    cout << "[Strategy logic test passed for: " << algo << "]\n" << endl;
}


int main()
{
    _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
    {
        FirstFitAllocator first(POOL_SIZE);
        testAllScenarios(first);
        testStrategyLogic(first); 
    }

    {
        BestFitAllocator best(POOL_SIZE);
        testAllScenarios(best);
        testStrategyLogic(best);
    }

    {
        WorstFitAllocator worst(POOL_SIZE);
        testAllScenarios(worst);
        testStrategyLogic(worst);
    }
    
    cout << " All extreme tests completed successfully.\n";
    cout << "Leaks: " << _CrtDumpMemoryLeaks() << endl;
    return 0;
}
